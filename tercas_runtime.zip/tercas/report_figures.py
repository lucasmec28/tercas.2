"""Technical PNG figures for the calculation report; no screen/chart dependency.

Moments are reconstructed from analysis.py, including its exact candidate
locations. Sampled diagram arrays are never used to determine an extreme.
"""
from __future__ import annotations

from functools import lru_cache
from io import BytesIO
import math
from pathlib import Path

from PIL import Image, ImageDraw, ImageFont

from . import analysis
from .report_tables import case_labels


_INK = '#17232e'
_GRID = '#cdd4da'
_BLUE = '#164e76'
_RED = '#883b29'
_WIDTH = 1800


@lru_cache(maxsize=12)
def _font(size: int, bold=False):
    paths = ([r'C:/Windows/Fonts/timesbd.ttf',
              '/usr/share/fonts/truetype/liberation2/LiberationSerif-Bold.ttf',
              '/usr/share/fonts/truetype/dejavu/DejaVuSerif-Bold.ttf'] if bold else
             [r'C:/Windows/Fonts/times.ttf',
              '/usr/share/fonts/truetype/liberation2/LiberationSerif-Regular.ttf',
              '/usr/share/fonts/truetype/dejavu/DejaVuSerif.ttf'])
    for filename in paths:
        if Path(filename).is_file():
            return ImageFont.truetype(filename, size)
    try:
        return ImageFont.truetype('DejaVuSerif.ttf', size)
    except OSError:
        return ImageFont.load_default(size=size)


def _fmt(value, precision=6):
    if abs(value) < 1e-10:
        value = 0.
    return f'{value:.{precision}g}'.replace('.', ',')


def _png(image):
    stream = BytesIO()
    image.save(stream, format='PNG', dpi=(277, 277), optimize=True)
    return stream.getvalue()


def _text(draw, xy, text, size=38, *, bold=False, anchor='la', fill=_INK):
    draw.text(xy, text, font=_font(size, bold), fill=fill, anchor=anchor)


def _line(draw, points, fill=_INK, width=4):
    draw.line(points, fill=fill, width=width)


def _dimension(draw, x1, x2, y, label, *, label_y=None):
    _line(draw, [(x1,y-15),(x1,y+15)], width=2)
    _line(draw, [(x2,y-15),(x2,y+15)], width=2)
    _line(draw, [(x1,y),(x2,y)], width=2)
    for x in (x1,x2):
        _line(draw, [(x-8,y+9),(x+8,y-9)], width=3)
    _text(draw, ((x1+x2)/2, label_y if label_y is not None else y-10), label,
          size=35, anchor='ms')


def beam_evidence(project: dict) -> dict:
    """Return drawing assumptions and exact stations, in mm, for the caption."""
    member = project['member']
    length = float(member['L_m'])*1000
    if not math.isfinite(length) or length <= 0:
        raise ValueError('O desenho exige vão positivo e finito.')
    restraint = member['restraint']
    if restraint not in ('none', 'discrete', 'continuous', 'panel'):
        raise ValueError('Condição de contenção desconhecida para o desenho.')
    positions = []
    spacing = None
    assumption = 'Apoios verticais apenas nas extremidades A e B.'
    if restraint == 'discrete':
        spacing = float(member['Lb_m'])*1000
        if not math.isfinite(spacing) or not 0 < spacing <= length:
            raise ValueError('O desenho exige 0 < Lb ≤ L.')
        count = max(0, math.ceil(length/spacing-1e-12)-1)
        if count > 10000:
            raise ValueError('Quantidade de contenções excede o limite do desenho.')
        positions = [spacing*i for i in range(1, count+1)]
        assumption += (' Contenções laterais e torcionais representadas a cada Lb, '
                       'a partir de A; espaçamento uniforme assumido porque o projeto '
                       'não informa posições. O último trecho é o residual. '
                       'Contenções não representam apoios verticais adicionais.')
    elif restraint in ('continuous', 'panel'):
        assumption += (' A linha superior indica contenção lateral/torcional '+
                       ('contínua.' if restraint == 'continuous' else 'associada ao painel.')+
                       ' Não representa apoio vertical distribuído.')
    stations = [0., *positions, length]
    return dict(length_mm=length, restraint=restraint, spacing_mm=spacing,
                supports_mm=[0., length], restraint_positions_mm=positions,
                segments_mm=[b-a for a,b in zip(stations, stations[1:])],
                assumption=assumption, intermediate_vertical_supports=False)


def beam_figure(project: dict) -> bytes:
    """Draw the end-supported member; intermediate marks are lateral restraints."""
    data = beam_evidence(project)
    image = Image.new('RGB', (_WIDTH, 610), 'white')
    draw = ImageDraw.Draw(image)
    left, right, level = 130., 1670., 215.
    length = data['length_mm']
    x = lambda z: left+(right-left)*z/length
    _line(draw, [(left,level),(right,level)], width=8)
    for end, label in ((left, 'A'), (right, 'B')):
        draw.polygon([(end,level+7),(end-30,level+62),(end+30,level+62)],
                     fill='white', outline=_INK, width=4)
        if label == 'B':
            for xx in (end-16,end+16):
                draw.ellipse((xx-7,level+65,xx+7,level+79), outline=_INK, width=3)
            base = level+85
        else:
            base = level+70
        _line(draw, [(end-46,base),(end+46,base)], width=3)
        _text(draw, (end,level+103), label, size=40, bold=True, anchor='mt')
    if data['restraint'] in ('continuous','panel'):
        _line(draw, [(left,level-55),(right,level-55)], fill=_BLUE, width=4)
        for i in range(17):
            xx = left+(right-left)*i/16
            _line(draw, [(xx,level-55),(xx,level-15)], fill=_BLUE, width=3)
        label = 'Contenção contínua' if data['restraint']=='continuous' else 'Contenção associada ao painel'
        _text(draw, (900,70), label+' — sem apoio vertical intermediário', anchor='mt', fill=_BLUE)
    elif data['restraint'] == 'discrete':
        positions = data['restraint_positions_mm']
        # All stations remain in evidence; dense schematics show a uniform pattern.
        displayed = positions if len(positions)<=60 else positions[:3]+positions[-3:]
        for pos in displayed:
            xx=x(pos)
            _line(draw, [(xx,level-64),(xx,level-12)], fill=_BLUE, width=4)
            draw.ellipse((xx-8,level-8,xx+8,level+8), fill='white', outline=_BLUE, width=4)
            _line(draw, [(xx-14,level-70),(xx+14,level-58)], fill=_BLUE, width=3)
        if len(positions)>60:
            _text(draw, (900,level-53), '…', size=48, anchor='mm', fill=_BLUE)
        _text(draw, (900,65), 'Contenções laterais/torcionais — não são apoios verticais', anchor='mt', fill=_BLUE)
        segments=data['segments_mm']
        stations=[0.,*positions,length]
        if len(segments)<=8:
            for i,(a,b) in enumerate(zip(stations,stations[1:])):
                # A short residual uses a separate label level to avoid overlap.
                label_y=365 if x(b)-x(a)<120 else None
                _dimension(draw,x(a),x(b),400,_fmt(b-a),label_y=label_y)
        else:
            _dimension(draw,left,x(stations[1]),400,'Lb = '+_fmt(segments[0]))
            _dimension(draw,x(stations[-2]),right,400,'Residual = '+_fmt(segments[-1]))
            _text(draw,(900,370),f'{len(positions)} contenções intermediárias; posições em espaçamento Lb',size=32,anchor='mt')
    else:
        _text(draw,(900,70),'Barra biapoiada — sem contenções intermediárias',anchor='mt')
    _dimension(draw,left,right,490,'L = '+_fmt(length)+' mm')
    _text(draw,(900,550),'Cotas em mm.',size=34,anchor='mt')
    return _png(image)


def _case_state(result, combination):
    length=float(result['project']['member']['L_m'])*1000
    case=analysis.beam_case(combination,length)
    diagram=next((row for row in result.get('diagrams',[]) if row['case_id']==combination['id']),{})
    kind=diagram.get('analysis_type','primeira ordem')
    second_order=kind.startswith('segunda ordem:')
    if kind!='primeira ordem' and not second_order:
        raise ValueError('Tipo de análise do diagrama não reconhecido: '+str(kind))
    if second_order:
        E=float(result['project']['material']['E_mpa'])
        ix=float(result['section']['Ix'])
        evaluate=lambda z: analysis.beam_column_forces(case,z,E,ix)
        candidates={'Mx':[0.,length/2,length], 'My':[0.,length]}
    else:
        evaluate=lambda z: analysis.forces(case,z)
        candidates={key:analysis.moment_candidates(case,axis)
                    for key,axis in (('Mx','major'),('My','minor'))}
    peaks={}
    for key in ('Mx','My'):
        rows=[dict(position_mm=z,value_Nmm=float(evaluate(z)[key])) for z in candidates[key]]
        maximum=max(rows,key=lambda row:row['value_Nmm'])
        minimum=min(rows,key=lambda row:row['value_Nmm'])
        peaks[key]=dict(maximum=maximum,minimum=minimum,
                        absolute=max(rows,key=lambda row:abs(row['value_Nmm'])))
    evidence: dict=dict(analysis_type=kind,second_order=second_order,
                  exact_candidates_mm=candidates,
                  extrema_method=('Solução analítica de viga-coluna: extremos em 0, L/2 e L.'
                                  if second_order else 'Extremos polinomiais exatos por trechos de analysis.moment_candidates.'),
                  assumptions=(['Modelo plano de segunda ordem, inicialmente reto, EIx bruto constante; '
                                'não inclui imperfeições iniciais nem estabilidade global do sistema.']
                               if second_order else []),
                  demand_matches=[],verification_points=[])
    for check in result.get('checks',[]):
        for suffix,key,branch in (('Mx+','Mx','maximum'),('Mx-','Mx','minimum'),
                                  ('My+','My','maximum'),('My-','My','minimum')):
            if check['id']!=combination['id']+'-'+suffix or check.get('demand') is None:
                continue
            value=abs(peaks[key][branch]['value_Nmm'])/1e6
            matched=math.isclose(value,float(check['demand']),rel_tol=1e-8,abs_tol=1e-9)
            evidence['demand_matches'].append(dict(check_id=check['id'],axis=key,
                demand_kNm=check['demand'],figure_peak_kNm=value,matches=matched))
            if not matched:
                raise ValueError('O extremo reconstruído não corresponde ao Msd verificado: '+check['id'])
    return case,evaluate,peaks,evidence


def _moment_png(case, evaluate, peaks, short_label, second_order):
    image=Image.new('RGB',(_WIDTH,980),'white')
    draw=ImageDraw.Draw(image)
    left,right=175.,1675.
    length=case['L']
    x=lambda z:left+(right-left)*z/length
    _text(draw,(900,25),short_label+' · ELU · '+('segunda ordem' if second_order else 'primeira ordem'),
          size=42,bold=True,anchor='mt')
    for index,(key,color) in enumerate((('Mx',_BLUE),('My',_RED))):
        top=95.+index*455
        bottom=top+220
        extremum=peaks[key]['absolute']['value_Nmm']/1e6
        scale=max(abs(extremum)*1.15,.01)
        y=lambda value: (top+bottom)/2-value/scale*(bottom-top)/2
        _text(draw,(left,top-43),key+' (kN·m)',size=39,bold=True,fill=color)
        for ordinate in (-scale,0.,scale):
            yy=y(ordinate)
            _line(draw,[(left,yy),(right,yy)],fill=_INK if ordinate==0 else _GRID,width=2)
            _text(draw,(left-20,yy),_fmt(ordinate,4),size=34,anchor='rm')
        for fraction in (0.,.25,.5,.75,1.):
            xx=x(fraction*length)
            _line(draw,[(xx,top),(xx,bottom)],fill=_GRID,width=2)
            _text(draw,(xx,bottom+12),_fmt(fraction*length),size=33,anchor='mt')
        _text(draw,(right,bottom+52),'z (mm)',size=33,anchor='rt')
        # Exact extrema and the concentrated-load station are inserted in the
        # drawing mesh. This mesh smooths the curve; it never finds the peaks.
        points=sorted(set([length*i/240 for i in range(241)]+[case['a']]+
                          [peaks[key][label]['position_mm'] for label in ('maximum','minimum')]))
        _line(draw,[(x(z),y(evaluate(z)[key]/1e6)) for z in points],fill=color,width=6)
        for label in ('maximum','minimum'):
            peak=peaks[key][label]
            xx,yy=x(peak['position_mm']),y(peak['value_Nmm']/1e6)
            draw.ellipse((xx-7,yy-7,xx+7,yy+7),fill=color)
        positive=peaks[key]['maximum'];negative=peaks[key]['minimum']
        _text(draw,(left,bottom+97),
              'Máximo: '+_fmt(positive['value_Nmm']/1e6)+' kN·m em z = '+_fmt(positive['position_mm'])+' mm',size=37)
        _text(draw,(left,bottom+141),
              'Mínimo: '+_fmt(negative['value_Nmm']/1e6)+' kN·m em z = '+_fmt(negative['position_mm'])+' mm',size=37)
    return _png(image)


def moment_figures(result: dict, verifications=None) -> list[dict]:
    """Return concomitant Mx/My figures for the governing and required ULS cases.

    Optional verification rows use case_id/check_id/kind and position_mm.
    Figures additionally cover the largest demand and utilization of each
    signed bending check, grouping all references to the same combination.
    """
    combinations={row['id']:row for row in result['combinations'] if row['kind']=='ULS'}
    if not combinations:
        return []
    selected=[]
    def add(identifier):
        if identifier in combinations and identifier not in selected:
            selected.append(identifier)
    checks=[row for row in result.get('checks',[]) if row.get('case_id') in combinations]
    numeric=[row for row in checks if row.get('utilization') is not None]
    if numeric:
        add(max(numeric,key=lambda row:row['utilization'])['case_id'])
    verifications=[] if verifications is None else list(verifications)
    for row in verifications:
        add(row.get('case_id'))
    for suffix in ('Mx+','Mx-','My+','My-'):
        rows=[row for row in checks if row['id']==row['case_id']+'-'+suffix]
        demands=[row for row in rows if row.get('demand') is not None]
        ratios=[row for row in rows if row.get('utilization') is not None]
        if demands:
            add(max(demands,key=lambda row:row['demand'])['case_id'])
        if ratios:
            add(max(ratios,key=lambda row:row['utilization'])['case_id'])
    if not selected:
        # A nonzero moment with an unavailable resistance still deserves a plot.
        for identifier,combination in combinations.items():
            if any(abs(combination[key])>1e-12 for key in ('qx_kNm','qy_kNm','px_kN','py_kN')):
                add(identifier)
                break
    labels=case_labels(result)
    figures=[]
    for identifier in selected:
        combination=combinations[identifier]
        case,evaluate,peaks,evidence=_case_state(result,combination)
        selected_verifications=[row for row in verifications if row.get('case_id')==identifier]
        evidence['check_ids']=[row['check_id'] for row in selected_verifications if row.get('check_id')]
        for row in selected_verifications:
            if row.get('position_mm') is None:
                continue
            z=float(row['position_mm'])
            if not 0<=z<=case['L']:
                raise ValueError('Posição da verificação fora do vão: '+str(row.get('check_id')))
            evidence['verification_points'].append(dict(check_id=row.get('check_id'),position_mm=z,
                Mx_Nmm=float(evaluate(z)['Mx']),My_Nmm=float(evaluate(z)['My'])))
        caption=(f"{labels[identifier]} — {combination['label']}. Mx e My concomitantes em kN·m; "
                 'z em mm; cada eixo tem escala própria. '+
                 ('Segunda ordem.' if evidence['second_order'] else 'Primeira ordem.'))
        figures.append(dict(png=_moment_png(case,evaluate,peaks,labels[identifier],evidence['second_order']),
                            caption=caption,case_id=identifier,peaks=peaks,evidence=evidence))
    return figures
