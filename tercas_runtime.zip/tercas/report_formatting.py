"""Display numbers without changing any engineering value or coefficient."""
from __future__ import annotations

import math

_SUPER = str.maketrans('-0123456789', '⁻⁰¹²³⁴⁵⁶⁷⁸⁹')


def number(value) -> str:
    if value is None:
        return '—'
    if not isinstance(value, (int, float)) or isinstance(value, bool):
        return str(value)
    value = float(value)
    if not math.isfinite(value):
        raise ValueError('A memória não aceita valores não finitos.')
    if value == 0:
        return '0,00'
    if abs(value) < .01 or abs(value) >= 1e6:
        mantissa, exponent = f'{value:.2e}'.split('e')
        text = mantissa+'×10'+str(int(exponent)).translate(_SUPER)
    else:
        text = f'{value:.2f}'
    return text.replace('.', ',').replace('-', '−')
