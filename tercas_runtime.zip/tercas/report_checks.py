"""Compact, editable calculation steps, independent of any document renderer.

Only already calculated checks are selected. Resistance data belong to the
governing combination; concurrent actions are rebuilt at one analytical point.
Internal calculations use N, mm and MPa. Displayed capacities explicitly divide
moments by 10⁶ and forces by 1000. No value is extracted from prose or LaTeX.
"""
from __future__ import annotations

from copy import deepcopy
import math

import numpy as np

from . import analysis, resistance
from .resistance_plates import effective_u, effective_intervals, reduction
from .report_formatting import number
from .orientation import projection_angle, gravity_components, is_girt


_EXP = str.maketrans('-+0123456789', '⁻⁺⁰¹²³⁴⁵⁶⁷⁸⁹')


def _f(value):
    return number(float(value))


def _fp(value):
    """A scientific base must be delimited before a further exponent."""
    text=_f(value)
    return '('+text+')' if '×10' in text else text


def _eq(symbolic,numeric,value=None,unit='',name=''):
    result=(str(value) if isinstance(value,str) else
            ((name+' = ') if name else '')+_f(value)+((' '+unit) if unit else ''))
    return dict(symbolic=symbolic,numeric=numeric,result=result)


def _agree(actual,expected,name):
    if not math.isclose(float(actual),float(expected),rel_tol=8e-6,abs_tol=2e-8):
        raise ValueError(f'A reconstrução da memória divergiu do resultado de {name}. Recalcule o projeto.')


def _reduction_expression(slenderness,*,local_mrd=False):
    limit=.776 if local_mrd else .673
    if slenderness<=limit+1e-14:
        return '1 (λ ≤ '+str(limit).replace('.', ',')+')','1'
    if local_mrd:
        return '(1 − 0,15/λ^(0,8))/λ^(0,8)',f'(1 − 0,15/{_f(slenderness)}^(0,8))/{_f(slenderness)}^(0,8)'
    return '(1 − 0,22/λ)/λ',f'(1 − 0,22/{_f(slenderness)})/{_f(slenderness)}'


def _chi_expression(lam):
    if lam<=.6+1e-14:
        return '1 (λ₀ ≤ 0,6)','1'
    if lam<1.336:
        return '1,11(1 − 0,278λ₀²)',f'1,11(1 − 0,278×{_fp(lam)}²)'
    return '1/λ₀²',f'1/{_fp(lam)}²'


def _resolved_project(result,rd):
    p=deepcopy(result['project'])
    member=p['member']
    catalog=result.get('section_catalog')
    if catalog is not None and p['profile']['family']=='Ue':
        critical=catalog.get('major',{}).get('distortional_Nmm')
        member['mdist_major_kNm']=None if critical is None else critical/1e6
    for sign in ('pos','neg'):
        for prefix,field in (('Ml','ml'),('Mdist','mdist')):
            key=f'{prefix}_minor_{sign}_Nmm'
            if key in rd:
                value=rd[key]
                member[f'{field}_minor_{sign}_kNm']=None if value is None else value/1e6
        if rd.get(f'minor_{sign}_distortional_absence_verified'):
            member[f'_minor_{sign}_distortional_absent']=True
    return p


class _Context:
    def __init__(self,result,check):
        self.result=result
        self.check=check
        self.p=result['project']
        self.s=result['section']
        self.m=self.p['material']
        self.E=self.m['E_mpa']
        self.fy=self.m['fy_mpa']
        self.cid=check.get('case_id')
        self.combination=next(c for c in result['combinations'] if c['id']==self.cid)
        self.case=analysis.beam_case(self.combination,self.p['member']['L_m']*1000)
        self.rd=result['resistances'].get('by_case',{}).get(self.cid,result['resistances'])
        diagram=next((d for d in result.get('diagrams',[]) if d['case_id']==self.cid),{})
        self.second=str(diagram.get('analysis_type','')).startswith('segunda ordem')
        self.equations=[]
        self.position=None
        self.concurrent=None

    def add(self,*args,**kwargs):
        self.equations.append(_eq(*args,**kwargs))

    def forces(self,z,side='right'):
        if self.second:
            return analysis.beam_column_forces(self.case,z,self.E,self.s['Ix'])
        return analysis.forces(self.case,z,side)

    def set_point(self,z,side='right'):
        self.position=float(z)
        self.concurrent={**self.forces(z,side),'N':self.case['N']}

    def moment_point(self,axis,sign):
        name='Mx' if axis=='x' else 'My'
        points=analysis.moment_candidates(self.case,'major' if axis=='x' else 'minor')
        if self.second:
            points=sorted(set(points+[self.case['L']/2]))
        z=max(points,key=lambda x:(1 if sign=='pos' else -1)*self.forces(x)[name])
        self.set_point(z)
        assert self.concurrent is not None
        return self.concurrent[name]


def _major_local(c):
    s,m,rd=c.s,c.m,c.rd
    W,fy,E,nu=s['Wx'],c.fy,c.E,m['nu']
    ml=rd['Ml_Nmm'];lam=math.sqrt(W*fy/ml)
    rho=rd['Wef_major_mm3']/W
    sr,nr=_reduction_expression(lam)
    c.add('kℓ = kℓ(b_f/b_w; D/b_w)',
          f'kℓ = kℓ({_f(s["B"])}/{_f(s["H"])}; {_f(s["D"])}/{_f(s["H"])})',rd['kl'],name='kℓ')
    c.add('Mℓ = kℓ π² E Wₓ / [12(1 − ν²)(b_w/t)²]',
          f'Mℓ = {_f(rd["kl"])}×π²×{_f(E)}×{_f(W)}/[12(1 − {_fp(nu)}²)({_f(s["H"])}/{_f(s["t"])})²]',ml,'N·mm','Mℓ')
    c.add('λp = √(Wₓ f_y/Mℓ); ρred = '+sr,
          f'λp = √({_f(W)}×{_f(fy)}/{_f(ml)}); ρred = '+nr,
          f'λp = {_f(lam)}; ρred = {_f(rho)}')
    c.add('M_Rd,loc = ρred Wₓ f_y/(1,10×10⁶)',
          f'M_Rd,loc = {_f(rho)}×{_f(W)}×{_f(fy)}/(1,10×10⁶)',rd['major_local_Nmm']/1e6,'kN·m','M_Rd,loc')
    return rd['major_local_Nmm']


def _elastic_forces(c,*,compression=False):
    s,rd,E,G=c.s,c.rd,c.E,c.m['G_mpa']
    L=c.case['L'];legacy=rd.get('Lb_major_mm') or (c.p['member']['Lb_m']*1000 if c.p['member']['restraint']=='discrete' else L)
    lx,ly,lz=(rd.get('Lx_buckling_mm',L),rd.get('Ly_buckling_mm',legacy),rd.get('Lz_buckling_mm',legacy))
    c.add('N_ey = π² E I_y/L_y²; N_ez = [π² E C_w/L_z² + GJ]/r₀²',
          f'N_ey = π²×{_f(E)}×{_f(s["Iy"])}/{_fp(ly)}²; '
          f'N_ez = [π²×{_f(E)}×{_f(s["Cw"])}/{_fp(lz)}² + {_f(G)}×{_f(s["J"])}]/{_fp(s["r0"])}²',
          f'N_ey = {_f(rd["Ney_N"])} N; N_ez = {_f(rd["Nez_N"])} N')
    if compression:
        c.add('N_ex = π² E I_x/L_x²; β = 1 − (x₀/r₀)²',
              f'N_ex = π²×{_f(E)}×{_f(s["Ix"])}/{_fp(lx)}²; β = 1 − ({_f(s["xsc"])}/{_f(s["r0"])})²',
              f'N_ex = {_f(rd["Nex_N"])} N; β = {_f(rd["beta"])}')
        c.add('N_exz = 2 N_ex N_ez/[N_ex + N_ez + √((N_ex + N_ez)² − 4β N_ex N_ez)]; N_e = min(N_ey; N_exz)',
              f'N_exz = 2×{_f(rd["Nex_N"])}×{_f(rd["Nez_N"])}/[{_f(rd["Nex_N"])} + {_f(rd["Nez_N"])} + '
              f'√(({_f(rd["Nex_N"])} + {_f(rd["Nez_N"])})² − 4×{_f(rd["beta"])}×{_f(rd["Nex_N"])}×{_f(rd["Nez_N"])})]; '
              f'N_e = min({_f(rd["Ney_N"])}; {_f(rd["Nexz_N"])})',rd['Ne_N'],'N','N_e')


def _major_capacity(c,sign):
    local=_major_local(c)
    rd,s,fy=c.rd,c.s,c.fy
    if c.p['member']['restraint']=='panel' and sign=='neg':
        factor=rd['panel_R']
        c.add('Mₓ,Rd− = R M_Rd,loc',f'Mₓ,Rd− = {_f(factor)}×{_f(local/1e6)}',
              rd['major_neg_Rd_Nmm']/1e6,'kN·m','Mₓ,Rd−')
        return rd['major_neg_Rd_Nmm']
    values=[('M_Rd,loc',local)]
    if c.p['member']['restraint'] not in ('continuous','panel'):
        _elastic_forces(c)
        cb=rd['Cb_major'];me=rd['Me_major_Nmm']
        if c.p['member']['restraint']=='none' and c.case['N']==0:
            values_m=[abs(c.forces(c.case['L']*v)['Mx']) for v in (.25,.5,.75)]
            peak=abs(analysis.maximum_moment(c.case)['value_Nmm'])
            c.add('C_b = 12,5M_max/(2,5M_max + 3M_A + 4M_B + 3M_C)',
                  f'C_b = 12,5×{_f(peak)}/(2,5×{_f(peak)} + 3×{_f(values_m[0])} + 4×{_f(values_m[1])} + 3×{_f(values_m[2])})',cb,name='C_b')
        lam=math.sqrt(s['Wx']*fy/me);chi=rd['chi_flt_major']
        expr,num=_chi_expression(lam)
        c.add('M_e = C_b r₀ √(N_ey N_ez); λ₀ = √(Wₓ f_y/M_e)',
              f'M_e = {_f(cb)}×{_f(s["r0"])}×√({_f(rd["Ney_N"])}×{_f(rd["Nez_N"])}); '
              f'λ₀ = √({_f(s["Wx"])}×{_f(fy)}/{_f(me)})',f'M_e = {_f(me)} N·mm; λ₀ = {_f(lam)}')
        lp=math.sqrt(chi*s['Wx']*fy/rd['Ml_Nmm']);wcef=s['Wx']*reduction(lp)
        rform,rnum=_reduction_expression(lp)
        c.add('χ_FLT = '+expr+'; λp,FLT = √(χ_FLT Wₓ f_y/Mℓ); W_c,ef = ρred Wₓ, ρred = '+rform,
              f'χ_FLT = {num}; λp,FLT = √({_f(chi)}×{_f(s["Wx"])}×{_f(fy)}/{_f(rd["Ml_Nmm"])}); '
              f'W_c,ef = ({rnum})×{_f(s["Wx"])}',f'χ_FLT = {_f(chi)}; λp,FLT = {_f(lp)}; W_c,ef = {_f(wcef)} mm³')
        c.add('M_Rd,FLT = χ_FLT W_c,ef f_y/(1,10×10⁶)',
              f'M_Rd,FLT = {_f(chi)}×{_f(wcef)}×{_f(fy)}/(1,10×10⁶)',rd['major_flt_Nmm']/1e6,'kN·m','M_Rd,FLT')
        values.append(('M_Rd,FLT',rd['major_flt_Nmm']))
    detail=rd.get(f'major_{sign}_distortion',{})
    if detail.get('provided'):
        critical=detail['critical'];lam=detail['lambda_dist'];chi=detail['chi_dist']
        form,num=_reduction_expression(lam)
        cap=chi*s['Wx']*fy/1.1
        c.add('λdist = √(Wₓ f_y/M_dist); χdist = '+form,
              f'λdist = √({_f(s["Wx"])}×{_f(fy)}/{_f(critical)}); χdist = '+num,
              f'λdist = {_f(lam)}; χdist = {_f(chi)}')
        c.add('M_Rd,dist = χdist Wₓ f_y/(1,10×10⁶)',
              f'M_Rd,dist = {_f(chi)}×{_f(s["Wx"])}×{_f(fy)}/(1,10×10⁶)',cap/1e6,'kN·m','M_Rd,dist')
        values.append(('M_Rd,dist',cap))
    final=rd[f'major_{sign}_Rd_Nmm']
    c.add('Mₓ,Rd = min('+ '; '.join(k for k,_ in values)+')',
          'Mₓ,Rd = min('+ '; '.join(_f(v/1e6) for _,v in values)+')',final/1e6,'kN·m','Mₓ,Rd')
    _agree(min(v for _,v in values),final,'resistência de flexão maior')
    return final


def _minor_me(c,sign,me=None,elastic=None):
    rd,s=c.rd,c.s
    ne=elastic or rd
    if me is None:
        me=rd.get(f'Me_minor_{sign}_Nmm')
        if me is None:
            me=resistance._minor_elastic_moment(s,ne,1. if sign=='pos' else -1.)[0]
    cs=-1 if sign=='pos' else 1
    c.add('M_e = C_s N_ex [j + C_s √(j² + r₀² N_ez/N_ex)] (C_m = 1)',
          f'M_e = ({cs})×{_f(ne["Nex_N"])}×[{_f(s["j"])} + ({cs})×√({_fp(s["j"])}² + '
          f'{_fp(s["r0"])}²×{_f(ne["Nez_N"])}/{_f(ne["Nex_N"])})]',me,'N·mm','M_e')
    return me


def _mrd_rows(c,nominal,me,ml,md,details,*,service=False):
    name='|M_n|' if service else 'W_y f_y'
    lam=details['lambda0'];chi=details['chi_global']
    form,num=_chi_expression(lam)
    c.add('λ₀ = √('+name+'/M_e); χ_FLT = '+form+'; M_Re = χ_FLT '+name,
          f'λ₀ = √({_f(nominal)}/{_f(me)}); χ_FLT = {num}; M_Re = {_f(chi)}×{_f(nominal)}',
          f'λ₀ = {_f(lam)}; M_Re = {_f(details["MRe_Nmm"])} N·mm')
    lam=details['lambda_local'];rho=details['rho_local']
    form,num=_reduction_expression(lam,local_mrd=True)
    c.add('λℓ = √(M_Re/Mℓ); ρred = '+form+'; M_Rℓ = ρred M_Re',
          f'λℓ = √({_f(details["MRe_Nmm"])}/{_f(ml)}); ρred = {num}; M_Rℓ = {_f(rho)}×{_f(details["MRe_Nmm"])}',
          f'λℓ = {_f(lam)}; M_Rℓ = {_f(details["MRl_Nmm"])} N·mm')
    values=[details['MRe_Nmm'],details['MRl_Nmm']]
    symbols=['M_Re','M_Rℓ']
    if details.get('MRdist_Nmm') is not None:
        lam=details['lambda_dist'];rho=details['rho_dist'];form,num=_reduction_expression(lam)
        c.add('λdist = √('+name+'/M_dist); ρdist = '+form+'; M_Rdist = ρdist '+name,
              f'λdist = √({_f(nominal)}/{_f(md)}); ρdist = {num}; M_Rdist = {_f(rho)}×{_f(nominal)}',
              f'λdist = {_f(lam)}; M_Rdist = {_f(details["MRdist_Nmm"])} N·mm')
        values.append(details['MRdist_Nmm']);symbols.append('M_Rdist')
    return symbols,values


def _plate_rows(c,eff,stress_ref):
    # The complete iterative section is rebuilt by the same bounded MLE. Plate
    # widths/stresses are structured results, never parsed from a memory note.
    t=c.s['t'];E=c.E
    for plate,detail,bands in zip(c.s['plates'],eff['plates'],eff['retained_intervals']):
        k=detail.get('k');width=plate['width'];retained=sum(b-a for a,b in bands)
        title={'web':'alma','upper_flange':'mesa superior','lower_flange':'mesa inferior'}.get(plate['id'],plate['id'])
        if k is None:
            c.add(f'{title}: b_ret = b_i (placa tracionada)',f'b_ret = {_f(width)}',retained,'mm','b_ret')
            continue
        maximum=max(detail['sigma_a'],detail['sigma_b'])
        psi=detail.get('psi',1.);sa,sb=detail['sigma_a'],detail['sigma_b']
        if detail.get('method')=='uniform_upper_bound' or abs(sa-sb)<=1e-9*maximum:
            kformula=knumeric='4' if plate['kind']=='AA' else '0,43'
        elif plate['kind']=='AA':
            kformula='4 + 2(1 − ψ) + 2(1 − ψ)³'
            knumeric=f'4 + 2(1 − ({_f(psi)})) + 2(1 − ({_f(psi)}))³'
        elif sb>=sa:
            kformula='0,57 − 0,21ψ + 0,07ψ²'
            knumeric=f'0,57 − 0,21×({_f(psi)}) + 0,07×({_f(psi)})²'
        elif psi>=0:
            kformula='0,578/(ψ + 0,34)';knumeric=f'0,578/({_f(psi)} + 0,34)'
        else:
            kformula='1,7 − 5ψ + 17,1ψ²';knumeric=f'1,7 − 5×({_f(psi)}) + 17,1×({_f(psi)})²'
        c.add(f'{title}: ψ = σ_min/σ_max; k = '+kformula,
              f'ψ = {_f(min(sa,sb))}/{_f(maximum)}; k = '+knumeric,
              f'ψ = {_f(psi)}; k = {_f(k)}')
        form,num=_reduction_expression(detail['lambda_p'])
        c.add(f'{title}: λp = (b_i/t)/[0,95√(kE/σ_max)]; b_ret = Σ(b₂ − b₁)',
              f'λp = ({_f(width)}/{_f(t)})/[0,95√({_f(k)}×{_f(E)}/{_f(maximum)})]; '
              'b_ret = '+' + '.join(f'({_f(b)} − {_f(a)})' for a,b in bands),
              f'k = {_f(k)}; λp = {_f(detail["lambda_p"])}; b_ret = {_f(retained)} mm')
        base=width if psi>=0 or plate['kind']=='AA' else width/(1-psi)
        base_symbol='b_i' if plate['kind']=='AA' else ('b_i' if psi>=0 else 'b_i/(1 − ψ)')
        base_numeric=_f(width) if psi>=0 or plate['kind']=='AA' else f'{_f(width)}/(1 − ({_f(psi)}))'
        c.add('ρred = '+form+'; b_ef = ρred × ('+base_symbol+')',
              f'ρred = {num}; b_ef = {_f(detail["rho"])}×({base_numeric})',
              detail['rho']*base,'mm','b_ef')
    c.add('W_y,ef = I_y,ef/c_ref; M_Rd,ef = σ_ref W_y,ef/(1,10×10⁶)',
          f'W_y,ef = {_f(eff["Iy"])}/{_f(eff["Iy"]/(eff["moment_Nmm"]/stress_ref))}; '
          f'M_Rd,ef = {_f(stress_ref)}×{_f(eff["moment_Nmm"]/stress_ref)}/(1,10×10⁶)',
          eff['moment_Nmm']/1.1e6,'kN·m','M_Rd,ef')


def _minor_capacity(c,sign):
    rd,s,fy=c.rd,c.s,c.fy
    me=_minor_me(c,sign)
    if s['family']=='Ue':
        W=rd['Wyield_minor_mm3'];nom=rd['minor_yield_Nmm'];d=rd[f'minor_{sign}_mrd']
        c.add('W_y = min(W_y,alma; W_y,borda); M_y = W_y f_y',
              f'W_y = min({_f(s["Wy_web"])}; {_f(s["Wy_edge"])}); M_y = {_f(W)}×{_f(fy)}',nom,'N·mm','M_y')
        names,values=_mrd_rows(c,nom,me,rd[f'Ml_minor_{sign}_Nmm'],rd[f'Mdist_minor_{sign}_Nmm'],d)
        c.add('M_y,Rd = min('+ '; '.join(names)+')/(1,10×10⁶)',
              'M_y,Rd = min('+ '; '.join(_f(v) for v in values)+')/(1,10×10⁶)',
              d['Rd_Nmm']/1e6,'kN·m','M_y,Rd')
    else:
        direction=1. if sign=='pos' else -1.
        effective=effective_u(s,c.m,0.,direction,reference_stress=fy)
        _plate_rows(c,effective,fy)
        wc=rd.get(f'Wc_minor_{sign}_mm3') or (s['Wy_edge'] if sign=='pos' else s['Wy_web'])
        lam=math.sqrt(wc*fy/me);chi=resistance._chi_flt(lam)
        form,num=_chi_expression(lam)
        c.add('λ₀ = √(W_c f_y/M_e); χ_FLT = '+form+'; σ_ref = χ_FLT f_y',
              f'λ₀ = √({_f(wc)}×{_f(fy)}/{_f(me)}); χ_FLT = {num}; σ_ref = {_f(chi)}×{_f(fy)}',
              f'λ₀ = {_f(lam)}; σ_ref = {_f(chi*fy)} MPa')
        flt=effective_u(s,c.m,0.,direction,reference_stress=chi*fy,compression_only=True)
        # Plate iteration is identical, now at the reduced compressive stress.
        w=flt['moment_Nmm']/(chi*fy)
        c.add('M_Rd,FLT = χ_FLT f_y I_y,ef/(c_ref×1,10×10⁶)',
              f'M_Rd,FLT = {_f(chi)}×{_f(fy)}×{_f(flt["Iy"])}/({_f(flt["Iy"]/w)}×1,10×10⁶)',
              flt['moment_Nmm']/1.1e6,'kN·m','M_Rd,FLT')
        c.add('M_y,Rd = min(M_Rd,loc; M_Rd,FLT)',
              f'M_y,Rd = min({_f(effective["moment_Nmm"]/1.1e6)}; {_f(flt["moment_Nmm"]/1.1e6)})',
              rd[f'minor_{sign}_Rd_Nmm']/1e6,'kN·m','M_y,Rd')
        _agree(min(effective['moment_Nmm'],flt['moment_Nmm'])/1.1,rd[f'minor_{sign}_Rd_Nmm'],'MLE menor')
    return rd[f'minor_{sign}_Rd_Nmm']


def _shear_capacity(c):
    h,t,E,fy=c.s['h'],c.s['t'],c.E,c.fy
    lim1=1.08*math.sqrt(E*5/fy);lim2=1.4*math.sqrt(E*5/fy)
    c.add('h/t; λv,1 = 1,08√(Ek_v/f_y); λv,2 = 1,40√(Ek_v/f_y), k_v = 5',
          f'h/t = {_f(h)}/{_f(t)}; λv,1 = 1,08√({_f(E)}×5/{_f(fy)}); λv,2 = 1,40√({_f(E)}×5/{_f(fy)})',
          f'h/t = {_f(h/t)}; λv,1 = {_f(lim1)}; λv,2 = {_f(lim2)}')
    if h/t<=lim1:
        formula='0,6 f_y h t';numeric=f'0,6×{_f(fy)}×{_f(h)}×{_f(t)}'
    elif h/t<=lim2:
        formula='0,65 t²√(Ek_v f_y)';numeric=f'0,65×{_fp(t)}²×√({_f(E)}×5×{_f(fy)})'
    else:
        formula='0,905 Ek_v t³/h';numeric=f'0,905×{_f(E)}×5×{_fp(t)}³/{_f(h)}'
    c.add('V_Rd = '+formula+'/(1,10×1000)',
          'V_Rd = ('+numeric+')/(1,10×1000)',c.rd['shear_Rd_N']/1000,'kN','V_Rd')
    return c.rd['shear_Rd_N']


def _axial_capacity(c,tension=False,*,gross_bound=False):
    rd,s,fy,E=c.rd,c.s,c.fy,c.E
    if tension:
        fu=c.m['fu_mpa'];t=c.p['tension']
        if gross_bound:
            c.add('N_t,lim = min(A f_y/1,10; A f_u/1,35)/1000',
                  f'N_t,lim = min({_f(s["A"])}×{_f(fy)}/1,10; {_f(s["A"])}×{_f(fu)}/1,35)/1000',
                  rd['tension_gross_Rd_N']/1000,'kN','N_t,lim')
            return rd['tension_gross_Rd_N']
        c.add('N_t,Rd = min(A f_y/1,10; A_n0 f_u/1,35; C_t A_n f_u/1,65)/1000',
              f'N_t,Rd = min({_f(s["A"])}×{_f(fy)}/1,10; {_f(t["an0_mm2"])}×{_f(fu)}/1,35; '
              f'{_f(t["ct"])}×{_f(t["an_mm2"])}×{_f(fu)}/1,65)/1000',rd['tension_Rd_N']/1000,'kN','N_t,Rd')
        return rd['tension_Rd_N']
    _elastic_forces(c,compression=True)
    lam=math.sqrt(s['A']*fy/rd['Ne_N']);chi=rd['chi_compression']
    expression='0,658^(λ₀²)' if lam<=1.5 else '0,877/λ₀²'
    numeric=f'0,658^({_fp(lam)}²)' if lam<=1.5 else f'0,877/{_fp(lam)}²'
    c.add('λ₀ = √(A f_y/N_e); χ = '+expression,
          f'λ₀ = √({_f(s["A"])}×{_f(fy)}/{_f(rd["Ne_N"])}); χ = '+numeric,
          f'λ₀ = {_f(lam)}; χ = {_f(chi)}')
    lp=math.sqrt(chi*s['A']*fy/rd['Nl_N']);form,num=_reduction_expression(lp,local_mrd=True)
    c.add('Nℓ = kℓ π² E A/[12(1 − ν²)(b_w/t)²]; λp = √(χA f_y/Nℓ)',
          f'Nℓ = {_f(rd["kl_compression"])}×π²×{_f(E)}×{_f(s["A"])}/[12(1 − {_fp(c.m["nu"])}²)({_f(s["H"])}/{_f(s["t"])})²]; '
          f'λp = √({_f(chi)}×{_f(s["A"])}×{_f(fy)}/{_f(rd["Nl_N"])})',f'Nℓ = {_f(rd["Nl_N"])} N; λp = {_f(lp)}')
    c.add('ρred = '+form+'; A_ef = ρred A; N_c,Rd,glob = χ A_ef f_y/(1,20×1000)',
          f'ρred = {num}; A_ef = {_f(rd["Aef_compression_mm2"]/s["A"])}×{_f(s["A"])}; '
          f'N_c,Rd,glob = {_f(chi)}×{_f(rd["Aef_compression_mm2"])}×{_f(fy)}/(1,20×1000)',
          rd['compression_global_Rd_N']/1000,'kN','N_c,Rd,glob')
    d=rd.get('compression_distortion',{})
    values=[rd['compression_global_Rd_N']]
    if d.get('provided'):
        lam=d['lambda_dist'];chi=d['chi_dist']
        formula='1' if lam<=.561 else '(1 − 0,25/λdist^(1,2))/λdist^(1,2)'
        numeric='1' if lam<=.561 else f'(1 − 0,25/{_f(lam)}^(1,2))/{_f(lam)}^(1,2)'
        value=chi*s['A']*fy/1.2;values.append(value)
        c.add('λdist = √(A f_y/N_dist); χdist = '+formula+'; N_c,Rd,dist = χdist A f_y/(1,20×1000)',
              f'λdist = √({_f(s["A"])}×{_f(fy)}/{_f(d["critical"])}); χdist = {numeric}; '
              f'N_c,Rd,dist = {_f(chi)}×{_f(s["A"])}×{_f(fy)}/(1,20×1000)',value/1000,'kN','N_c,Rd,dist')
    c.add('N_c,Rd = min(resistências aplicáveis)',
          'N_c,Rd = min('+ '; '.join(_f(v/1000) for v in values)+')',rd['compression_Rd_N']/1000,'kN','N_c,Rd')
    return rd['compression_Rd_N']


def _support_capacity(c):
    s,p=c.s,c.p
    if s['family']=='Ue':
        alpha,ar,ac,ah=(4.6,.14,.35,.02) if p['support']['fastened'] else (4.3,.14,.35,.02)
    else:
        alpha,ar,ac,ah=4.6,.4,.6,.03
    t,ri,h,contact=s['t'],s['ri'],s['h'],p['support']['c_mm']
    c.add('F_Rd = α t² f_y(1 − α_r√(r_i/t))(1 + α_c√(c/t))(1 − α_h√(h/t))/(1,35×1000)',
          f'F_Rd = {_f(alpha)}×{_fp(t)}²×{_f(c.fy)}(1 − {_f(ar)}√({_f(ri)}/{_f(t)}))'
          f'(1 + {_f(ac)}√({_f(contact)}/{_f(t)}))(1 − {_f(ah)}√({_f(h)}/{_f(t)}))/(1,35×1000)',
          c.rd['support_Rd_N']/1000,'kN','F_Rd')
    return c.rd['support_Rd_N']


def _demand_moment(c,axis,sign):
    M=c.moment_point(axis,sign);q=c.case['qy' if axis=='x' else 'qx'];P=c.case['py' if axis=='x' else 'px']
    L,a,z=c.case['L'],c.case['a'],c.position
    if c.second:
        N=c.case['N'];k=math.sqrt(N/(c.E*c.s['Ix']))
        c.add('k = √(N/(E Iₓ)); Mₓ(z) = q_y/k² [cos(k(z − L/2))/(cos(kL/2)) − 1]',
              f'k = √({_f(N)}/({_f(c.E)}×{_f(c.s["Ix"])})); Mₓ({_f(z)}) = {_f(q)}/{_fp(k)}² '
              f'[cos({_f(k)}({_f(z)} − {_f(L)}/2))/(cos({_f(k)}×{_f(L)}/2)) − 1]',M,'N·mm','Mₓ')
    else:
        ra=analysis.reactions(c.case)['RAy' if axis=='x' else 'RAx']
        c.add('R_A = q L/2 + P(L − a)/L; M(z) = R_A z − q z²/2 − P max(z − a; 0)',
              f'R_A = {_f(q)}×{_f(L)}/2 + {_f(P)}({_f(L)} − {_f(a)})/{_f(L)}; '
              f'M({_f(z)}) = {_f(ra)}×{_f(z)} − {_f(q)}×{_fp(z)}²/2 − {_f(P)}×max({_f(z)} − {_f(a)}; 0)',
              M,'N·mm',f'M{axis}')
    c.add('M_Sd [kN·m] = |M(z)|/10⁶',f'M_Sd = |{_f(M)}|/10⁶',abs(M)/1e6,'kN·m','M_Sd')
    return abs(M)/1e6


def _comparison(c,symbol_d,symbol_c,demand,capacity):
    ratio=abs(demand)/capacity
    _agree(ratio,c.check['utilization'],c.check['label'])
    c.add(f'η = |{symbol_d}|/({symbol_c}) ≤ 1',f'η = |{_f(demand)}|/{_f(capacity)}',
          f'η = {_f(ratio)} '+('≤ 1' if ratio<=1+1e-9 else '> 1'))


def _interaction(c,family):
    rd=c.rd
    if family=='MV':
        _major_local(c);_shear_capacity(c)
        point=(analysis.max_beam_column_moment_shear(c.case,c.E,c.s['Ix'],rd['major_local_Nmm'],rd['shear_Rd_N'])
               if c.second else analysis.max_moment_shear(c.case,rd['major_local_Nmm'],rd['shear_Rd_N']))
        c.set_point(point['x_mm'],point.get('side','right'))
        # The analytic second-order solver's side is descriptive, not an input.
        f=point;ratio=point['utilization']
        c.add('η_MV(z) = (Mₓ(z)/M_Rd,loc)² + (V_y(z)/V_Rd)² ≤ 1',
              f'η_MV({_f(point["x_mm"])} mm) = ({_f(f["Mx"]/1e6)}/{_f(rd["major_local_Nmm"]/1e6)})² + '
              f'({_f(f["Vy"]/1000)}/{_f(rd["shear_Rd_N"]/1000)})²',
              f'η_MV = {_f(ratio)} '+('≤ 1' if ratio<=1+1e-9 else '> 1'))
    else:
        caps={key:rd.get(key+'_Rd_Nmm') for key in ('major_pos','major_neg','minor_pos','minor_neg')}
        # A zero-demand direction needs no resistance and cannot block a
        # calculated interaction. This matches the engine's active directions.
        forces=[analysis.forces(c.case,z) for z in set(analysis.moment_candidates(c.case,'major')+analysis.moment_candidates(c.case,'minor'))]
        for axis,root in (('Mx','major'),('My','minor')):
            for sign in ('pos','neg'):
                active=max((1 if sign=='pos' else -1)*f[axis] for f in forces)>1e-6
                if not active:
                    caps[root+'_'+sign]=1.
        if family.startswith('NM') and c.second:
            z=c.case['L']/2;c.set_point(z);f=c.concurrent
            sign='pos' if f['Mx']>=0 else 'neg'
            bending=abs(f['Mx'])/rd['major_'+sign+'_Rd_Nmm']
        else:
            point=analysis.max_biaxial(c.case,**caps)
            c.set_point(point['x_mm']);f=point;bending=point['utilization']
        sx='pos' if f['Mx']>=0 else 'neg';sy='pos' if f['My']>=0 else 'neg'
        mx=rd.get('major_'+sx+'_Rd_Nmm') if abs(f['Mx'])>1e-6 else None
        my=rd.get('minor_'+sy+'_Rd_Nmm') if abs(f['My'])>1e-6 else None
        terms=[];names=[]
        if mx is not None:
            _major_capacity(c,sx);terms.append(f'|{_f(f["Mx"]/1e6)}|/{_f(mx/1e6)}');names.append('|Mₓ|/Mₓ,Rd')
        if my is not None:
            _minor_capacity(c,sy);terms.append(f'|{_f(f["My"]/1e6)}|/{_f(my/1e6)}');names.append('|M_y|/M_y,Rd')
        ratio=bending
        if family.startswith('NM'):
            tension=c.case['N']<0
            bound=tension and rd.get('tension_Rd_N') is None
            nc=_axial_capacity(c,tension,gross_bound=bound)
            ratio+=abs(c.case['N'])/nc
            terms.insert(0,f'|{_f(c.case["N"]/1000)}|/{_f(nc/1000)}');names.insert(0,'|N|/N_Rd')
        c.add('η(z) = '+' + '.join(names)+' ≤ 1',
              f'η({_f(c.position)} mm) = '+' + '.join(terms),
              f'η = {_f(ratio)} '+('≤ 1' if ratio<=1+1e-9 else '> 1'))
    _agree(ratio,c.check['utilization'],'interação concomitante')


def _service_snapshot(c):
    p=_resolved_project(c.result,c.rd)
    cache={}
    def stiffness(mx,my,n=0.):
        key=(round(mx,6),round(my,6),round(n,6))
        if key not in cache:
            cache[key]=resistance.service_stiffness(p['profile'],p['material'],c.s,mx,my,n,project=p)
        return cache[key]
    case=c.case
    points=set(analysis.moment_candidates(case,'major')+analysis.moment_candidates(case,'minor'))
    ref=max((analysis.forces(case,x) for x in points),key=lambda f:abs(f['Mx'])/c.s['Wx']+abs(f['My'])/min(c.s['Wy_web'],c.s['Wy_edge']))
    if c.second:
        ref=analysis.beam_column_forces(case,case['L']/2,c.E,c.s['Ix'])
    st=stiffness(ref['Mx'],ref['My'],case['N'])
    if not st.get('converged'):
        raise ValueError('A rigidez de serviço não pode ser reconstruída para a memória.')
    if c.second:
        return st,ref,analysis.beam_column_deflections(case,c.E,c.s['Ix'],projection_angle(p['member'])),True,stiffness
    major_only=abs(case['qx'])+abs(case['px'])<1e-12
    minor_only=abs(case['qy'])+abs(case['py'])<1e-12
    gross=abs(st['Ix']/c.s['Ix']-1)<1e-8 and abs(st['Iy']/c.s['Iy']-1)<1e-8 and abs(st.get('Ixy',0))<1e-7
    constant=case['N']==0 and ((major_only and (case['qy']*case['py']>=0 or gross)) or
        (gross and abs(case['px'])+abs(case['py'])<1e-12) or
        (minor_only and case['qx']*case['px']>=0 and st.get('method')=='MRD_C5_minor'))
    response=(analysis.fixed_stiffness_deflections(case,c.E,st,projection_angle(p['member'])) if constant else
              analysis.variable_stiffness_deflections(case,c.E,stiffness,projection_angle(p['member'])))
    return st,ref,response,constant,stiffness


def _gross_service_rows(c,st,ref):
    """Full-area proof: every compressed plate plus its edge stiffener."""
    plates={p['id']:p for p in c.s['plates']}
    details=st.get('plates',[])
    lipped=[d for d in details if d.get('method')=='uniform_upper_bound_9.2.3']
    if lipped:
        d=max(lipped,key=lambda d:d['sigma_bound']);plate=plates[d['id']]
        width,t,E,sigma=plate['width'],c.s['t'],c.E,d['sigma_bound']
        coords=[(x,y) for x in (plate['a'][0],plate['b'][0]) for y in (plate['a'][1]-t/2,plate['a'][1]+t/2)]
        x,y=max(coords,key=lambda xy:ref['Mx']*xy[1]/c.s['Ix']+ref['My']*(xy[0]-c.s['xc'])/c.s['Iy'])
        c.add('σ_max,mesa = N/A + Mₓ y/Iₓ + M_y(x − x_c)/I_y; λp0 = (b_i/t)/[0,623√(E/σ_max,mesa)]',
              f'σ_max,mesa = {_f(c.case["N"])}/{_f(c.s["A"])} + {_f(ref["Mx"])}×{_f(y)}/{_f(c.s["Ix"])} + {_f(ref["My"])}×({_f(x)} − {_f(c.s["xc"])})/{_f(c.s["Iy"])}; '
              f'λp0 = ({_f(width)}/{_f(t)})/[0,623√({_f(E)}/{_f(sigma)})]',
              f'σ_max,mesa = {_f(sigma)} MPa; λp0 = {_f(d["lambda_p0"])}')
        if d['lambda_p0']>.673:
            lp0=d['lambda_p0'];Is=t*c.s['d']**3/12
            Ia=min(399*t**4*(.487*lp0-.328)**3,t**4*(56*lp0+5))
            ns=max(.582-.122*lp0,1/3);ratio=c.s['D']/width
            c.add('I_s = t d³/12; I_a = min[399t⁴(0,487λp0 − 0,328)³; t⁴(56λp0 + 5)]; η_s = min(I_s/I_a; 1)',
                  f'I_s = {_f(t)}×{_fp(c.s["d"])}³/12; I_a = min[399×{_fp(t)}⁴(0,487×{_f(lp0)} − 0,328)³; {_fp(t)}⁴(56×{_f(lp0)} + 5)]; '
                  f'η_s = min({_f(Is)}/{_f(Ia)}; 1)',f'I_s = {_f(Is)} mm⁴; I_a = {_f(Ia)} mm⁴; η_s = {_f(d["eta_s"])}')
            coefficient='3,57' if ratio<=.25 else '(4,82 − 5D/b_i)'
            number='3,57' if ratio<=.25 else f'(4,82 − 5×{_f(c.s["D"])}/{_f(width)})'
            c.add('n_s = max(0,582 − 0,122λp0; 1/3); k_mesa = min['+coefficient+'η_s^n_s + 0,43; 4]',
                  f'n_s = max(0,582 − 0,122×{_f(lp0)}; 1/3); k_mesa = min[{number}×{_f(d["eta_s"])}^{_f(ns)} + 0,43; 4]',
                  f'n_s = {_f(ns)}; k_mesa = {_f(d["k"])}')
            c.add('λp,mesa = (b_i/t)/[0,95√(k_mesa E/σ_max,mesa)] ≤ 0,673; η_s = 1',
                  f'λp,mesa = ({_f(width)}/{_f(t)})/[0,95√({_f(d["k"])}×{_f(E)}/{_f(sigma)})]',
                  f'λp,mesa = {_f(d["lambda_p"])} ≤ 0,673; η_s = 1; b_ef = {_f(width)} mm')
        else:
            c.add('λp0 ≤ 0,673 ⇒ b_ef = b_i (9.2.3)',
                  f'{_f(d["lambda_p0"])} ≤ 0,673 ⇒ b_ef = {_f(width)}',width,'mm','b_ef')
    compressed=[d for d in details if d.get('k') is not None and d.get('method')!='uniform_upper_bound_9.2.3']
    if compressed:
        terms=[];values=[]
        for d in compressed:
            width=plates[d['id']]['width'];sigma=d.get('sigma_bound',max(d['sigma_a'],d['sigma_b']))
            terms.append(f'({_f(width)}/{_f(c.s["t"])})/[0,95√({_f(d["k"])}×{_f(c.E)}/{_f(sigma)})]')
            values.append(d['lambda_p'])
        if max(values)<=.673:
            c.add('λp,max = maxᵢ{(b_i/t)/[0,95√(k_i E/σ_max,i)]} ≤ 0,673 (alma/lábios; Tabelas 5/6)',
                  'λp,max = max{'+'; '.join(terms)+'}',f'λp,max = {_f(max(values))} ≤ 0,673; ρred = 1')
        else:
            for d,term in zip(compressed,terms):
                plate=plates[d['id']];bands,_=effective_intervals(plate,d['sigma_a'],d['sigma_b'],c.E,c.s['t'])
                retained=sum(b-a for a,b in bands)
                c.add('λp = (b_i/t)/[0,95√(kE/σ_max)]; b_ret = Σ(b₂ − b₁) = b_i (faixas retidas)',
                      'λp = '+term+'; b_ret = '+' + '.join(f'({_f(b)} − {_f(a)})' for a,b in bands),
                      f'λp = {_f(d["lambda_p"])}; b_ret = {_f(retained)} mm = {_f(plate["width"])} mm')
    c.add('A_ef = A; I_x,ef = I_x; I_y,ef = I_y; I_xy,ef = 0 (seção integral comprovada)',
          f'A_ef = {_f(c.s["A"])}; I_x,ef = {_f(c.s["Ix"])}; I_y,ef = {_f(c.s["Iy"])}; I_xy,ef = 0',
          f'A_ef = {_f(st["A"])} mm²; I_x,ef = {_f(st["Ix"])} mm⁴; I_y,ef = {_f(st["Iy"])} mm⁴')


def _service(c,family):
    st,ref,response,constant,stiffness=_service_snapshot(c)
    axis='dx' if 'parallel' in family else 'dy' if 'normal' in family else 'vertical'
    z=response[axis+'_at_mm'];value=response[axis+'_mm']
    _agree(abs(value),c.check['demand'],'flecha')
    c.set_point(z)
    if st['method']=='MSE_major':
        ml=c.rd['Ml_Nmm'];moment=abs(ref['Mx']);lam=math.sqrt(moment/ml);rho=st['Ix']/c.s['Ix'];form,num=_reduction_expression(lam)
        c.add('λp,ser = √(|M_n|/Mℓ); ρred = '+form+'; I_x,ef = ρred I_x',
              f'λp,ser = √({_f(moment)}/{_f(ml)}); ρred = {num}; I_x,ef = {_f(rho)}×{_f(c.s["Ix"])}',st['Ix'],'mm⁴','I_x,ef')
    elif st['method']=='MRD_C5_minor':
        d=st['minor_mrd'];sign='pos' if ref['My']>0 else 'neg'
        p=_resolved_project(c.result,c.rd);L=c.case['L']
        lb=L if p['member'].get('deflection_ignore_restraints') else (p['member']['Lb_m']*1000 if p['member']['restraint']=='discrete' else L)
        lx,ly,lz=(st.get('service_Lx_mm',L),st.get('service_Ly_mm',lb),st.get('service_Lz_mm',lb))
        elastic=resistance._elastic(c.s,c.E,c.m['G_mpa'],lx,ly,lz)
        me=st['Me_service_Nmm'];_minor_me(c,sign,me,elastic)
        names,values=_mrd_rows(c,abs(ref['My']),me,c.rd[f'Ml_minor_{sign}_Nmm'],c.rd[f'Mdist_minor_{sign}_Nmm'],d,service=True)
        c.add('M_R,ser = min('+ '; '.join(names)+'); I_y,ef = min(1; M_R,ser/|M_n|) I_y',
              'M_R,ser = min('+ '; '.join(_f(v) for v in values)+'); '
              f'I_y,ef = min(1; {_f(d["MRser_Nmm"])}/{_f(abs(ref["My"]))})×{_f(c.s["Iy"])}',st['Iy'],'mm⁴','I_y,ef')
    elif st['method']=='gross_MLE_verified':
        _gross_service_rows(c,st,ref)
    else:
        c.add('I_x,ef = ∫(y − y_c,ef)²d A_ef; I_y,ef = ∫(x − x_c,ef)²d A_ef; I_xy,ef = ∫(x − x_c,ef)(y − y_c,ef)d A_ef',
              f'A_ef = {_f(st["A"])} mm²; x_c,ef = {_f(st["xc"])} mm; y_c,ef = {_f(st["yc"])} mm',
              f'I_x,ef = {_f(st["Ix"])} mm⁴; I_y,ef = {_f(st["Iy"])} mm⁴; I_xy,ef = {_f(st.get("Ixy",0))} mm⁴')
    L=c.case['L'];angle_deg=projection_angle(c.p['member'])
    projection=(1.,0.) if axis=='dx' else (0.,1.) if axis=='dy' else gravity_components(c.p['member'])
    c.add('δ = aδ δ_x + bδ δ_y; (aδ; bδ) = '+('(sen α; cos α)' if axis=='vertical' else '(1; 0)' if axis=='dx' else '(0; 1)'),
          '(aδ; bδ) = '+(f'(sen({_f(angle_deg)}°); cos({_f(angle_deg)}°))' if axis=='vertical' else f'({_f(projection[0])}; {_f(projection[1])})'),
          f'aδ = {_f(projection[0])}; bδ = {_f(projection[1])}')
    if c.second:
        N=c.case['N'];q=c.case['qy'];u=L/2*math.sqrt(abs(N)/(c.E*c.s['Ix']))
        M=ref['Mx']
        factor='sec(u) − 1' if N>0 else '1 − sech(u)'
        nf=f'1/(cos({_f(u)})) − 1' if N>0 else f'1 − 1/(cosh({_f(u)}))'
        c.add('u = (L/2)√(|N|/(E I_x)); M_max = q_y E I_x/|N| × ('+factor+')',
              f'u = ({_f(L)}/2)√({_f(abs(N))}/({_f(c.E)}×{_f(c.s["Ix"])})); '
              f'M_max = {_f(q)}×{_f(c.E)}×{_f(c.s["Ix"])}/{_f(abs(N))}×({nf})',M,'N·mm','M_max')
        c.add('δ_y = (M_max − q_y L²/8)/N; δ_v = δ_y cos α; δ_x = 0',
              f'δ_y = ({_f(M)} − {_f(q)}×{_fp(L)}²/8)/({_f(N)}); δ_v = {_f(response["dy_mm"])}×cos({_f(angle_deg)}°)',
              value,'mm','δ')
    elif constant:
        ix,iy,ixy=st['Ix'],st['Iy'],st.get('Ixy',0.);D=ix*iy-ixy**2
        ax,ay=projection
        q=(ax*(ix*c.case['qx']-ixy*c.case['qy'])+ay*(iy*c.case['qy']-ixy*c.case['qx']))/(c.E*D)
        P=(ax*(ix*c.case['px']-ixy*c.case['py'])+ay*(iy*c.case['py']-ixy*c.case['px']))/(c.E*D)
        c.add('qδ = [aδ(I_x,ef q_x − I_xy,ef q_y) + bδ(I_y,ef q_y − I_xy,ef q_x)]/[E(I_x,ef I_y,ef − I_xy,ef²)]',
              f'qδ = [{_f(ax)}({_f(ix)}×{_f(c.case["qx"])} − {_f(ixy)}×{_f(c.case["qy"])}) + '
              f'{_f(ay)}({_f(iy)}×{_f(c.case["qy"])} − {_f(ixy)}×{_f(c.case["qx"])})]/'
              f'[{_f(c.E)}({_f(ix)}×{_f(iy)} − {_fp(ixy)}²)]',q,'mm⁻³','qδ')
        if abs(c.case['px'])+abs(c.case['py'])<1e-12:
            c.add('δ_max = 5qδL⁴/384 (z = L/2)',f'δ_max = 5×({_f(q)})×{_fp(L)}⁴/384',value,'mm','δ_max')
        else:
            c.add('Pδ = [aδ(I_x,ef P_x − I_xy,ef P_y) + bδ(I_y,ef P_y − I_xy,ef P_x)]/[E(I_x,ef I_y,ef − I_xy,ef²)]',
                  f'Pδ = [{_f(ax)}({_f(ix)}×{_f(c.case["px"])} − {_f(ixy)}×{_f(c.case["py"])}) + '
                  f'{_f(ay)}({_f(iy)}×{_f(c.case["py"])} − {_f(ixy)}×{_f(c.case["px"])})]/({_f(c.E)}×{_f(D)})',P,'mm⁻²','Pδ')
            a=c.case['a'];b=L-a
            if z<=a:
                term='Pδ b z(L² − b² − z²)/(6L)'
                numeric=f'({_f(P)})×{_f(b)}×{_f(z)}({_fp(L)}² − {_fp(b)}² − {_fp(z)}²)/(6×{_f(L)})'
            else:
                term='Pδ a(L − z)[L² − a² − (L − z)²]/(6L)'
                numeric=f'({_f(P)})×{_f(a)}({_f(L)} − {_f(z)})[{_fp(L)}² − {_fp(a)}² − ({_f(L)} − {_f(z)})²]/(6×{_f(L)})'
            c.add('δ(z) = qδ z(L³ − 2L z² + z³)/24 + '+term,
                  f'δ({_f(z)}) = ({_f(q)})×{_f(z)}({_fp(L)}³ − 2×{_f(L)}×{_fp(z)}² + {_fp(z)}³)/24 + '+numeric,
                  value,'mm','δ')
    else:
        current=stiffness(c.concurrent['Mx'],c.concurrent['My'],c.case['N'])
        ix,iy,ixy=current['Ix'],current['Iy'],current.get('Ixy',0.);D=ix*iy-ixy**2
        ax,ay=projection;Mx,My=c.concurrent['Mx'],c.concurrent['My']
        curvature=(ax*(ix*My-ixy*Mx)+ay*(iy*Mx-ixy*My))/(c.E*D)
        c.add('κδ(z) = [aδ(I_x,ef M_y − I_xy,ef Mₓ) + bδ(I_y,ef Mₓ − I_xy,ef M_y)]/[E(I_x,ef I_y,ef − I_xy,ef²)]',
              f'κδ({_f(z)}) = [{_f(ax)}({_f(ix)}×{_f(My)} − {_f(ixy)}×{_f(Mx)}) + '
              f'{_f(ay)}({_f(iy)}×{_f(Mx)} − {_f(ixy)}×{_f(My)})]/({_f(c.E)}×{_f(D)})',curvature,'mm⁻¹','κδ')
        # Numeric integration terms are independently accumulated from the
        # same converged piecewise-linear curvature model, not inferred from δ.
        I0,Iz=_curvature_integrals(c,stiffness,projection,z,response['stations'])
        reconstructed=z/L*I0-Iz
        _agree(reconstructed,value,'integração da curvatura')
        c.add('δ(z) = (z/L)∫₀ᴸ(L − s)κδ(s)ds − ∫₀ᶻ(z − s)κδ(s)ds',
              f'δ({_f(z)}) = ({_f(z)}/{_f(L)})×({_f(I0)}) − ({_f(Iz)})',value,'mm','δ')
    denominator=L/c.check['capacity']
    c.add('δ_lim = L/divisor',f'δ_lim = {_f(L)}/{_f(denominator)}',c.check['capacity'],'mm','δ_lim')
    _comparison(c,'δ','δ_lim',abs(value),c.check['capacity'])


def _curvature_integrals(c,stiffness,projection,z,stations):
    case=c.case;L=case['L']
    points=set([0.,L,case['a']]+analysis.moment_zeros(case,'major')+analysis.moment_zeros(case,'minor')+
               analysis.moment_candidates(case,'major')+analysis.moment_candidates(case,'minor'))
    grid=None
    for panels in (32,64,128,256,512,1024,2048):
        candidate=sorted(set(np.linspace(0,L,panels+1).tolist())|points)
        if len(candidate)==stations:
            grid=candidate;break
    if grid is None:
        raise ValueError('A malha de integração de serviço não pôde ser reconstruída.')
    values=[]
    for x in grid:
        f=analysis.forces(case,x);st=stiffness(f['Mx'],f['My'],case['N'])
        ix,iy,ixy=st['Ix'],st['Iy'],st.get('Ixy',0.);D=ix*iy-ixy**2
        values.append((projection[0]*(ix*f['My']-ixy*f['Mx'])+projection[1]*(iy*f['Mx']-ixy*f['My']))/(c.E*D))
    def integral(end):
        total=0.
        for a,b,ka,kb in zip(grid[:-1],grid[1:],values[:-1],values[1:]):
            stop=min(b,end)
            if stop<=a:
                break
            h=stop-a;kstop=ka+(kb-ka)*h/(b-a)
            total+=(end-a)*h*(ka+kstop)/2-h*h*(ka/6+kstop/3)
        return total
    return integral(L),integral(z)


def _family(check,combinations):
    identifier=check['id'];case=combinations.get(check.get('case_id'),{})
    for suffix in ('Mx+','Mx-','My+','My-','Vy','MV','biax'):
        if identifier.endswith('-'+suffix):
            return suffix
    if identifier.endswith('-N'):
        return 'Nt' if case.get('nsd_kN',0)<0 else 'Nc'
    if identifier.endswith('-NM'):
        return 'NM-tension' if case.get('nsd_kN',0)<0 else 'NM-compression'
    for suffix in ('support-A','support-B','euler-model','euler-service'):
        if identifier.endswith('-'+suffix):
            return suffix
    for suffix in ('deflection-normal','deflection-parallel','deflection-vertical'):
        if identifier.endswith('-'+suffix):
            return suffix+'-'+case.get('service_type','gravity')
    return 'other-'+identifier


def build_verifications(result) -> list[dict]:
    """Worst calculated check per family; signs and service types stay separate.

    Additional structured fields: check_id, kind, demand/capacity/unit,
    position_mm and forces (N·mm / N), for diagrams and independent audits.
    Pending and excluded items belong to collect_assumptions(), never silently
    become calculated checks here.
    """
    combinations={c['id']:c for c in result.get('combinations',[])}
    chosen={}
    for check in result.get('checks',[]):
        ratio=check.get('utilization')
        if check.get('status') not in ('pass','fail') or ratio is None or not math.isfinite(ratio):
            continue
        key=_family(check,combinations)
        previous=chosen.get(key)
        if previous is None or (ratio,check.get('conditional',False))>(previous['utilization'],previous.get('conditional',False)):
            chosen[key]=check
    rows=[]
    for family,check in chosen.items():
        c=_Context(result,check)
        if family in ('Mx+','Mx-','My+','My-'):
            axis='x' if family.startswith('Mx') else 'y';sign='pos' if family.endswith('+') else 'neg'
            capacity=_major_capacity(c,sign) if axis=='x' else _minor_capacity(c,sign)
            demand=_demand_moment(c,axis,sign)
            _comparison(c,'M_Sd','M_Rd',demand,capacity/1e6)
        elif family=='Vy':
            capacity=_shear_capacity(c)
            points=[(x,side) for x in (0.,c.case['a'],c.case['L']) for side in ('left','right')]
            z,side=max(points,key=lambda item:abs(c.forces(*item)['Vy']))
            c.set_point(z,side)
            assert c.concurrent is not None
            demand=abs(c.concurrent['Vy'])/1000
            if c.second:
                k=math.sqrt(c.case['N']/(c.E*c.s['Ix']))
                c.add('V_y(z) = −q_y sin(k(z − L/2))/[k cos(kL/2)]',
                      f'V_y({_f(z)}) = −{_f(c.case["qy"])} sin({_f(k)}({_f(z)} − {_f(c.case["L"])}/2))/[{_f(k)} cos({_f(k)}×{_f(c.case["L"])}/2)]',
                      c.concurrent['Vy'],'N','V_y')
            else:
                ra=analysis.reactions(c.case)['RAy'];H=1 if z>c.case['a'] or (z==c.case['a'] and side=='right') else 0
                c.add('V_y(z) = R_Ay − q_y z − P_y H(z − a)',
                      f'V_y({_f(z)}) = {_f(ra)} − {_f(c.case["qy"])}×{_f(z)} − {_f(c.case["py"])}×{H}',c.concurrent['Vy'],'N','V_y')
            _comparison(c,'V_Sd [kN]','V_Rd [kN]',demand,capacity/1000)
        elif family in ('MV','biax') or family.startswith('NM-'):
            _interaction(c,family)
        elif family in ('Nc','Nt'):
            capacity=_axial_capacity(c,family=='Nt')
            _comparison(c,'N_Sd [kN]','N_Rd [kN]',abs(c.case['N'])/1000,capacity/1000)
        elif family.startswith('support-'):
            capacity=_support_capacity(c);end=family[-1]
            L,a=c.case['L'],c.case['a'];q,P=c.case['qy'],c.case['py']
            demand=analysis.reactions(c.case)['R'+end+'y']
            term=f'({_f(L)} − {_f(a)})' if end=='A' else _f(a)
            c.add('R_'+end+' = q_y L/2 + P_y '+('(L − a)' if end=='A' else 'a')+'/L',
                  f'R_{end} = {_f(q)}×{_f(L)}/2 + {_f(P)}×{term}/{_f(L)}',demand,'N','R_'+end)
            c.set_point(0. if end=='A' else L)
            _comparison(c,'R_'+end+' [kN]','F_Rd [kN]',demand/1000,capacity/1000)
        elif family.startswith('deflection-'):
            _service(c,family)
        elif family.startswith('euler-'):
            capacity=math.pi**2*c.E*c.s['Ix']/c.case['L']**2
            c.add('N_E = π² E I_x/L²',f'N_E = π²×{_f(c.E)}×{_f(c.s["Ix"])}/{_fp(c.case["L"])}²',capacity,'N','N_E')
            _comparison(c,'N [kN]','N_E [kN]',c.case['N']/1000,capacity/1000)
        else:
            _comparison(c,'Solicitação','Resistência ou limite',check['demand'],check['capacity'])
        rows.append(dict(key=family,title=check['label'],reference=check.get('reference',''),case_id=check.get('case_id'),
            check_id=check['id'],kind=c.combination['kind'],status=check['status'],utilization=float(check['utilization']),
            conditional=bool(check.get('conditional',False)),equations=c.equations,demand=check.get('demand'),
            capacity=check.get('capacity'),unit=check.get('unit',''),position_mm=c.position,forces=c.concurrent,
            forces_units={'Mx':'N·mm','My':'N·mm','Vx':'N','Vy':'N','N':'N'}))
    return rows


def collect_assumptions(result) -> list[str]:
    """Final-only assumptions, grouped by mechanism instead of combination."""
    p=result.get('project',{});member=p.get('member',{});rows=[]
    if member:
        restraint={'continuous':'contínua','discrete':'discreta','none':'sem contenção intermediária','panel':'painel conectado','independent':'comprimentos de flambagem independentes'}.get(member['restraint'],member['restraint'])
        lengths=(f"; Lx = {_f(member['Lx_m'])} m; Ly = {_f(member['Ly_m'])} m; Lz = {_f(member['Lz_m'])} m"
                 if member['restraint']=='independent' else f"; Lb = {_f(member['Lb_m'])} m" if member['restraint']=='discrete' else '')
        rows.append(f"Barra biapoiada: L = {_f(member['L_m'])} m; contenção declarada: {restraint}{lengths}. As condições reais devem corresponder às entradas.")
        if is_girt(member):
            rows.append('Travessa com abertura para baixo: rotação de projeção −90,00°; gravidade em −x (My negativo, alma comprimida) e vento normal ao fechamento em ±y.')
        if member.get('deflection_ignore_restraints'):
            rows.append('Flechas no vão integral L, sem considerar o efeito das contenções intermediárias; a estabilidade ELU conserva os vínculos informados.')
        if p.get('profile',{}).get('family')=='Ue' and member.get('exclude_minor_distortion'):
            rows.append('Distorção em My excluída por solicitação; não se trata de dispensa normativa nem de ausência física demonstrada. Resistência e rigidez correspondentes são condicionais.')
        if member.get('exclude_minor_shear'):
            rows.append('Cisalhamento no eixo menor e suas interações excluídos do escopo; nenhuma resistência foi atribuída ao mecanismo.')
        if is_girt(member):
            rows.append('Serviço da travessa: deslocamento paralelo ao fechamento sob a combinação concomitante e deslocamento normal sob vento isolado, conforme Tabela A.1. As notas e/f próprias de coberturas não são aplicadas ao fechamento lateral.')
        elif not p.get('limits',{}).get('additional_checks',False):
            rows.append('Critérios suplementares de flecha no plano da cobertura e na direção normal sob gravidade estão desligados; combinações com gravidade e sucção concomitantes não são verificadas por esses limites adicionais. Permanecem os critérios de gravidade vertical e sucção isolada da Tabela A.1.')
    limitations={item.get('code',''):item for item in result.get('limitations',[])}
    skip={'MINOR_DISTORTION_EXCLUDED','MINOR_SHEAR_EXCLUDED'}
    for code,item in limitations.items():
        if code not in skip and item.get('message'):
            rows.append(item['message'])
    grouped={}
    combinations={c['id']:c for c in result.get('combinations',[])}
    for item in result.get('checks',[]):
        if item.get('status') not in ('pending','excluded'):
            continue
        identifier=item['id'];note=item.get('note','')
        if item.get('status')=='excluded' and ('minor-distortion' in identifier or identifier.endswith('-Vx')):
            continue
        if identifier=='connections' and 'CONNECTIONS' in limitations:
            continue
        if identifier.endswith('-NM-global') and 'AXIAL_GLOBAL' in limitations:
            continue
        if identifier.endswith('-F-biax') and 'PANEL_BIAXIAL' in limitations:
            continue
        if '-domain-' in identifier and (identifier.split('-domain-',1)[1] in limitations or any(note==v.get('message') for v in limitations.values())):
            continue
        if 'support-' in identifier:
            if not p.get('support',{}).get('check') and 'support_not_checked' in limitations:
                continue
            key='support-disabled' if not p.get('support',{}).get('check') else ('support-uplift' if 'levantamento' in note else 'support-domain')
        elif identifier.endswith('-minor-restraints'):
            key='minor-restraints'
        elif identifier.endswith('-point-introduction'):
            key='point-introduction'
        elif '-deflection' in identifier:
            # Causes are stored separately in limitations. Keep a compact
            # reminder if the numerical service model itself remains pending.
            key='service-model'
            note='As combinações de serviço indicadas como pendentes exigem completar o modelo de deslocamentos; valores isolados não concluem a verificação.'
        else:
            key=_family(item,combinations)
        grouped.setdefault(key,note or item.get('label','Verificação não concluída.'))
    rows.extend(grouped.values())
    if any(c.get('verification')=='Estabilidade global e sistema do galpão' and c.get('status')=='pending' for c in result.get('coverage',[])):
        rows.append('Modelo de uma barra biapoiada: pórticos, contraventamentos globais, empoçamento e sequência de montagem não são verificados nesta memória.')
    catalog=result.get('section_catalog')
    if catalog:
        source=catalog.get('source',{});material=p.get('material',{})
        provenance=f"Origem dos dados numéricos de flambagem: catálogo {catalog.get('catalog_version','')}, registro {catalog.get('id','')}"
        if source.get('kind')=='computed_fsm':
            radius=catalog.get('profile',p.get('profile',{})).get('r_mm',0.)
            E=catalog.get('E_used_mpa',material.get('E_mpa',200000.))
            nu=catalog.get('reference_material',{}).get('nu',material.get('nu',.3))
            provenance+=f"; análise própria FSM/cFSM de cantos arredondados, com ri = {_f(radius)} mm, E = {_f(E)} MPa e ν = {_f(nu)} adotados no modelo."
        else:
            provenance+='; '+str(source.get('description') or source.get('reference') or 'origem registrada no JSON')+'.'
        published=catalog.get('published')
        if published:
            provenance+=f" Referência publicada: Pierin, Silva e La Rovere (2013), Tabela {published.get('table')}, p. {published.get('printed_page')} (PDF p. {published.get('pdf_page')}), modelo de cantos retos. Os valores publicados não são adotados automaticamente; Mℓ,y publicado não identifica o sentido da flexão."
        provenance+=' A procedência e os registros completos permanecem no JSON.'
        rows.append(provenance)
    elif member.get('minor_critical_source'):
        rows.append('Origem informada pelo projetista para os críticos externos: '+str(member['minor_critical_source']))
    rows.append('Grandezas e resultados são exibidos com duas casas decimais; valores pequenos não nulos usam notação científica. Coeficientes normativos conservam seus algarismos e as verificações usam a precisão completa do motor. Recalcular os valores já arredondados pode produzir pequena diferença no último algarismo.')
    return list(dict.fromkeys(text.strip() for text in rows if text and text.strip()))


def conclusion_data(result) -> dict:
    """Numerical conclusions never turn unavailable/excluded checks green.

    max_uls/max_sls are None or dictionaries with check_id, title, case_id,
    utilization, status and conditional. The numeric maxima exclude unavailable
    checks. evaluated_status refers only to evaluated checks; complete also
    requires no pending, excluded or conditional scope.
    """
    combinations={c['id']:c for c in result.get('combinations',[])}
    checks=result.get('checks',[])
    calculated=[c for c in checks if c.get('status') in ('pass','fail') and isinstance(c.get('utilization'),(int,float)) and math.isfinite(c['utilization'])]
    def peak(kind):
        items=[c for c in calculated if combinations.get(c.get('case_id'),{}).get('kind')==kind]
        if not items:
            return None
        item=max(items,key=lambda c:c['utilization'])
        return dict(check_id=item['id'],title=item['label'],case_id=item.get('case_id'),utilization=item['utilization'],status=item['status'],conditional=bool(item.get('conditional')))
    actions=any(abs(float(c.get(key,0)))>1e-12 for c in combinations.values() for key in ('qx_kNm','qy_kNm','px_kN','py_kN','nsd_kN'))
    failed=any(c.get('status')=='fail' for c in checks) or result.get('overall_status')=='fail'
    pending=any(c.get('status')=='pending' for c in checks) or any(c.get('status')=='pending' for c in result.get('coverage',[]))
    excluded=any(c.get('status')=='excluded' for c in checks)
    conditional=any(c.get('conditional') for c in calculated)
    evaluated='fail' if failed else ('pass' if calculated and actions else 'pending')
    complete=evaluated=='pass' and not (pending or excluded or conditional)
    profile=result.get('project',{}).get('profile',{})
    designation=profile.get('family','Perfil')
    dimensions=[profile[k] for k in ('h_mm','b_mm','d_mm','t_mm') if k in profile and (k!='d_mm' or profile.get('family')=='Ue')]
    if dimensions:
        designation+=' '+' × '.join(_f(v) for v in dimensions)+' mm'
    maxima=[('ELU',peak('ULS')),('ELS',peak('SLS'))]
    percentages='; '.join(label+' = '+_f(100*item['utilization'])+'%' for label,item in maxima if item is not None)
    if failed:
        text='não atende a um ou mais critérios calculados.'
    elif evaluated!='pass':
        text='não possui verificações calculadas suficientes para concluir atendimento.'
    elif complete:
        text='atende aos critérios calculados nas condições informadas.'
    else:
        text='atende aos critérios calculados, condicionado às premissas e ao escopo adotado.'
    text=designation+' '+text+((' Utilizações máximas: '+percentages+'.') if percentages else '')
    return dict(status='fail' if failed else 'pending' if evaluated=='pending' or pending else 'partial' if excluded or conditional else 'pass',
        evaluated_status=evaluated,complete=complete,passes_evaluated=evaluated=='pass',has_pending=pending,
        has_exclusions=excluded,conditional=conditional,max_uls=peak('ULS'),max_sls=peak('SLS'),
        calculated_count=len(calculated),failed_count=sum(c.get('status')=='fail' for c in checks),text=text)
