"""Physical G/D bases for an ordered, open, symmetric six-vertex Ue chain.

Two pyCUFSM0.2.0 indexing errors are bypassed without monkeypatching:
* y_dofs uses node0 as an unvisited sentinel in its sectorial traversal;
* constr_xz_y checks the second element number instead of its orientation.

Sectorial integration and the two tangent compatibility equations below are
independent constructions of the same cFSM kinematic spaces. The transverse
equilibrium extension and finite-strip matrices remain from pyCUFSM.
"""
from __future__ import annotations

import numpy as np
from scipy.linalg import null_space
from pycufsm.solve import cfsm


BASIS_VERSION = 'physical_gd_v1'


def physical_gd_bases(nodes,elements,props,el_props,length):
    """Return physical G/D vectors at the reference half-wave length.

    The origin used for sectorial coordinates is arbitrary: translation adds
    only a combination of1,x,y to omega, preserving the global subspace.
    D is its area-metric orthogonal complement in the six main longitudinal
    DOFs. Corner tangential displacement is -dv/ds before multiplication1/k.
    """
    nn = len(nodes)
    if elements.shape[0]!=nn-1 or not np.array_equal(elements[:,1:3],
            np.column_stack((np.arange(nn-1),np.arange(1,nn)))):
        raise ValueError('A base física exige uma cadeia aberta ordenada sem ramificações.')
    xy = nodes[:,1:3]
    omega = np.concatenate(([0.],np.cumsum(xy[:-1,0]*xy[1:,1]-xy[1:,0]*xy[:-1,1])))
    main,meta,node_props,n_main,n_corner,n_sub,n_dist,n_local,perm = cfsm.base_properties(nodes,elements)
    _,_,ryd,rys,rud = cfsm.mode_constr(nodes,elements,node_props,main,meta)
    if n_main!=6 or n_corner!=4 or n_dist!=2 or not np.allclose(rud,np.eye(6),atol=1e-12):
        raise ValueError('A base física exige seis nós principais independentes de uma seção Ue aberta.')
    ids = main[:,3].astype(int)

    rx,rz = np.zeros((4,6)),np.zeros((4,6))
    for k,i in enumerate(range(1,5)):
        previous,current,following = main[i-1,1:3],main[i,1:3],main[i+1,1:3]
        a,b = current-previous,following-current
        la,lb = np.linalg.norm(a),np.linalg.norm(b)
        slopes = np.zeros((2,6))
        slopes[0,i-1],slopes[0,i] = 1/la,-1/la
        slopes[1,i],slopes[1,i+1] = 1/lb,-1/lb
        compatibility = np.linalg.solve(np.vstack((a/la,b/lb)),slopes)
        rx[k],rz[k] = compatibility[0],compatibility[1]

    raw_global = np.column_stack((np.ones(6),xy[ids,1],xy[ids,0],omega[ids]))
    norms = np.linalg.norm(raw_global,axis=0)
    if np.any(norms==0):
        raise ValueError('A seção não define quatro deformações globais independentes.')
    raw_global /= norms
    if np.linalg.matrix_rank(raw_global)!=4:
        raise ValueError('A seção não define quatro deformações globais independentes.')
    global_y = np.linalg.qr(raw_global,mode='reduced')[0]
    chol = np.linalg.cholesky(ryd).T
    distortional_y = np.linalg.solve(chol,null_space((chol@global_y).T))
    if distortional_y.shape!=(6,2):
        raise ValueError('A separação física não produziu dois modos distorcionais.')
    dy = np.column_stack((global_y,distortional_y))
    basis = cfsm.base_column(nodes_base=nodes,elements=elements,props=props,length=length,
                            B_C='S-S',m_a=np.array([1]),el_props=el_props,node_props=node_props,
                            n_main_nodes=n_main,n_corner_nodes=n_corner,n_sub_nodes=n_sub,
                            n_global_modes=4,n_dist_modes=2,n_local_modes=n_local,dof_perm=perm,
                            r_x=rx,r_z=rz,r_ys=rys,d_y=dy)
    orthogonality = float(np.linalg.norm(global_y.T@ryd@distortional_y)/
                          (np.linalg.norm(global_y)*np.linalg.norm(ryd)*np.linalg.norm(distortional_y)))
    compatibility_error = max(np.linalg.norm(rx@main[:,1]+np.ones(4)),
                              np.linalg.norm(rz@main[:,2]+np.ones(4)),
                              np.linalg.norm(rx@main[:,2]),np.linalg.norm(rz@main[:,1]))
    if orthogonality>1e-10 or compatibility_error>1e-10:
        raise ValueError('A base física não satisfez suas identidades de compatibilidade/ortogonalidade.')
    return {'basis':basis[:,:6],'n_local':n_local,'global_y':global_y,
            'distortional_y':distortional_y,'metric':ryd,'omega':omega,
            'rx':rx,'rz':rz,'main_nodes':main,
            'audit':{'version':BASIS_VERSION,'global_modes':4,'distortional_modes':2,
                     'area_metric_orthogonality_relative':orthogonality,
                     'linear_field_compatibility_residual':float(compatibility_error),
                     'sectorial_method':'Integração ordenada de x dy−y dx ao longo da cadeia aberta.',
                     'corner_method':'Compatibilidade nos dois tangentes adjacentes: T u=−dv/ds.'}}
