"""Map the installation to the existing member axes and signed moments.

The solver convention is positive My = compression at the free edges. A wall
girt opening down therefore has negative My under gravity (web compressed).
No section properties or resistance formula is rotated or recalculated here.
"""
from __future__ import annotations

import math


def is_girt(member: dict) -> bool:
    return member.get('element_type', 'roof_purlin') == 'wall_girt'


def projection_angle(member: dict) -> float:
    """Angle used by the signed load/deflection convention, in degrees."""
    return -90.0 if is_girt(member) else float(member['angle_deg'])


def gravity_components(member: dict) -> tuple[float, float]:
    if is_girt(member):
        return -1.0, 0.0
    angle = math.radians(projection_angle(member))
    return math.sin(angle), math.cos(angle)


def element_label(member: dict) -> str:
    return 'Travessa de fechamento lateral' if is_girt(member) else 'Terça de cobertura'


def minor_restraints_present(member: dict) -> bool:
    if member['restraint'] == 'independent':
        return member['Ly_m'] < member['L_m'] - 1e-12
    return member['restraint'] == 'discrete' and member['Lb_m'] < member['L_m'] - 1e-12
