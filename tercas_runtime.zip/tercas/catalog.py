"""Traceable section table, readable from a normal package or the runtime ZIP."""
from copy import deepcopy
from functools import lru_cache
from importlib.resources import files
import json
import math
from typing import Any


PROFILE_FIELDS = ('family', 'h_mm', 'b_mm', 'd_mm', 't_mm', 'r_mm')


@lru_cache(maxsize=1)
def _catalog() -> dict[str, Any]:
    data = json.loads(files('tercas').joinpath('data').joinpath('section_catalog.json').read_text(encoding='utf8'))
    identifiers = set()
    for entry in data['entries']:
        if entry['id'] in identifiers:
            raise ValueError('Identificador duplicado no catálogo de perfis.')
        identifiers.add(entry['id'])
        if entry['major']['status'] != 'computed' or entry['major']['local_Nmm'] <= 0:
            raise ValueError('O catálogo contém um perfil sem crítico local maior concluído.')
        if entry['profile']['family'] == 'Ue':
            if entry['major']['distortional_Nmm'] is None or entry['major']['distortional_Nmm'] <= 0:
                raise ValueError('O catálogo contém Ue sem crítico distorcional maior concluído.')
            if entry['minor']['status'] != 'computed':
                raise ValueError('O catálogo contém Ue com flexão menor não concluída.')
            for sign in ('pos', 'neg'):
                branch = entry['minor']['by_sign'][sign]
                if branch['status'] != 'computed' or branch['local_Nmm'] <= 0:
                    raise ValueError('O catálogo contém ramo local menor não concluído.')
                md = branch['distortional_Nmm']
                absent = branch['distortion_status'] == 'not_applicable'
                if (absent and md is not None) or (not absent and (md is None or md <= 0)):
                    raise ValueError('Estado distorcional inconsistente no catálogo.')
    return data


def entries():
    return deepcopy(_catalog()['entries'])


def entry_by_id(identifier):
    return deepcopy(next(item for item in _catalog()['entries'] if item['id'] == identifier))


def match_profile(profile):
    for entry in _catalog()['entries']:
        other = entry['profile']
        if profile['family'] == other['family'] and all(
            math.isclose(float(profile[field]), float(other[field]), rel_tol=0., abs_tol=1e-9)
            for field in PROFILE_FIELDS if field != 'family'
        ):
            return deepcopy(entry)
    return None


def _scale_moments(value: Any, factor: float) -> Any:
    """Geometry/lengths and modal identities stay fixed; elastic moments scale with E."""
    if isinstance(value, dict):
        return {key: (item*factor if key.endswith('_Nmm') and isinstance(item, (int, float))
                      else _scale_moments(item, factor)) for key, item in value.items()}
    if isinstance(value, list):
        return [_scale_moments(item, factor) for item in value]
    return value


def critical_data(profile, material):
    entry = match_profile(profile)
    reference = _catalog()['reference_material']
    if entry is None or not math.isclose(material['nu'], reference['nu'], abs_tol=1e-12, rel_tol=0.):
        return None
    if not math.isfinite(material['E_mpa']) or material['E_mpa'] <= 0:
        raise ValueError('E deve ser positivo e finito para consultar o catálogo.')
    factor = material['E_mpa']/reference['E_mpa']
    result: dict[str, Any] = {**entry, 'catalog_version': _catalog()['version'],
              'reference_material': deepcopy(reference), 'E_used_mpa': material['E_mpa'],
              'scale_E': factor, 'origin': 'precomputed_catalog'}
    for axis in ('major', 'minor'):
        if result[axis] is None:
            continue
        base = result[axis]
        result[axis] = _scale_moments(base, factor)
        # Keep the actual original trace distinct from the adopted scaled result.
        result[axis]['diagnostics'] = {'catalog_id': entry['id'], 'scale_E': factor,
                                       'reference_analysis': deepcopy(base.get('diagnostics', {}))}
        result[axis]['memory'] = [dict(row, title='Análise de referência do catálogo — '+row['title'])
                                  for row in base.get('memory', [])]
        result[axis]['origin'] = 'precomputed_catalog'
        result[axis]['method'] = 'Catálogo pré-calculado: '+base.get('method', '')
    result['memory'] = [dict(
        title='Perfil e críticos provenientes do catálogo',
        formula=r'M_{cr}(E)=M_{cr}(E_0)\frac{E}{E_0}',
        substitution=f"E0={reference['E_mpa']:g} MPa; E={material['E_mpa']:g} MPa; ν={reference['nu']:g}; fator={factor:.8g}.",
        result=f"{entry['label']} · registro {entry['id']} · catálogo {_catalog()['version']}. "
               'Raio, geometria e ν coincidem com a análise tabulada. Não há interpolação entre perfis. '
               'fy não altera os críticos elásticos. Os críticos locais maiores do catálogo são informativos: '
               'a resistência maior continua usando o MSE normativo implementado.',
        unit='', reference='NBR 14762:2010, 9.3 e Anexo C.2; análise elástica linear documentada no catálogo.')]
    return result
