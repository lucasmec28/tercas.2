"""Entradas portáveis e importação estrita de projetos, sem execução de conteúdo."""
from __future__ import annotations

import copy
import hashlib
import json
import math
from typing import Any

_DEFAULT: dict[str, Any] = {
    "schema_version": 6,
    "name": "Minha terça",
    "profile": {"family": "Ue", "h_mm": 200.0, "b_mm": 80.0, "d_mm": 30.0, "t_mm": 2.0, "r_mm": 2.0},
    "material": {"fy_mpa": 250.0, "fu_mpa": 400.0, "E_mpa": 200000.0, "G_mpa": 77000.0, "nu": 0.3, "density_kgm3": 7850.0},
    "tension": {"an0_mm2": None, "an_mm2": None, "ct": None},
    "member": {"L_m": 6.0, "angle_deg": 0.0, "restraint": "continuous", "Lb_m": 3.0, "load_at_shear_center": True, "end_fork": True, "warping_free": True, "mdist_major_kNm": None, "mdist_minor_kNm": None, "ndist_kN": None, "ml_minor_pos_kNm": None, "ml_minor_neg_kNm": None, "mdist_minor_pos_kNm": None, "mdist_minor_neg_kNm": None, "minor_critical_source": "", "minor_critical_mode": "automatic"},
    "loads": {"mode": "characteristic", "g_metal_kNm": 0.0373382519456324, "g_roof_kNm": 0.25, "q_kNm": 0.5, "wind_down_kNm": 0.0, "wind_up_kNm": 0.0, "point_kN": 0.0, "point_x_m": 3.0, "psi0_q": 0.8, "psi1_q": 0.7, "psi2_q": 0.6, "psi0_w": 0.6, "psi1_w": 0.3, "psi2_w": 0.0, "qd_normal_kNm": 1.2125, "qd_parallel_kNm": 0.0, "qs_normal_kNm": 0.85, "qs_parallel_kNm": 0.0, "nsd_kN": 0.0, "nser_kN": 0.0},
    "support": {"check": True, "c_mm": 100.0, "theta_deg": 90.0, "fastened": True},
    "panel": {"thickness_mm": 0.5, "rib_height_mm": 35.0, "rib_pitch_mm": 250.0, "fastener_mm": 5.5, "washer_mm": 12.5, "fastener_pitch_mm": 250.0, "near_center": True, "proven_stiffness": True},
    "limits": {"gravity_L": 180.0, "uplift_L": 120.0, "parallel_L": 180.0, "additional_checks": False},
}

# Requested calculation scope; imported older projects adopt this explicit
# policy while preserving all previously stored loads, geometry and exclusions.
_SCOPE_DEFAULTS = {
    'exclude_minor_distortion': True,
    'exclude_minor_shear': True,
    'deflection_ignore_restraints': True,
}
_DEFAULT['member'].update(_SCOPE_DEFAULTS)
_DEFAULT['member'].update(element_type='roof_purlin', Lx_m=6.0, Ly_m=6.0, Lz_m=6.0)
_DEFAULT['limits']['wall_wind_L'] = 120.0


def default_project() -> dict:
    return copy.deepcopy(_DEFAULT)


def _validate_shape(value: Any, template: Any, path: str) -> Any:
    if isinstance(template, dict):
        if not isinstance(value, dict):
            raise ValueError(f"{path or 'Projeto'} deve ser um objeto de dados.")
        unknown = set(value) - set(template)
        missing = set(template) - set(value)
        if unknown:
            raise ValueError(f"Campo não reconhecido em {path or 'projeto'}: {', '.join(sorted(unknown))}.")
        if missing:
            raise ValueError(f"Campo ausente em {path or 'projeto'}: {', '.join(sorted(missing))}.")
        return {key: _validate_shape(value[key], default, f"{path}.{key}".strip('.')) for key, default in template.items()}
    if isinstance(template, bool):
        if type(value) is not bool:
            raise ValueError(f"{path} deve ser verdadeiro ou falso.")
        return value
    if isinstance(template, str):
        maximum = 500 if path == 'member.minor_critical_source' else 160
        if not isinstance(value, str) or len(value) > maximum:
            raise ValueError(f"{path} deve ser um texto de até {maximum} caracteres.")
        return value
    if value is None and template is None:
        return None
    if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value):
        raise ValueError(f"{path} deve ser um número finito" + (" ou nulo." if template is None else "."))
    return value


def validate_project(project: dict) -> dict:
    """Confere o contrato e invariantes básicos; o motor confere o domínio normativo."""
    if isinstance(project, dict) and project.get('schema_version') == 1:
        project = copy.deepcopy(project)
        project['schema_version'] = 2
        if isinstance(project.get('member'), dict):
            for key in ('ml_minor_pos_kNm', 'ml_minor_neg_kNm', 'mdist_minor_pos_kNm',
                        'mdist_minor_neg_kNm', 'minor_critical_source'):
                project['member'].setdefault(key, _DEFAULT['member'][key])
    if isinstance(project, dict) and project.get('schema_version') == 2:
        project = copy.deepcopy(project)
        project['schema_version'] = 3
        if isinstance(project.get('member'), dict):
            # Existing calculations keep their explicitly supplied criticals.
            project['member'].setdefault('minor_critical_mode', 'manual')
    if isinstance(project, dict) and project.get('schema_version') == 3:
        project = copy.deepcopy(project)
        project['schema_version'] = 4
        if isinstance(project.get('limits'), dict):
            project['limits'].setdefault('additional_checks', False)
    if isinstance(project, dict) and project.get('schema_version') == 4:
        project = copy.deepcopy(project)
        project['schema_version'] = 5
        if isinstance(project.get('member'), dict):
            for key, default in _SCOPE_DEFAULTS.items():
                project['member'].setdefault(key, default)
    if isinstance(project, dict) and project.get('schema_version') == 5:
        project = copy.deepcopy(project)
        project['schema_version'] = 6
        if isinstance(project.get('member'), dict):
            project['member'].setdefault('element_type', 'roof_purlin')
            for key in ('Lx_m', 'Ly_m', 'Lz_m'):
                project['member'].setdefault(key, project['member'].get('L_m', 6.0))
        if isinstance(project.get('limits'), dict):
            project['limits'].setdefault('wall_wind_L', 120.0)
    p = _validate_shape(project, _DEFAULT, "")
    if p['schema_version'] != 6:
        raise ValueError("Versão de projeto não suportada. São aceitos projetos das versões 1 a 6.")
    if p['member']['element_type'] not in ('roof_purlin', 'wall_girt'):
        raise ValueError("Escolha terça de cobertura ou travessa de fechamento lateral.")
    if p['member']['minor_critical_mode'] not in ('automatic', 'manual'):
        raise ValueError("Escolha cálculo automático ou informação manual dos críticos do eixo menor.")
    if p['profile']['family'] not in ('U', 'Ue'):
        raise ValueError("Esta versão calcula perfis U e U enrijecido.")
    if p['member']['restraint'] not in ('continuous', 'none', 'discrete', 'panel', 'independent'):
        raise ValueError("Condição de contenção não reconhecida.")
    if p['loads']['mode'] not in ('characteristic', 'design'):
        raise ValueError("Escolha ações características ou cargas de cálculo informadas.")
    if not p['name'].strip():
        raise ValueError("Informe uma identificação para a terça.")
    for key in ('h_mm', 'b_mm', 't_mm'):
        if p['profile'][key] <= 0:
            raise ValueError(f"A dimensão {key} deve ser positiva.")
    if p['profile']['r_mm'] < 0 or p['profile']['d_mm'] < 0:
        raise ValueError("Raio interno e enrijecedor não podem ser negativos.")
    if p['profile']['family'] == 'U' and p['profile']['d_mm'] != 0:
        raise ValueError("Perfil U simples deve ter D = 0.")
    if p['profile']['family'] == 'Ue' and p['profile']['d_mm'] <= 0:
        raise ValueError("Informe o enrijecedor D do perfil Ue.")
    for key in ('fy_mpa', 'fu_mpa', 'E_mpa', 'G_mpa', 'density_kgm3'):
        if p['material'][key] <= 0:
            raise ValueError(f"A propriedade {key} deve ser positiva.")
    if p['material']['fu_mpa'] < p['material']['fy_mpa']:
        raise ValueError("fu não pode ser menor que fy.")
    for key, value in p['tension'].items():
        if value is not None and value <= 0:
            raise ValueError("As áreas líquidas e Ct devem ser positivos quando informados.")
    if p['tension']['ct'] is not None and p['tension']['ct'] > 1:
        raise ValueError("Ct não pode exceder 1.")
    if not 0 <= p['material']['nu'] < 0.5:
        raise ValueError("O coeficiente de Poisson deve estar entre zero e 0,5, exclusive.")
    L = p['member']['L_m']
    if not 0 < L <= 100:
        raise ValueError("O vão deve estar entre zero e 100 m, exclusive em zero.")
    if p['member']['Lb_m'] <= 0 or (p['member']['restraint'] != 'independent' and p['member']['Lb_m'] > L):
        raise ValueError("O comprimento entre contenções deve ser positivo e não exceder o vão.")
    for key in ('Lx_m', 'Ly_m', 'Lz_m'):
        value = p['member'][key]
        if value <= 0 or (p['member']['restraint'] == 'independent' and value > L):
            raise ValueError("Os comprimentos Lx, Ly e Lz devem ser positivos e, no modo independente com K = 1, não exceder o vão.")
    if abs(p['member']['angle_deg']) >= 90:
        raise ValueError("A inclinação deve estar entre −90° e +90°, exclusive.")
    for key in ('mdist_major_kNm', 'mdist_minor_kNm', 'ndist_kN', 'ml_minor_pos_kNm',
                'ml_minor_neg_kNm', 'mdist_minor_pos_kNm', 'mdist_minor_neg_kNm'):
        if p['member'][key] is not None and p['member'][key] <= 0:
            raise ValueError("Esforços críticos elásticos informados devem ser magnitudes positivas.")
    q = p['loads']
    for key in ('g_metal_kNm', 'g_roof_kNm', 'q_kNm', 'wind_down_kNm', 'wind_up_kNm', 'point_kN'):
        if q[key] < 0:
            raise ValueError(f"{key} deve ser não negativo; o sentido do vento é selecionado pelo campo correspondente.")
    if q['point_kN'] > 0 and not 0 < q['point_x_m'] < L:
        raise ValueError("A força pontual deve estar no interior do vão.")
    for suffix in ('q', 'w'):
        v = [q[f'psi{i}_{suffix}'] for i in range(3)]
        if not 1 >= v[0] >= v[1] >= v[2] >= 0:
            raise ValueError("Os fatores devem satisfazer 1 ≥ ψ0 ≥ ψ1 ≥ ψ2 ≥ 0.")
    if q['mode'] == 'characteristic' and (q['nsd_kN'] != 0 or q['nser_kN'] != 0):
        raise ValueError("Forças normais concomitantes são informadas no modo de cargas de cálculo.")
    if any(p['limits'][key] <= 0 for key in ('gravity_L', 'uplift_L', 'parallel_L', 'wall_wind_L')):
        raise ValueError("Os denominadores dos limites de flecha devem ser positivos.")
    if p['support']['c_mm'] <= 0:
        raise ValueError("O comprimento de contato do apoio deve ser positivo.")
    return p


def project_fingerprint(project: dict) -> str:
    encoded = json.dumps(project, sort_keys=True, separators=(',', ':'), allow_nan=False, ensure_ascii=False)
    return hashlib.sha256(encoded.encode('utf-8')).hexdigest()


def import_project_json(content: str | bytes) -> dict:
    if isinstance(content, bytes):
        if len(content) > 1_000_000:
            raise ValueError("O arquivo de projeto deve ter até 1 MB.")
        try:
            content = content.decode('utf-8-sig')
        except UnicodeError as exc:
            raise ValueError("Arquivo inválido. Use JSON com codificação UTF-8.") from exc
    if len(content) > 1_000_000:
        raise ValueError("O arquivo de projeto deve ter até 1 MB.")
    def reject_constant(value):
        raise ValueError(f"Número não finito no arquivo: {value}.")
    try:
        data = json.loads(content, parse_constant=reject_constant)
    except (json.JSONDecodeError, UnicodeError) as exc:
        raise ValueError("Arquivo inválido. Selecione um projeto JSON exportado pelo aplicativo.") from exc
    return validate_project(data)
