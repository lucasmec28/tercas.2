"""Memória HTML autônoma, com MathML nativo, e arquivos JSON portáveis."""
from __future__ import annotations

from datetime import datetime, timezone
from html import escape
import json
import math

from . import __version__
from .inputs import INPUTS, input_rows

STATUS = {'pass': 'Atende no modelo', 'fail': 'Não atende', 'pending': 'Verificação pendente', 'not_applicable': 'Não se aplica'}


def _fmt(value):
    if value is None:
        return '—'
    if isinstance(value, bool):
        return 'Sim' if value else 'Não'
    if isinstance(value, (float, int)):
        if not math.isfinite(value):
            return 'Indisponível'
        return f'{value:,.5g}'.replace(',', '_').replace('.', ',').replace('_', ' ')
    return str(value)


def project_json(project: dict) -> str:
    return json.dumps(project, ensure_ascii=False, indent=2, allow_nan=False)


def report_json(result: dict) -> str:
    return json.dumps(result, ensure_ascii=False, indent=2, allow_nan=False)


def _table(headers, rows):
    head = ''.join(f'<th>{escape(str(x))}</th>' for x in headers)
    body = ''.join('<tr>' + ''.join(f'<td>{escape(_fmt(x))}</td>' for x in row) + '</tr>' for row in rows)
    return f'<table><thead><tr>{head}</tr></thead><tbody>{body}</tbody></table>'


def _math(formula):
    if not formula:
        return ''
    try:
        from latex2mathml.converter import convert
        return '<div class="equation">' + convert(str(formula)) + '</div>'
    except (ValueError, IndexError, KeyError, TypeError, NotImplementedError, RuntimeError):
        return '<pre class="equation">' + escape(str(formula)) + '</pre>'


def _svg(z, values, title, unit, color='#126b79'):
    if not z or not values or len(z) != len(values):
        return ''
    if not all(isinstance(x, (int, float)) and math.isfinite(x) for x in [*z, *values]):
        return ''
    a, b = min(z), max(z)
    lo, hi = min(0, min(values)), max(0, max(values))
    if b <= a:
        return ''
    if hi - lo < 1e-10:
        hi, lo = 1, -1
    def xy(x, y):
        return 60 + (x-a)/(b-a)*770, 210 - (y-lo)/(hi-lo)*150
    points = ' '.join(f'{x:.2f},{y:.2f}' for x,y in (xy(x,y) for x,y in zip(z,values)))
    zero = xy(a, 0)[1]
    return f'''<figure><figcaption>{escape(title)} · {escape(unit)}</figcaption>
<svg viewBox="0 0 860 250" role="img" aria-label="{escape(title, quote=True)}">
<path d="M60 50V210H830" fill="none" stroke="#bcc6ce"/>
<line x1="60" y1="{zero:.2f}" x2="830" y2="{zero:.2f}" stroke="#bcc6ce"/>
<polyline points="{points}" fill="none" stroke="{color}" stroke-width="2.5"/>
<text x="10" y="65">{escape(_fmt(hi))}</text><text x="10" y="210">{escape(_fmt(lo))}</text>
<text x="55" y="236">{escape(_fmt(a))}</text><text x="780" y="236">{escape(_fmt(b))} m</text></svg></figure>'''


def report_html(result: dict) -> str:
    p = result['project']
    title = p.get('name', 'Cálculo de terça')
    status = result.get('overall_status', 'pending')
    parts = [f'<h1>{escape(title)}</h1>', '<p class="subtitle">Memória de cálculo de terça U ou U enrijecido · Base ABNT NBR 14762:2010</p>',
             f'<p><strong>{escape(STATUS.get(status, status))}</strong> · Versão do aplicativo {__version__}</p>',
             '<p>Os resultados se referem às ações, vínculos, geometria e verificações identificados nesta memória. O quadro de cobertura registra as verificações calculadas e as pendentes.</p>']
    limitations = result.get('limitations', [])
    if limitations:
        parts += ['<h2>Condições e pendências</h2>', _table(['Identificação','Descrição','Referência'], [[x.get('code',''),x.get('message',''),x.get('reference','')] for x in limitations])]
    checks = result.get('checks', [])
    parts += ['<h2>Verificações</h2>', _table(['Verificação','Caso','Situação','Solicitação','Resistência ou limite','Uso','Unidade','Referência'],
                [[x.get('label',''),x.get('case_id',''),STATUS.get(x.get('status'),x.get('status','')),x.get('demand'),x.get('capacity'),x.get('utilization'),x.get('unit',''),x.get('reference','')] for x in checks])]
    if result.get('service_cases'):
        parts += ['<h2>Deslocamentos de serviço</h2>', _table(['Caso','Situação','δx mm','Limite x mm','δy mm','Limite y mm','δvertical mm','Limite vertical mm','Observação'],
                   [[x.get('label',x.get('id','')),STATUS.get(x.get('status'),x.get('status','')),x.get('dx_mm'),x.get('limit_x_mm'),x.get('dy_mm'),x.get('limit_y_mm'),x.get('dvertical_mm'),x.get('limit_vertical_mm'),x.get('note','')] for x in result['service_cases']])]
    automatic = result.get('automatic_minor', {})
    if automatic.get('by_sign'):
        rows=[]
        for sign,item in automatic['by_sign'].items():
            ml,md=item.get('local_Nmm'),item.get('distortional_Nmm')
            rows.append(['My+' if sign=='pos' else 'My−',
                         ml/1e6 if ml is not None else None,
                         md/1e6 if md is not None else ('Não aplicável' if item.get('distortion_status')=='not_applicable' else 'Não determinado'),
                         item.get('local_half_wave_mm'),item.get('distortional_half_wave_mm'),item.get('note','')])
        parts += ['<h2>Momentos críticos calculados automaticamente</h2>',
                  '<p>'+escape(str(automatic.get('method','')))+' · '+escape(str(automatic.get('reference','')))+'</p>',
                  _table(['Sentido','Mℓ [kN·m]','Mdist [kN·m]','Semionda local [mm]','Semionda distorcional [mm]','Observação'],rows)]
    parts.append('<h2>Entradas adotadas</h2>')
    labels={'profile':'Seção transversal','material':'Aço','tension':'Tração e áreas líquidas','member':'Vão e contenções','loads':'Ações','support':'Apoios','panel':'Painel conectado','limits':'Limites de deslocamento'}
    for key,label in labels.items():
        parts.append(f'<h3>{label}</h3>')
        parts.append(_table(['Variável','Valor'],[(INPUTS.get(f'{key}.{k}', (k,''))[0],v) for k,v in p.get(key,{}).items()]))
    sec = result.get('section', {})
    properties=[('A','Área','mm²'),('Ix','Inércia maior','mm⁴'),('Iy','Inércia menor','mm⁴'),('Wx','Módulo no eixo maior','mm³'),('J','Constante de torção','mm⁴'),('Cw','Constante de empenamento','mm⁶'),('xsc','Centro de torção relativo ao centroide','mm'),('mass','Massa por comprimento','kg/m'),('pp','Peso próprio','kN/m')]
    parts += ['<h2>Propriedades da seção</h2>',_table(['Símbolo','Propriedade','Valor','Unidade'], [[k,desc,sec.get(k),unit] for k,desc,unit in properties])]
    parts += ['<h2>Combinações</h2>',_table(['Caso','Tipo','Descrição','qx kN/m','qy kN/m','Px kN','Py kN','Nsd kN'],
        [[x.get('id',''),x.get('kind',''),x.get('description',x.get('label','')),x.get('qx_kNm'),x.get('qy_kNm'),x.get('px_kN'),x.get('py_kN'),x.get('nsd_kN')] for x in result.get('combinations',[])])]
    diagrams=result.get('diagrams',[])
    governing=(result.get('governing') or {}).get('case_id')
    selected=next((d for d in diagrams if d.get('case_id')==governing),diagrams[0] if diagrams else None)
    if selected:
        parts += ['<h2>Diagramas do caso selecionado</h2>',f'<p>{escape(str(selected.get("label",selected.get("case_id",""))))} · {escape(str(selected.get("analysis_type","primeira ordem")))}</p>']
        for key,label,unit in [('Mx_kNm','Momento no eixo maior','kN·m'),('My_kNm','Momento no eixo menor','kN·m'),('Vy_kN','Cortante na alma','kN'),('dy_mm','Deslocamento normal','mm'),('dx_mm','Deslocamento paralelo','mm')]:
            parts.append(_svg(selected.get('z_m',[]),selected.get(key,[]),label,unit))
    parts.append('<h2>Equações e referências</h2>')
    for m in result.get('memory',[]):
        parts += [f'<h3>{escape(str(m.get("title","Cálculo")))}</h3>',_math(m.get('formula')),_math(m.get('substitution')),
                  f'<p><strong>Resultado:</strong> {escape(_fmt(m.get("result")))} {escape(str(m.get("unit","")))}</p>',f'<p class="reference">{escape(str(m.get("reference","")))}</p>']
    parts += ['<h2>Cobertura desta verificação</h2>',_table(['Verificação','Situação','Condição','Referência'],[[x.get('verification',''),STATUS.get(x.get('status'),x.get('status','')),x.get('note',''),x.get('reference','')] for x in result.get('coverage',[])])]
    parts += ['<h2>Variáveis de entrada e suas descrições</h2>', _table(['Variável','Valor adotado','Descrição'], [[row['variável'],row['valor'],row['descrição']] for row in input_rows(p)])]
    generated=datetime.now(timezone.utc).isoformat(timespec='seconds')
    parts.append(f'<p class="reference">Memória gerada em {escape(generated)}. As páginas e os itens citados correspondem à edição normativa indicada. Os valores de entrada e os resultados completos estão disponíveis no arquivo JSON da análise.</p>')
    return '''<!doctype html><html lang="pt-BR"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>''' + escape(title) + '''</title><style>
body{max-width:1120px;margin:40px auto;padding:0 24px;font:15px/1.55 system-ui,sans-serif;color:#172b3a;background:white}h1{font-size:30px;line-height:1.15}h2{margin-top:34px;font-size:21px}h3{margin-top:22px;font-size:16px}.subtitle,.reference{color:#526571}.reference{font-size:12px}table{border-collapse:collapse;width:100%;margin:12px 0 22px;font-size:12px}th,td{border:1px solid #d9dfe4;padding:8px;text-align:left;overflow-wrap:anywhere}th{background:#183b4e;color:white}tr:nth-child(even){background:#f2f5f7}thead{display:table-header-group}tr{break-inside:avoid}.equation{overflow:auto;padding:8px 0;font-size:16px}math{font-family:Cambria Math,STIX Two Math,serif}figure{margin:18px 0;break-inside:avoid}svg{width:100%;max-height:260px;font:12px system-ui}figcaption{font-weight:600}h2,h3{break-after:avoid}@media print{body{max-width:none;margin:0;font-size:10pt}table{font-size:8pt}h1{font-size:23pt}h2{font-size:15pt}h3{font-size:11pt}.equation{overflow:visible}a{color:inherit} @page{size:A4;margin:16mm}}
</style></head><body>''' + ''.join(parts) + '</body></html>'
