"""Elastic major-axis local/distortional moments for symmetric Ue sections.

The corrected physical G/D basis is shared with the minor-axis provider.
Only the longitudinal stress distribution is overridden: sigma = Mx
(y-yc)/Ixx, with each model's own Ixx. The same audited finite-strip matrices
and modal subspaces are reused.
This provider does not calculate member resistance or assign catalogue data.
"""
from __future__ import annotations

from copy import deepcopy
from functools import lru_cache
from importlib.metadata import version
import math
from time import perf_counter
import warnings

import numpy as np
from threadpoolctl import threadpool_limits

from .critical_minor import (
    GLOBAL_SEPARATION, MOMENT_TOLERANCE, SAMPLE_COUNT, WAVE_TOLERANCE,
    _LOCK, _Solver, _difference, _select,
)
from pycufsm.solve.analysis import analysis
from .physical_basis import BASIS_VERSION


REFERENCE = "Li (2011), 6.2.2; AISI RP21-01 (2021), Exemplo I, p. 8; NBR 14762:2010, 9.8.2.3 e Anexo C.2."
METHOD = "Flexão maior Mx: FSM arredondado com famílias local/distorcional identificadas em modelo cFSM auxiliar de cantos retos."
CFSM_SYMMETRY_TOLERANCE = 1e-4
FSM_SYMMETRY_TOLERANCE = 1e-6


class MajorSolver(_Solver):
    """Same geometry and bases as My; independent major-axis stress field."""

    def matrices(self, wave, sign):
        nodes = self.nodes.copy()
        nodes[:,7] = sign*1e6*(nodes[:,2]-self.section['cy'])/self.section['Ixx']
        return analysis.k_kg_global(nodes,self.elements,self.el_props,self.props,wave,'S-S',np.array([1]))


def _major_level(geometry,E,nu,divisions,angle):
    h = geometry[0]
    sharp = MajorSolver(geometry,E,nu,h/divisions,angle)
    rounded = MajorSolver(geometry,E,nu,h/divisions,angle,rounded=True)
    families = {}
    for family in ('local','dist'):
        minima = sharp.minima(1,family)
        if len(minima)!=1:
            raise ValueError(f"O ramo {family} da flexão maior não apresenta um único mínimo interior; exige análise modal externa.")
        families[family] = minima[0]
    conventional = rounded.minima(1,'all')
    selected = {
        'local':_select(rounded,1,'local',families['local'],families['dist'],conventional),
        'distortional':_select(rounded,1,'dist',families['dist'],families['local'],conventional),
    }
    guards,symmetry = [],[]
    for family,label in (('local','local'),('dist','distortional')):
        item = selected[label]
        for origin,wave in (('cfsm',item['cfsm_half_wave_mm']),('adopted',item['wave_mm'])):
            global_value = sharp.critical(wave,1,'global')
            pure = sharp.critical(wave,1,family)
            ratio = None if global_value is None or pure is None else global_value/pure
            guards.append({'family':label,'wave_source':origin,'wave_mm':wave,
                           'global_pure_Nmm':None if global_value is None else global_value*1e6,
                           'family_pure_Nmm':None if pure is None else pure*1e6,
                           'ratio_global_to_family':ratio,
                           'passed':bool(pure is not None and (global_value is None or (ratio is not None and ratio>1+GLOBAL_SEPARATION)))})
            for model,solver,mode in (('sharp',sharp,family),('rounded',rounded,'all')):
                positive,negative = solver.critical(wave,1,mode),solver.critical(wave,-1,mode)
                difference = None if positive is None or negative is None else abs(positive-negative)/max(positive,negative)
                tolerance = CFSM_SYMMETRY_TOLERANCE if model=='sharp' else FSM_SYMMETRY_TOLERANCE
                symmetry.append({'model':model,'family':label,'wave_source':origin,'wave_mm':wave,
                                 'positive_Nmm':None if positive is None else positive*1e6,
                                 'negative_Nmm':None if negative is None else negative*1e6,
                                 'relative_difference':difference,'tolerance':tolerance,
                                 'passed':bool(difference is not None and difference<=tolerance)})
    return {'strip_width_mm':h/divisions,'corner_angle_deg':angle,
            'sharp_nodes':len(sharp.nodes),'rounded_nodes':len(rounded.nodes),
            'half_wave_range_mm':[.05*h,100*h],'signature_samples':SAMPLE_COUNT,
            'rounded_area_mm2':float(rounded.section['A']),
            'rounded_Ix_mm4':float(rounded.section['Ixx']),
            'physical_basis':sharp.basis_audit,
            'selected':selected,'rounded_stationary_minima':conventional,
            'global_separation_checks':guards,'symmetry_checks':symmetry}


@lru_cache(maxsize=16)
def _cached_major(geometry,E,nu):
    started = perf_counter()
    with _LOCK,threadpool_limits(limits=1,user_api='blas'),warnings.catch_warnings():
        warnings.simplefilter('ignore',DeprecationWarning)
        levels = [_major_level(geometry,E,nu,20,15),_major_level(geometry,E,nu,40,7.5)]
    convergence,selected = {},{}
    passed = True
    reasons = []
    for family in ('local','distortional'):
        a,b = [level['selected'][family] for level in levels]
        dm,dw = _difference(a,b,'moment_Nmm'),_difference(a,b,'wave_mm')
        good = dm<=MOMENT_TOLERANCE and dw<=WAVE_TOLERANCE
        convergence[family] = {'moment_relative_change':dm,'wave_relative_change':dw,'passed':bool(good)}
        selected[family] = min((a,b),key=lambda item:item['moment_Nmm'])
        if not good:
            passed = False
            reasons.append(f"O ramo {family} excedeu a tolerância de convergência entre malhas.")
    if not all(check['passed'] for level in levels for check in level['global_separation_checks']):
        passed = False
        reasons.append("Há competição com a família global: a separação mínima de 5% não foi satisfeita; exige identificação modal externa.")
    symmetry_verified = all(check['passed'] for level in levels for check in level['symmetry_checks'])
    if not symmetry_verified:
        passed = False
        reasons.append("A equivalência numérica entre Mx+ e Mx− não foi confirmada.")
    local,dist = selected['local'],selected['distortional']
    memory = [
        {'title':'Momentos críticos automáticos no eixo maior',
         'formula':r'\sigma_i=\pm\frac{10^6(y_i-y_c)}{I_x}',
         'substitution':'Momento de referência de 1 kN·m. Cada malha usa seu próprio centroide e sua inércia Ix.',
         'result':METHOD+' Os momentos críticos não são copiados da flexão menor. A equivalência Mx+/Mx− é conferida pela simetria da seção.',
         'unit':'N, mm, MPa','reference':REFERENCE},
        {'title':'Base física das famílias global e distorcional',
         'formula':r'G_y=\operatorname{span}\{1,y,x,\omega\},\quad G_y^T R_{yd}D_y=0',
         'substitution':'Coordenada setorial integrada ao longo da cadeia aberta; compatibilidade T u=−dv/ds nos dois tangentes adjacentes de cada canto.',
         'result':'Quatro deformações globais e duas distorcionais independentes, com ortogonalidade pela métrica de área. Identidades cinemáticas e simetria são verificadas; o momento adotado é obtido da curva FSM completa.',
         'unit':'','reference':REFERENCE},
        {'title':'Convergência dos críticos de flexão maior','formula':None,
         'substitution':'Malhas h/20 e h/40, mínimo de 2 faixas por trecho reto, arcos de 15° e 7,5°, 31 semiondas iniciais entre 0,05h e 100h.',
         'result':f"{convergence}. Aceitação: variação de até 1% no momento e 5% na semionda. Usa-se o menor momento convergido, sem multiplicador adicional.",
         'unit':'','reference':REFERENCE},
        {'title':'Simetria dos sentidos de flexão maior',
         'formula':r'\frac{|M_+-M_-|}{\max(M_+,M_-)}\leq\varepsilon',
         'substitution':'ε=10⁻⁴ (0,01%) para autovalores cFSM puros; ε=10⁻⁶ (0,0001%) para o FSM completo.',
         'result':'A condensação auxiliar cFSM usa penalização elevada e pode amplificar arredondamento numérico. As tolerâncias distintas foram verificadas por montagem Python independente das mesmas matrizes; cada comparação registra seu resíduo e limite. Não alteram as guardas globais nem os critérios de convergência entre malhas.',
         'unit':'','reference':REFERENCE},
    ]
    for i,level in enumerate(levels,1):
        descriptions = []
        for check in level['global_separation_checks']:
            g = 'sem autovalor positivo' if check['global_pure_Nmm'] is None else f"{check['global_pure_Nmm']/1e6:.6g} kN·m"
            f = 'não determinado' if check['family_pure_Nmm'] is None else f"{check['family_pure_Nmm']/1e6:.6g} kN·m"
            ratio = 'não se aplica' if check['ratio_global_to_family'] is None else f"{check['ratio_global_to_family']:.6g}"
            descriptions.append(f"{check['family']}, {check['wave_source']}={check['wave_mm']:.6g} mm: G={g}; família={f}; razão={ratio}.")
        memory.append({'title':f'Separação global da flexão maior — malha {i}','formula':None,
                       'substitution':'G/família >1,05 na semionda cFSM e na semionda adotada.',
                       'result':' '.join(descriptions)+' O limite de 5% é da implementação; não é prescrição normativa nem demonstração de ausência de interação. Os modos FSM completos permanecem acoplados.',
                       'unit':'kN·m, mm','reference':REFERENCE})
    local_text = f"{local['moment_Nmm']/1e6:.6g} kN·m" if passed else 'não determinado'
    dist_text = f"{dist['moment_Nmm']/1e6:.6g} kN·m" if passed else 'não determinado'
    memory.append({'title':'Críticos de flexão maior disponíveis para dimensionamento','formula':None,
                   'substitution':'Mx+ e Mx− de seção Ue simétrica; momento puro uniforme.',
                   'result':f'Mlocal,x={local_text}; Mdist,x={dist_text}. '+('Cálculo elástico concluído.' if passed else ' '.join(reasons)),
                   'unit':'kN·m','reference':REFERENCE})
    return {'status':'computed' if passed else 'pending','axis':'x',
            'local_Nmm':local['moment_Nmm'] if passed else None,
            'distortional_Nmm':dist['moment_Nmm'] if passed else None,
            'distortion_status':'computed' if passed else 'pending',
            'local_half_wave_mm':local['wave_mm'],'distortional_half_wave_mm':dist['wave_mm'],
            'bending_symmetry_verified':bool(symmetry_verified),'convergence':convergence,
            'selected':selected,'note':None if passed else ' '.join(reasons),
            'method':METHOD,'reference':REFERENCE,'memory':memory,
            'diagnostics':{'levels':levels,'E_MPa':E,'nu':nu,'G_plate_MPa':E/(2*(1+nu)),
                           'physical_basis_version':BASIS_VERSION,
                           'versions':{name:version(name) for name in ('pycufsm','numpy','scipy')},
                           'elapsed_seconds':perf_counter()-started,'moment_tolerance':MOMENT_TOLERANCE,
                           'wave_tolerance':WAVE_TOLERANCE,'global_separation_margin':GLOBAL_SEPARATION,
                           'symmetry_tolerances':{'cfsm_pure':CFSM_SYMMETRY_TOLERANCE,'fsm_full':FSM_SYMMETRY_TOLERANCE},
                           'load_case':'Momento puro uniforme Mx em Ue simétrico de chapa isotrópica, sem furos e com lábios de 90°.'}}


def critical_major_moments(profile,material):
    """Return numerical Mlocal,x and Mdist,x; only computed data may be adopted.

    The two major-moment signs share magnitudes only after the numerical
    reflection-symmetry check. Cache key excludes fy, span and restraints.
    """
    try:
        if profile.get('family')!='Ue':
            raise ValueError("O cálculo distorcional automático de Mx é exclusivo de Ue simétrico; perfis U simples mantêm sua rota normativa própria.")
        geometry = tuple(float(profile[key]) for key in ('h_mm','b_mm','d_mm','t_mm','r_mm'))
        E,nu = float(material['E_mpa']),float(material['nu'])
        if not all(math.isfinite(v) for v in (*geometry,E,nu)):
            raise ValueError("Geometria e constantes elásticas devem ser finitas.")
        h,b,d,t,ri = geometry
        if min(h,b,d,t,E)<=0 or ri<0 or not 0<=nu<.5:
            raise ValueError("Geometria ou constantes elásticas inválidas.")
        if min(h-2*(ri+t),b-2*(ri+t),d-ri-t)<=0 or 2*d>=h:
            raise ValueError("Dimensões incompatíveis: trechos retos não positivos ou enrijecedores sobrepostos.")
        return deepcopy(_cached_major(geometry,E,nu))
    except (ValueError,ArithmeticError,np.linalg.LinAlgError) as exc:
        return {'status':'pending','axis':'x','local_Nmm':None,'distortional_Nmm':None,
                'distortion_status':'pending','method':METHOD,'reference':REFERENCE,'note':str(exc),
                'diagnostics':{'error_type':type(exc).__name__},
                'memory':[{'title':'Críticos de flexão maior pendentes','formula':None,'substitution':None,
                           'result':str(exc),'unit':'','reference':REFERENCE}]}


def clear_cache():
    with _LOCK:
        _cached_major.cache_clear()
