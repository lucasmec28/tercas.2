"""Effective flat plate bands, with explicitly bounded MLE branches."""
from __future__ import annotations
import math
import numpy as np
from .sections import from_raw, plate_raw


class PlateDomainError(ValueError):
    """The supplied state requires a plate branch not covered here."""


def reduction(lp):
    return 1.0 if lp <= .673 else (1-.22/lp)/lp


def stress_coefficients(section, gross, mx, my, normal=0.0):
    """Moments supplied about the gross centroid; compression is positive."""
    mx_eff = mx+normal*(gross['yc']-section['yc'])
    my_eff = my+normal*(gross['xc']-section['xc'])
    determinant = section['Ix']*section['Iy']-section['Ixy']**2
    aa = (my_eff*section['Ix']-mx_eff*section['Ixy'])/determinant
    bb = (mx_eff*section['Iy']-my_eff*section['Ixy'])/determinant
    cc = normal/section['A']-aa*section['xc']-bb*section['yc']
    return cc, aa, bb


def stress(coeff, point):
    return coeff[0]+coeff[1]*point[0]+coeff[2]*point[1]


def _merge(intervals, width):
    intervals = sorted((max(0., a), min(width, b)) for a, b in intervals if b-a > 1e-12)
    out = []
    for a, b in intervals:
        if out and a <= out[-1][1]+1e-9:
            out[-1] = (out[-1][0], max(b, out[-1][1]))
        else:
            out.append((a, b))
    return out


def effective_intervals(plate, sa, sb, E, t):
    """Lengths measured from plate.a (the supported edge for an AL plate)."""
    width, kind = plate['width'], plate['kind']
    maximum = max(sa, sb)
    detail = dict(id=plate['id'], sigma_a=sa, sigma_b=sb, width=width)
    if maximum <= 1e-10:
        return [(0., width)], dict(detail, k=None, lambda_p=0., rho=1., method='tension')
    if width/t > (500 if kind == 'AA' else 60)+1e-9:
        raise PlateDomainError(f"{plate['id']}: largura/espessura fora da Tabela 4 para o elemento comprimido.")
    if kind == 'LIPPED':
        raise PlateDomainError('Mesa enrijecida exige a verificação específica de 9.2.3.')
    psi = min(sa, sb)/maximum
    if kind == 'AA':
        k = 4. if abs(sa-sb) <= 1e-9*maximum else 4+2*(1-psi)+2*(1-psi)**3
        lp = (width/t)/(.95*math.sqrt(k*E/maximum))
        rho = reduction(lp)
        if rho >= 1-1e-12:
            bands = [(0., width)]
        else:
            be = rho*width
            if abs(sa-sb) <= 1e-9*maximum:
                first = second = be/2
            else:
                first = be/(3-psi)
                second = be-first if psi > -.236 else be/2
            bc = width if psi >= 0 else width/(1-psi)
            if first+second >= bc:
                bands = [(0., width)]
            else:
                bands = [(0., first), (bc-second, width)]
            if sb > sa:
                bands = [(width-b, width-a) for a, b in bands]
    else:
        # Table 6 does not permit extrapolating psi < -1. A uniform maximum
        # compression bound can nevertheless prove the WHOLE plate effective.
        if psi < -1-1e-10:
            k = .43
            lp = (width/t)/(.95*math.sqrt(k*E/maximum))
            if lp > .673:
                raise PlateDomainError(f"{plate['id']}: ψ={psi:.4g} fora da Tabela 6; a hipótese uniforme também não comprova efetividade integral.")
            return [(0., width)], dict(detail, psi=psi, k=k, lambda_p=lp, rho=1., method='uniform_upper_bound')
        psi = max(-1., min(1., psi))
        if abs(sa-sb) <= 1e-9*maximum:
            k = .43
        elif sb >= sa:
            k = .57-.21*psi+.07*psi*psi
        elif psi >= 0:
            k = .578/(psi+.34)
        else:
            k = 1.7-5*psi+17.1*psi*psi
        lp = (width/t)/(.95*math.sqrt(k*E/maximum))
        rho = reduction(lp)
        bc = width if psi >= 0 else width/(1-psi)
        be = rho*bc
        if rho >= 1-1e-12:
            bands = [(0., width)]
        elif sb >= sa:  # free edge most compressed; retain next to support/NA
            bands = [(0., width-bc+be)]
        else:
            bands = [(0., be)]
            if psi < 0:
                bands.append((bc, width))
    return _merge(bands, width), dict(detail, psi=psi, k=k, lambda_p=lp, rho=rho, method='Table5' if kind == 'AA' else 'Table6')


def retained_raw(props, bands):
    raw = np.array(props['raw_moments'], dtype=float)
    for plate, intervals in zip(props['plates'], bands):
        a, b = np.array(plate['a']), np.array(plate['b'])
        raw -= plate_raw(a, b, props['t'])
        unit = (b-a)/plate['width']
        for start, end in intervals:
            raw += plate_raw(a+start*unit, a+end*unit, props['t'])
    return raw


def effective_u(props, material, mx, my, normal=0., *, reference_stress=None, compression_only=False):
    """Joint MLE for a simple U. Optional stress controller is for pure My.

    The original outer fibres are used as reference, including discarded
    flat material. This is a conservative effective-width implementation.
    """
    if props['family'] != 'U':
        raise PlateDomainError('O MLE com redução de bandas está implementado para U simples.')
    raw = np.array(props['raw_moments'], dtype=float)
    E, t = float(material['E_mpa']), props['t']
    if props['h']/t > 200+1e-9:
        raise PlateDomainError('Alma de viga sem enrijecedores: h/t excede 200 (Tabela 4).')
    scales = np.array([props['A'], props['A']*props['H'], props['A']*props['H'], props['Ix'], props['Iy']+props['A']*props['xc']**2, math.sqrt(props['Ix']*props['Iy'])])
    final_load = (mx, my, normal)
    for iteration in range(1, 301):
        geom = from_raw(raw)
        coeff = stress_coefficients(geom, props, mx, my, normal)
        if reference_stress is not None:
            if mx != 0 or normal != 0 or my == 0:
                raise ValueError('O controle por tensão é exclusivo da flexão menor sem força normal.')
            values = [stress(coeff, (-t/2, 0)), stress(coeff, (props['B']-t/2, 0))]
            peak = max(values) if compression_only else max(abs(v) for v in values)
            if peak <= 0:
                raise PlateDomainError('Fibra de referência comprimida não encontrada.')
            factor = reference_stress/peak
            final_load = (0., my*factor, 0.)
            coeff = stress_coefficients(geom, props, *final_load)
        else:
            final_load = (mx, my, normal)
        bands, details = [], []
        for plate in props['plates']:
            sa, sb = stress(coeff, plate['a']), stress(coeff, plate['b'])
            if plate['id'] == 'web' and abs(sa-sb) <= 1e-8*max(1., abs(sa), abs(sb)) and max(sa, sb) > 0 and plate['width']/t > 90+1e-9:
                raise PlateDomainError('Alma de U simples sob compressão uniforme: h/t excede 90 (Tabela 4).')
            intervals, detail = effective_intervals(plate, sa, sb, E, t)
            bands.append(intervals)
            details.append(detail)
        candidate = retained_raw(props, bands)
        error = float(np.max(np.abs(candidate-raw)/np.maximum(scales, 1.)))
        if error < 1e-9:
            geom = from_raw(candidate)
            geom.update(converged=True, method='MLE_joint_U', iterations=iteration,
                        plates=details, retained_intervals=[[[float(a), float(b)] for a,b in intervals] for intervals in bands],
                        moment_Nmm=abs(final_load[1]), raw_moments=[float(v) for v in candidate])
            return geom
        # Relax only the iteration; the returned section consists of full
        # retained rectangles and corners, not fractional fictitious plates.
        raw = .65*candidate+.35*raw
    raise PlateDomainError('MLE conjunto não convergiu em 300 iterações; a rigidez não foi validada.')


def prove_gross_lipped(props, material, mx, my, normal=0.):
    """Conservative full-area proof only; no reduced Ue biaxial assumption."""
    coeff = stress_coefficients(props, props, mx, my, normal)
    E, t = float(material['E_mpa']), props['t']
    details = []
    for plate in props['plates']:
        sa, sb = stress(coeff, plate['a']), stress(coeff, plate['b'])
        if max(sa, sb) <= 1e-10:
            details.append(dict(id=plate['id'], sigma_a=sa, sigma_b=sb, rho=1., method='tension'))
            continue
        if plate['kind'] != 'LIPPED':
            bands, detail = effective_intervals(plate, sa, sb, E, t)
            if sum(b-a for a,b in bands) < plate['width']*(1-1e-9):
                raise PlateDomainError(f"{plate['id']}: exige redução de área; o MLE conjunto reduzido para Ue não está implementado.")
            details.append(detail)
            continue
        # Maximum through the whole flange thickness, not merely centreline.
        a, b = plate['a'], plate['b']
        sigma = max(stress(coeff, (xx, yy)) for xx in (a[0], b[0]) for yy in (a[1]-t/2, a[1]+t/2))
        width = plate['width']
        if width/t > 60+1e-9:
            raise PlateDomainError('Mesa enrijecida: b/t excede 60 (Tabela 4).')
        lp0 = (width/t)/(.623*math.sqrt(E/sigma))
        eta = 1.
        if lp0 <= .673:
            k, lp = None, 0.
        else:
            ratio = props['D']/width
            if ratio > .8+1e-10:
                raise PlateDomainError('Mesa enrijecida: D/b excede o domínio 0,8 de 9.2.3.')
            Is = t*props['d']**3/12
            Ia = min(399*t**4*(.487*lp0-.328)**3, t**4*(56*lp0+5))
            eta = min(Is/Ia, 1.)
            exponent = max(.582-.122*lp0, 1/3)
            k = min((3.57 if ratio <= .25 else 4.82-5*ratio)*eta**exponent+.43, 4.)
            lp = (width/t)/(.95*math.sqrt(k*E/sigma))
        if lp > .673 or eta < 1-1e-9:
            raise PlateDomainError('Mesa/enrijecedor do Ue exige redução efetiva sob os esforços conjuntos; a versão não substitui isso por inércia bruta.')
        details.append(dict(id=plate['id'], sigma_a=sa, sigma_b=sb, sigma_bound=sigma,
                            lambda_p0=lp0, lambda_p=lp, eta_s=eta, k=k, rho=1., method='uniform_upper_bound_9.2.3'))
    return dict(A=props['A'], Ix=props['Ix'], Iy=props['Iy'], Ixy=0., xc=props['xc'], yc=0.,
                determinant=props['Ix']*props['Iy'], converged=True, method='gross_MLE_verified', plates=details)
