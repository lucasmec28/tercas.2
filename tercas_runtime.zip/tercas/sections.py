"""Rounded U/Ue sections. Units: N, mm, MPa; external nominal dimensions.

Area moments integrate rectangles and annular bends. J, Cw and the shear
centre use the open thin-wall centreline approximation (not eigenvalues).
"""
from __future__ import annotations

from functools import lru_cache
import math
from copy import deepcopy
import numpy as np


def _number(value, name, *, positive=False, nonnegative=False):
    if isinstance(value, bool):
        raise ValueError(f"{name} deve ser um número finito.")
    try:
        value = float(value)
    except (TypeError, ValueError) as exc:
        raise ValueError(f"{name} deve ser um número finito.") from exc
    if not math.isfinite(value) or (positive and value <= 0) or (nonnegative and value < 0):
        raise ValueError(f"{name} deve ser finito e respeitar seu intervalo físico.")
    return value


def plate_raw(a, b, thickness):
    """A, Sx, Sy, integral(y²), integral(x²), integral(xy) of a flat band."""
    x, y = (a[0] + b[0]) / 2, (a[1] + b[1]) / 2
    dx, dy = b[0] - a[0], b[1] - a[1]
    length = math.hypot(dx, dy)
    if length <= 1e-12:
        return np.zeros(6)
    ux, uy = dx / length, dy / length
    area = thickness * length
    ixx = area * (length * length * uy * uy + thickness * thickness * ux * ux) / 12
    iyy = area * (length * length * ux * ux + thickness * thickness * uy * uy) / 12
    ixy = area * (length * length - thickness * thickness) * ux * uy / 12
    return np.array([area, area*x, area*y, ixx+area*y*y,
                     iyy+area*x*x, ixy+area*x*y])


def from_raw(raw):
    a, sx, sy, ix0, iy0, ixy0 = map(float, raw)
    if a <= 0:
        raise ValueError("A seção efetiva perdeu toda a área.")
    xc, yc = sx/a, sy/a
    ix, iy, ixy = ix0-a*yc*yc, iy0-a*xc*xc, ixy0-a*xc*yc
    determinant = ix*iy-ixy*ixy
    if ix <= 0 or iy <= 0 or determinant <= 0:
        raise ValueError("A matriz de inércia da seção é singular ou inválida.")
    return dict(A=a, xc=xc, yc=yc, Ix=ix, Iy=iy, Ixy=ixy, determinant=determinant)


@lru_cache(maxsize=256)
def _geometry(family, H, B, D, t, ri):
    r = ri+t/2
    ym = (H-t)/2
    xm = B-t if family == 'Ue' else B-t/2
    h = H-2*(ri+t)
    b = B-2*(ri+t) if family == 'Ue' else B-(ri+t)
    d = D-(ri+t) if family == 'Ue' else 0.0
    if h <= 0 or b <= 0 or (family == 'Ue' and (d <= 0 or 2*D >= H)):
        raise ValueError("Dimensões incompatíveis: as partes planas devem ser positivas e os enrijecedores não podem se encontrar.")
    parts = []
    def line(a, b): parts.append(('line', a, b))
    def arc(c, a, b): parts.append(('arc', c, (a, b)))
    if family == 'Ue':
        line((xm, H/2-D), (xm, ym-r))
        arc((xm-r, ym-r), 0, math.pi/2)
        line((xm-r, ym), (r, ym))
    else:
        line((xm, ym), (r, ym))
    arc((r, ym-r), math.pi/2, math.pi)
    line((0, ym-r), (0, -ym+r))
    arc((r, -ym+r), math.pi, 3*math.pi/2)
    if family == 'Ue':
        line((r, -ym), (xm-r, -ym))
        arc((xm-r, -ym+r), 3*math.pi/2, 2*math.pi)
        line((xm, -ym+r), (xm, -H/2+D))
    else:
        line((r, -ym), (xm, -ym))
    gp, gw = np.polynomial.legendre.leggauss(32)
    vp, vw = np.polynomial.legendre.leggauss(5)
    centre, area = [], []
    omega = length = 0.0
    for kind, a, z in parts:
        if kind == 'line':
            dx, dy = z[0]-a[0], z[1]-a[1]
            ell = math.hypot(dx, dy)
            for u, weight in zip((gp+1)/2, gw/2):
                xx, yy = a[0]+u*dx, a[1]+u*dy
                om = omega+u*(a[0]*dy-a[1]*dx)
                centre.append((xx, yy, ell*weight*t, om))
                for v, wv in zip(vp*t/2, vw*t/2):
                    area.append((xx-v*dy/ell, yy+v*dx/ell, ell*weight*wv))
            omega += a[0]*dy-a[1]*dx
        else:
            th0, th1 = z
            dth = th1-th0
            ell = r*dth
            for th, weight in zip(th0+(gp+1)/2*dth, gw/2*dth):
                cs, sn = math.cos(th), math.sin(th)
                xx, yy = a[0]+r*cs, a[1]+r*sn
                om = omega+a[0]*r*(sn-math.sin(th0))-a[1]*r*(cs-math.cos(th0))+r*r*(th-th0)
                centre.append((xx, yy, r*weight*t, om))
                for v, wv in zip(vp*t/2, vw*t/2):
                    area.append((a[0]+(r+v)*cs, a[1]+(r+v)*sn, (r+v)*weight*wv))
            omega += a[0]*r*(math.sin(th1)-math.sin(th0))-a[1]*r*(math.cos(th1)-math.cos(th0))+r*r*dth
        length += ell
    ar = np.array(area)
    x, y, weight = ar[:, 0], ar[:, 1], ar[:, 2]
    raw = np.array([weight.sum(), (x*weight).sum(), (y*weight).sum(),
                    (y*y*weight).sum(), (x*x*weight).sum(), (x*y*weight).sum()])
    out = from_raw(raw)
    # Reflection symmetry is exact; remove integration round-off.
    out['yc'] = out['Ixy'] = 0.0
    raw[2] = raw[5] = 0.0
    cr = np.array(centre)
    weight, x, y, om = cr[:, 2], cr[:, 0], cr[:, 1], cr[:, 3]
    ac = weight.sum()
    xcc, ycc = (x*weight).sum()/ac, (y*weight).sum()/ac
    x, y = x-xcc, y-ycc
    om = om-xcc*y+ycc*x
    om -= (om*weight).sum()/ac
    ixc, iyc, ixyc = (y*y*weight).sum(), (x*x*weight).sum(), (x*y*weight).sum()
    co = np.linalg.solve(np.array([[iyc, ixyc], [ixyc, ixc]]),
                         -np.array([(x*om*weight).sum(), (y*om*weight).sum()]))
    xsc_line, ysc = -float(co[1]), float(co[0])
    # Translate the centreline shear centre to the actual area centroid.
    xsc = float(xcc+xsc_line-out['xc'])
    omc = om+co[0]*x+co[1]*y
    cw = float((omc*omc*weight).sum())
    ix, iy, aa, xc = out['Ix'], out['Iy'], out['A'], out['xc']
    integral_j = float((((ar[:, 0]-xc)**3+(ar[:, 0]-xc)*ar[:, 1]**2)*ar[:, 2]).sum())
    flange_end = xm-r if family == 'Ue' else xm
    plates: list[dict] = [dict(id='web', kind='AA', a=[0., -ym+r], b=[0., ym-r]),
              dict(id='upper_flange', kind='LIPPED' if family == 'Ue' else 'AL', a=[r, ym], b=[flange_end, ym]),
              dict(id='lower_flange', kind='LIPPED' if family == 'Ue' else 'AL', a=[r, -ym], b=[flange_end, -ym])]
    if family == 'Ue':
        plates += [dict(id='upper_lip', kind='AL', a=[xm, ym-r], b=[xm, H/2-D]),
                   dict(id='lower_lip', kind='AL', a=[xm, -ym+r], b=[xm, -H/2+D])]
    for plate in plates:
        plate['width'] = math.dist(plate['a'], plate['b'])
    out.update(family=family, H=H, B=B, D=D, t=t, ri=ri, rmean=r,
               Wx=ix/(H/2), Wy_web=iy/(xc+t/2), Wy_edge=iy/(B-t/2-xc),
               J=length*t**3/3, Cw=cw, xsc=xsc, ysc=0.0,
               r0=math.sqrt((ix+iy)/aa+xsc*xsc), rx=math.sqrt(ix/aa), ry=math.sqrt(iy/aa),
               h=h, b=b, d=d, centerline_length=length, xc_line=float(xcc),
               xsc_line=xsc_line, integral_j=integral_j, j=integral_j/(2*iy)-xsc,
               raw_moments=[float(v) for v in raw], plates=plates,
               geometry_method='A e inércias por retângulos e arcos anulares; J, Cw e CT pela aproximação de parede delgada; CT transladado ao centroide da área.')
    return out


def section_properties(profile, material):
    family = profile.get('family')
    if family not in ('U', 'Ue'):
        raise ValueError("A família deve ser U ou Ue.")
    H = _number(profile.get('h_mm'), 'Altura', positive=True)
    B = _number(profile.get('b_mm'), 'Mesa', positive=True)
    t = _number(profile.get('t_mm'), 'Espessura', positive=True)
    ri = _number(profile.get('r_mm'), 'Raio interno', nonnegative=True)
    D = _number(profile.get('d_mm', 0), 'Enrijecedor', nonnegative=True)
    if family == 'U' and D != 0:
        raise ValueError("O perfil U simples deve ter enrijecedor D = 0.")
    if family == 'Ue' and D <= 0:
        raise ValueError("O perfil U enrijecido exige D positivo.")
    density = _number(material.get('density_kgm3', 7850), 'Massa específica', positive=True)
    out = deepcopy(_geometry(family, H, B, D, t, ri))
    out['mass'] = out['A']*1e-6*density
    out['pp'] = out['mass']*9.81/1000
    return out
