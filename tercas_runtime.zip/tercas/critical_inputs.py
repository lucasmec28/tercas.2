"""Resolve automatic critical moments without altering the saved user inputs."""
from copy import deepcopy


FIELDS = ('ml_minor_pos_kNm', 'ml_minor_neg_kNm',
          'mdist_minor_pos_kNm', 'mdist_minor_neg_kNm')


def resolve_minor_criticals(project, combinations, precomputed=None):
    if project['profile']['family'] != 'Ue' or project['member']['minor_critical_mode'] != 'automatic':
        return project, {'status': 'manual' if project['profile']['family'] == 'Ue' else 'not_applicable'}
    working = deepcopy(project)
    for field in FIELDS:
        working['member'][field] = None
    working['member']['minor_critical_source'] = 'Cálculo automático de estabilidade elástica.'
    if not any(abs(case['qx_kNm']) + abs(case['px_kN']) > 1e-12 for case in combinations):
        return working, {'status': 'not_required', 'note': 'Não há solicitação de flexão no eixo menor nos casos informados.'}

    if precomputed is not None:
        data = deepcopy(precomputed)
    else:
        from .critical_minor import critical_moments
        data = critical_moments(project['profile'], project['material'])
    working['member']['minor_critical_source'] = str(data.get('method', 'Análise automática'))
    for sign, values in data.get('by_sign', {}).items():
        if sign not in ('pos', 'neg'):
            continue
        if values.get('status') == 'computed':
            local = values.get('local_Nmm')
            dist = values.get('distortional_Nmm')
            working['member'][f'ml_minor_{sign}_kNm'] = local / 1e6 if local is not None else None
            working['member'][f'mdist_minor_{sign}_kNm'] = dist / 1e6 if dist is not None else None
            if values.get('distortion_status') == 'not_applicable':
                # Internal provenance, not an importable user waiver.
                working['member'][f'_minor_{sign}_distortional_absent'] = True
    return working, data
