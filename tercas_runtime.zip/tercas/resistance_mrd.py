"""NBR 14762:2010, Annex C.4/C.5, for externally established eigenvalues.

All moments are in N mm and inertias in mm^4. This module does not obtain
eigenvalues or decide whether a buckling mode can be omitted. The caller must
provide the elastic local and distortional critical moments for the actual
bending direction, and the elastic global moment for the actual restraints.
An explicitly verified absence of distortional buckling may be declared by
the caller under C.2; missing numerical data never imply that absence.

The nominal moment is W*fy, with W referred to the first fibre to yield (C.1).
It is supplied by the caller: the helper does not substitute the compressed
fibre modulus for the first-yield modulus of a monosymmetric section.
"""
from __future__ import annotations

import math

from .sections import _number


def _root_ratio(numerator: float, denominator: float) -> float:
    """sqrt(a/b), avoiding overflow of an otherwise representable ratio root."""
    value = math.sqrt(numerator)/math.sqrt(denominator)
    if not math.isfinite(value):
        raise ValueError('A razão entre momentos excede o intervalo numérico do cálculo MRD.')
    return value


def _positive_result(value: float) -> float:
    if not math.isfinite(value) or value <= 0:
        raise ValueError('O momento resistente MRD está fora do intervalo numérico representável.')
    return float(value)


def _snap_threshold(value: float, *thresholds: float) -> float:
    """Resolve only floating-point noise at an explicitly inclusive limit.

    Four ulps cover rounding of the supplied squared ratio and its square
    root, without broadening a normative interval by an engineering tolerance.
    """
    for threshold in thresholds:
        if abs(value-threshold) <= 4*math.ulp(threshold):
            return threshold
    return value


def global_resistance(nominal_Nmm, me_Nmm) -> dict:
    """Characteristic global resistance MRe, C.4.1; no safety factor."""
    nominal = _number(nominal_Nmm, 'Momento nominal Wfy', positive=True)
    me = _number(me_Nmm, 'Momento crítico global Me', positive=True)
    lambda0 = _snap_threshold(_root_ratio(nominal, me), .6, 1.336)
    if lambda0 <= .6:
        chi, mre = 1., nominal
    elif lambda0 < 1.336:
        chi = min(1., 1.11*(1-.278*lambda0**2))
        mre = chi*nominal
    else:
        # C.4.1: Wfy/lambda0^2 = Me. This form also avoids squaring a
        # very large slenderness and losing an otherwise finite result.
        mre = me
        chi = me/nominal
    return dict(MRe_Nmm=_positive_result(mre), lambda0=float(lambda0),
                chi_global=float(chi))


def local_resistance(mre_Nmm, ml_Nmm) -> dict:
    """Characteristic local resistance MRl from MRe, C.4.2; no gamma."""
    mre = _number(mre_Nmm, 'Momento característico global MRe', positive=True)
    ml = _number(ml_Nmm, 'Momento crítico local Mℓ', positive=True)
    slenderness = _snap_threshold(_root_ratio(mre, ml), .776)
    if slenderness <= .776:
        rho, mrl = 1., mre
    else:
        power = slenderness**.8
        rho = min(1., (1-.15/power)/power)
        mrl = mre*rho
    return dict(MRl_Nmm=_positive_result(mrl), lambda_local=float(slenderness),
                rho_local=float(rho))


def distortion_resistance(nominal_Nmm, mdist_Nmm) -> dict:
    """Characteristic distortional resistance MRdist, C.4.3; no gamma."""
    nominal = _number(nominal_Nmm, 'Momento nominal Wfy', positive=True)
    mdist = _number(mdist_Nmm, 'Momento crítico distorcional Mdist', positive=True)
    slenderness = _snap_threshold(_root_ratio(nominal, mdist), .673)
    if slenderness <= .673:
        rho, mrdist = 1., nominal
    else:
        rho = min(1., (1-.22/slenderness)/slenderness)
        mrdist = nominal*rho
    return dict(MRdist_Nmm=_positive_result(mrdist), lambda_dist=float(slenderness),
                rho_dist=float(rho))


def _distortion_input(mdist_Nmm, distortional_absent: bool) -> float | None:
    """Validate a physical critical moment or an explicit C.2 omission."""
    if not isinstance(distortional_absent, bool):
        raise ValueError('A ausência de distorção deve ser declarada explicitamente como bool.')
    if distortional_absent:
        if mdist_Nmm is not None:
            raise ValueError('A ausência de distorção conflita com um Mdist informado.')
        return None
    return _number(mdist_Nmm, 'Momento crítico distorcional Mdist', positive=True)


def _characteristic(nominal_Nmm, me_Nmm, ml_Nmm, mdist_Nmm,
                    *, distortional_absent: bool = False) -> dict:
    mdist = _distortion_input(mdist_Nmm, distortional_absent)
    result = global_resistance(nominal_Nmm, me_Nmm)
    result.update(local_resistance(result['MRe_Nmm'], ml_Nmm))
    candidates = [result['MRe_Nmm'], result['MRl_Nmm']]
    if distortional_absent:
        result.update(MRdist_Nmm=None, lambda_dist=None, rho_dist=None,
                      distortional_state='omitted_per_C2')
    else:
        result.update(distortion_resistance(nominal_Nmm, mdist))
        result['distortional_state'] = 'computed'
        candidates.append(result['MRdist_Nmm'])
    result['MRk_Nmm'] = min(candidates)
    return result


def minor_mrd(nominal_Nmm, me_Nmm, ml_Nmm, mdist_Nmm,
              *, distortional_absent: bool = False) -> dict:
    """C.4: MRd=min(MRe,MRl,MRdist)/1.10 for a single bending direction.

    Moments must be finite and strictly positive. The sole exception is
    mdist_Nmm=None with distortional_absent=True: the caller has verified the
    mode's absence and its resistance branch is omitted under C.2. The helper
    does not verify this mechanical premise. Supplying both a critical moment
    and that declaration is rejected. Other missing eigenvalues remain pending
    verification; they cannot be replaced by zero or infinity.
    """
    result = _characteristic(nominal_Nmm, me_Nmm, ml_Nmm, mdist_Nmm,
                             distortional_absent=distortional_absent)
    result['Rd_Nmm'] = _positive_result(result['MRk_Nmm']/1.1)
    return result


def minor_service(me_Nmm, ml_Nmm, mdist_Nmm, moment_ser, Ig,
                  *, distortional_absent: bool = False) -> dict:
    """C.5: Ief=min(MR,ser/|Mn|,1)*Ig for uniaxial bending only.

    C.4 is recalculated with Wfy replaced by |Mn|, including the global-local
    interaction in C.4.2. No partial safety factor is applied. The moment can
    be signed; the caller must select the eigenvalues of the matching sign.
    This scalar uniaxial inertia is not a joint biaxial effective section.
    A C.2 omission follows the same explicit contract as minor_mrd, including
    at zero service moment; zero demand does not validate missing input data.
    """
    me = _number(me_Nmm, 'Momento crítico global Me', positive=True)
    ml = _number(ml_Nmm, 'Momento crítico local Mℓ', positive=True)
    mdist = _distortion_input(mdist_Nmm, distortional_absent)
    moment = abs(_number(moment_ser, 'Momento solicitante de serviço Mn'))
    inertia = _number(Ig, 'Inércia bruta Ig', positive=True)
    if moment == 0:
        return dict(MRe_Nmm=0., MRl_Nmm=0.,
                    MRdist_Nmm=None if distortional_absent else 0., MRk_Nmm=0.,
                    lambda0=0., lambda_local=0.,
                    lambda_dist=None if distortional_absent else 0.,
                    chi_global=1., rho_local=1.,
                    rho_dist=None if distortional_absent else 1.,
                    distortional_state='omitted_per_C2' if distortional_absent else 'computed',
                    MRser_Nmm=0., Ief_mm4=inertia, ratio=1.)
    result = _characteristic(moment, me, ml, mdist,
                             distortional_absent=distortional_absent)
    ratio = min(result['MRk_Nmm']/moment, 1.)
    result.update(MRser_Nmm=result['MRk_Nmm'],
                  Ief_mm4=_positive_result(inertia*ratio), ratio=float(ratio))
    return result
