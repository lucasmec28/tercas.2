"""Casos do caderno numérico; valores são dados de exercícios, não catálogo."""
from copy import deepcopy
from .project import default_project
from .sections import section_properties


def _build():
    cases = {}
    p = default_project()
    p['name'] = 'F1 · Ue 200 × 80 × 30 × 2 · 6 m'
    cases['F1 — Gravidade e contenção contínua'] = deepcopy(p)
    p['name'] = 'F1b · Flecha governante · 8 m'
    p['member']['L_m'] = 8.0
    p['loads']['point_x_m'] = 4.0
    p['loads']['q_kNm'] = 0.55
    cases['F1b — Resistência atende e flecha excede'] = deepcopy(p)
    p = default_project()
    p['name'] = 'F2 · Ue sem contenção intermediária'
    p['member']['restraint'] = 'none'
    p['member']['Lb_m'] = 6.0
    cases['F2 — Flambagem lateral com torção'] = deepcopy(p)
    p['name'] = 'F2b · Contenção lateral e torcional em 3 m'
    p['member']['restraint'] = 'discrete'
    p['member']['Lb_m'] = 3.0
    cases['F2b — Contenção no meio do vão'] = deepcopy(p)
    p = default_project()
    p['name'] = 'F3 · Sucção e painel · Ue 200 × 70 × 30 × 2'
    p['profile']['b_mm'] = 70.0
    p['member']['restraint'] = 'panel'
    p['loads'].update(g_metal_kNm=0.0404185919456324, q_kNm=0.0, wind_up_kNm=1.25)
    cases['F3 — Sucção com painel conectado'] = deepcopy(p)
    p = default_project()
    p['name'] = 'F4 · U simples · Inclinação de 5 graus'
    p['profile'].update(family='U', d_mm=0.0)
    p['member'].update(L_m=4.0, Lb_m=4.0, angle_deg=5.0, restraint='none')
    p['loads'].update(g_metal_kNm=0.0455665759728162, g_roof_kNm=0.05, q_kNm=0.20, point_x_m=2.0)
    p['support']['fastened'] = False
    cases['F4 — Flexão biaxial em U simples'] = deepcopy(p)
    p['name'] = 'F4b · U simples · Inclinação de 10 graus'
    p['member']['angle_deg'] = 10.0
    cases['F4b — Aumento da inclinação'] = deepcopy(p)
    p = default_project()
    p['name'] = 'S1 · Flecha com redução da inércia efetiva'
    p['profile'].update(family='U', d_mm=0.0)
    p['member'].update(L_m=4.0, Lb_m=4.0)
    p['loads'].update(g_metal_kNm=0.0455665759728162, g_roof_kNm=0.40, q_kNm=0.75, point_x_m=2.0)
    p['support']['fastened'] = False
    cases['S1 — Inércia efetiva de serviço'] = deepcopy(p)
    p = default_project()
    p['name'] = 'V4 · Peso próprio e carga em um quarto do vão'
    p['loads'].update(g_metal_kNm=0.0, g_roof_kNm=0.0, q_kNm=0.0, point_kN=6.249840949, point_x_m=1.5)
    cases['V4 — Interação momento e cortante'] = deepcopy(p)
    p = default_project()
    p['name'] = 'N1 · Compressão de 25 kN · Sem contenção intermediária'
    p['member'].update(restraint='none', Lb_m=6.0)
    p['loads'].update(mode='design', qd_normal_kNm=0.0, qs_normal_kNm=0.0, nsd_kN=25.0)
    cases['N1 — Compressão axial'] = deepcopy(p)
    p['name'] = 'N1b · Compressão · Contenção lateral e torcional em 3 m'
    p['member'].update(restraint='discrete', Lb_m=3.0)
    cases['N1b — Compressão com contenção intermediária'] = deepcopy(p)
    p['name'] = 'N3 · Flexocompressão · Contenção em 3 m'
    p['loads'].update(qd_normal_kNm=1.0, qs_normal_kNm=0.6, nser_kN=15.0)
    cases['N3 — Compressão e flexão no modelo ideal'] = deepcopy(p)
    p['name'] = 'N3b · Flexocompressão sem contenção intermediária'
    p['member'].update(restraint='none', Lb_m=6.0)
    cases['N3b — Flexocompressão sem contenção'] = deepcopy(p)
    p['name'] = 'N4 · Flexotração · Momento sem alívio pela tração'
    p['member'].update(restraint='discrete', Lb_m=3.0)
    p['loads'].update(nsd_kN=-25.0, nser_kN=0.0)
    p['tension'].update(an0_mm2=813.6991118430774, an_mm2=669.3292006587697, ct=0.7442019407550482)
    cases['N4 — Tração e flexão'] = deepcopy(p)
    p['name'] = 'N2 · Tração · Áreas líquidas e Ct do exemplo 4M16'
    p['loads'].update(qd_normal_kNm=0.0, qs_normal_kNm=0.0, nsd_kN=-20.0)
    cases['N2 — Tração da barra'] = deepcopy(p)
    p = default_project()
    p['name'] = 'F5 · Ue · My positivo · Críticos didáticos'
    p['member'].update(restraint='none', Lb_m=6.0, minor_critical_mode='manual',
        ml_minor_pos_kNm=5.0, mdist_minor_pos_kNm=8.0,
        ml_minor_neg_kNm=7.0, mdist_minor_neg_kNm=12.0,
        minor_critical_source='DADOS DIDÁTICOS para conferir as equações do Anexo C. Ml+/Mdist+=5/8 e Ml−/Mdist−=7/12 kN·m são hipóteses numéricas; não são autovalores calculados ou certificados desta seção.')
    p['loads'].update(mode='design', qd_normal_kNm=0.0, qd_parallel_kNm=0.30,
        qs_normal_kNm=0.0, qs_parallel_kNm=2/9)
    cases['F5 — Ue no eixo menor, My positivo (didático)'] = deepcopy(p)
    p['name'] = 'F5b · Ue · My negativo · Críticos didáticos'
    p['loads'].update(qd_parallel_kNm=-0.50, qs_parallel_kNm=-0.35)
    cases['F5b — Ue no eixo menor, My negativo (didático)'] = deepcopy(p)
    p['name'] = 'F6 · Ue · Flexão biaxial a 5 graus · Críticos didáticos'
    p['member'].update(restraint='continuous', angle_deg=5.0)
    p['loads'].update(mode='characteristic')
    cases['F6 — Ue em flexão biaxial (didático)'] = deepcopy(p)
    p = default_project()
    p['name'] = 'A1 · Ue · My positivo · Críticos automáticos'
    p['member'].update(restraint='none', Lb_m=6.0)
    p['loads'].update(mode='design', qd_normal_kNm=0.0, qd_parallel_kNm=0.30,
        qs_normal_kNm=0.0, qs_parallel_kNm=2/9)
    cases['A1 — Ue My positivo com críticos automáticos'] = deepcopy(p)
    p['name'] = 'A2 · Ue · My negativo · Críticos automáticos'
    p['loads'].update(qd_parallel_kNm=-0.50, qs_parallel_kNm=-0.35)
    cases['A2 — Ue My negativo com críticos automáticos'] = deepcopy(p)
    p['name'] = 'A3 · Ue · Flexão biaxial · Críticos automáticos'
    p['member'].update(restraint='continuous', angle_deg=5.0)
    p['loads'].update(mode='characteristic')
    cases['A3 — Ue biaxial com críticos automáticos'] = deepcopy(p)
    # These exercises explicitly demonstrate the optional in-plane criterion.
    for name, case in cases.items():
        if name.split(' —')[0] in ('F5', 'F5b', 'F6', 'A1', 'A2', 'A3'):
            case['limits']['additional_checks'] = True
    p = default_project()
    p['name'] = 'J1 · Travessa Ue 150 × 60 × 20 × 4,25 · referência Jary'
    p['profile'].update(h_mm=150.,b_mm=60.,d_mm=20.,t_mm=4.25,r_mm=4.25)
    p['material'].update(E_mpa=205000.,G_mpa=78846.,fy_mpa=170.,fu_mpa=300.)
    p['member'].update(element_type='wall_girt',L_m=5.,Lb_m=5.,restraint='independent',
                       Lx_m=3.,Ly_m=2.,Lz_m=5.)
    own_weight=section_properties(p['profile'],p['material'])['pp']
    p['loads'].update(g_metal_kNm=.2-own_weight,g_roof_kNm=0.,q_kNm=0.,
                      wind_down_kNm=.87,wind_up_kNm=.91,point_kN=0.,point_x_m=2.5)
    p['support']['check']=False
    cases['J1 — Travessa de fechamento · comparação Jary'] = deepcopy(p)
    return cases


PRESETS = _build()
