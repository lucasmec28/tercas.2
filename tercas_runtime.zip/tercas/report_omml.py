"""Native Word math for the controlled expression language of report_checks.

The parser preserves operator precedence, parenthesized denominators, scientific
numbers as indivisible atoms, and every source token. It never evaluates or
rounds an expression. Word-specific objects are produced directly, without Word
automation or an image fallback at export time.
"""
from __future__ import annotations

from dataclasses import dataclass
import re

from docx.oxml import OxmlElement
from docx.oxml.ns import qn

_SUPERS = '⁰¹²³⁴⁵⁶⁷⁸⁹⁻⁺'
_UNSUPER = str.maketrans(_SUPERS, '0123456789-+')
_SUBS = '₀₁₂₃₄₅₆₇₈₉ₓᵧₛᵢ'
_UNSUB = str.maketrans(_SUBS, '0123456789xysi')
_NUM = r'\d+(?:[.,]\d+)?'
_WORD = r'[^\W\d_]+'


@dataclass(frozen=True)
class Node:
    kind: str
    value: str = ''
    children: tuple['Node', ...] = ()


def _normalise(text: str) -> str:
    text = str(text).replace('−', '-').replace('–', '-')
    # The decimal point in historical Unicode superscripts is U+00B7.
    text = re.sub('['+_SUPERS+']+(?:[·,.]['+_SUPERS+']+)?',
                  lambda m: '^{'+m[0].translate(_UNSUPER).replace('·', ',')+'}', text)
    text = re.sub('['+_SUBS+']+', lambda m: '_{'+m[0].translate(_UNSUB)+'}', text)
    # A qualifier following a Unicode index is part of that same index.
    # In particular Mₓ,Rd must be one denominator M_{x,Rd}, never M_x ,Rd.
    text = re.sub(r'_\{([^{}]+)\},([A-Za-z0-9]+)', r'_{\1,\2}', text)
    text = re.sub(r'(M_\{[xy],Rd)\}([+-])(?=\s*(?:=|$))', r'\1\2}', text)
    text = re.sub(r'_([A-Za-z]+[0-9]+)\b', r'_{\1}', text)
    text = text.replace('ᴸ', '^{L}').replace('ᶻ', '^{z}')
    text = re.sub(r'([MNk])ℓ', r'\1_{ℓ}', text)
    text = re.sub(r'(λ)(p0|p|dist|v|ℓ)(?:,([A-Za-z0-9]+))?',
                  lambda m: m[1]+'_{'+m[2]+(','+m[3] if m[3] else '')+'}', text)
    text = re.sub(r'(χ|ρ)(FLT|dist|red)', r'\1_{\2}', text)
    text = re.sub(r'([abqPκ])δ', r'\1_{δ}', text)
    # Legacy forms use a Unicode subscript inside a caret exponent.
    text = re.sub(r'\^([A-Za-zΑ-ω]+)_\{([^}]+)\}', r'^{\1_{\2}}', text)
    return text


def _tokens(text):
    text = _normalise(text)
    result = []
    i = 0
    while i < len(text):
        if text[i].isspace():
            i += 1
            continue
        annotation = re.match(r'\((?:alma/lábios; Tabelas 5/6|seção integral comprovada|faixas retidas|resistências aplicáveis)\)', text[i:])
        if annotation:
            result.append(('text', annotation[0])); i += len(annotation[0]); continue
        # Scientific notation must be one atom, especially after a slash:
        # a/2.28×10^7 means a divided by the full recorded float.
        match = re.match('('+_NUM+r')×10\^\{([+-]?\d+)\}', text[i:])
        if match:
            result.append(('science', match[1]+'|'+match[2]))
            i += len(match[0]); continue
        match = re.match(_NUM, text[i:])
        if match:
            result.append(('atom', match[0])); i += len(match[0]); continue
        match = re.match(_WORD, text[i:], re.UNICODE)
        if match:
            result.append(('atom', match[0])); i += len(match[0]); continue
        result.append(('mark', text[i])); i += 1
    return result


class _Parser:
    def __init__(self, text):
        self.tokens = _tokens(text)
        self.i = 0

    def peek(self):
        return self.tokens[self.i][1] if self.i < len(self.tokens) else None

    def pop(self):
        token = self.tokens[self.i]
        self.i += 1
        return token

    def atom(self):
        if self.i >= len(self.tokens):
            raise ValueError('Operador sem argumento na equação.')
        kind, token = self.pop()
        if token in ('+', '-'):
            node = Node('unary', token, (self.expression(30),))
        elif token in ('(', '[', '{'):
            close = {'(': ')', '[': ']', '{': '}'}[token]
            contents = self.expression(0, {close})
            if self.peek() != close:
                raise ValueError('Delimitador não balanceado na equação.')
            self.pop()
            node = Node('group', token+close, (contents,))
        elif token == '|':
            contents = self.expression(0, {'|'})
            if self.peek() != '|':
                raise ValueError('Módulo não balanceado na equação.')
            self.pop()
            node = Node('group', '||', (contents,))
        elif token == '√':
            argument = self.atom()
            if argument.kind == 'group':
                argument = argument.children[0]
            node = Node('sqrt', children=(argument,))
        elif kind == 'science':
            mantissa, exponent = token.split('|')
            node = Node('science', mantissa, (Node('atom', exponent),))
        elif kind == 'text':
            node = Node('text', token)
        else:
            node = Node('atom', token)
        # Indices bind before exponentiation. Comma-separated indices belong to
        # the same subscript only when the next word has no intervening operator.
        while self.peek() == '_':
            self.pop()
            if self.peek() == '{':
                index = self.atom().children[0]
            else:
                if self.i >= len(self.tokens):
                    raise ValueError('Índice ausente na equação.')
                index = Node('atom', self.pop()[1])
                while self.peek() == ',' and self.i+1 < len(self.tokens) and self.tokens[self.i+1][0] == 'atom':
                    self.pop()
                    index = Node('sequence', children=(index, Node('atom', ','), Node('atom', self.pop()[1])))
            node = Node('sub', children=(node, index))
        return node

    def expression(self, minimum=0, stop=None):
        stop = stop or set()
        if self.peek() is None or self.peek() in stop:
            return Node('atom', '')
        left = self.atom()
        while self.peek() is not None and self.peek() not in stop:
            token = self.peek()
            if token in (')', ']', '}'):
                break
            if token == '^':
                power = 40
                if power < minimum: break
                self.pop()
                exponent = self.atom()
                if exponent.kind == 'group': exponent = exponent.children[0]
                left = Node('sup', children=(left, exponent)); continue
            if token in ('=', '≤', '≥', '<', '>', '⇒', ';', ':', ',', '→'):
                power = 1
            elif token in ('+', '-'):
                power = 10
            elif token in ('×', '·', '/', '*'):
                power = 20
            else:
                power = 20
                if power < minimum: break
                right = self.expression(power+1, stop)
                left = Node('implicit', children=(left, right)); continue
            if power < minimum: break
            self.pop()
            right = self.expression(power+1, stop)
            left = Node('fraction' if token == '/' else 'binary', token, (left, right))
        return left


def parse(text: str) -> Node:
    parser = _Parser(text)
    node = parser.expression()
    if parser.i != len(parser.tokens):
        raise ValueError('Trecho não interpretado na equação: '+str(parser.tokens[parser.i:]))
    return node


def _element(tag, **attrs):
    element = OxmlElement('m:'+tag)
    for key, value in attrs.items():
        element.set(qn('m:'+key), str(value))
    return element


def _run(text, normal=False):
    run = _element('r')
    if normal or text in ('min', 'max', 'sen', 'cos', 'tan', 'divisor',
                           'mm', 'N', 'kN', 'MPa'):
        math_props = _element('rPr')
        math_props.append(_element('nor'))
        run.append(math_props)
    props = OxmlElement('w:rPr')
    fonts = OxmlElement('w:rFonts')
    for key in ('ascii', 'hAnsi', 'eastAsia', 'cs'):
        fonts.set(qn('w:'+key), 'Cambria Math')
    props.append(fonts)
    size = OxmlElement('w:sz'); size.set(qn('w:val'), '24'); props.append(size)
    run.append(props)
    item = _element('t'); item.text = text.replace('-', '−')
    if text.startswith(' ') or text.endswith(' '):
        item.set(qn('xml:space'), 'preserve')
    run.append(item)
    return run


def _container(tag, node):
    element = _element(tag)
    element.extend(_emit(node))
    return element


def _emit(node):
    kind = node.kind
    if kind == 'atom': return [_run(node.value)]
    if kind == 'text': return [_run(node.value, normal=True)]
    if kind == 'unary': return [_run(node.value), *_emit(node.children[0])]
    if kind in ('sequence', 'implicit'):
        return [item for child in node.children for item in _emit(child)]
    if kind == 'binary':
        return [*_emit(node.children[0]), _run(node.value), *_emit(node.children[1])]
    if kind == 'group':
        obj = _element('d'); props = _element('dPr')
        props.append(_element('begChr', val=node.value[0]))
        props.append(_element('endChr', val=node.value[1]))
        obj.append(props); obj.append(_container('e', node.children[0])); return [obj]
    if kind == 'fraction':
        obj = _element('f')
        numerator, denominator = node.children
        # Grouping remains structurally explicit in num/den and need not be
        # printed as redundant parentheses surrounding the entire fraction.
        if numerator.kind == 'group' and numerator.value != '||': numerator = numerator.children[0]
        if denominator.kind == 'group' and denominator.value != '||': denominator = denominator.children[0]
        obj.append(_container('num', numerator)); obj.append(_container('den', denominator)); return [obj]
    if kind == 'sqrt':
        obj = _element('rad'); props = _element('radPr')
        props.append(_element('degHide', val='1')); obj.append(props)
        obj.append(_element('deg')); obj.append(_container('e', node.children[0])); return [obj]
    if kind == 'science':
        power = Node('sup', children=(Node('atom', '10'), node.children[0]))
        return [_run(node.value), _run('×'), *_emit(power)]
    if kind in ('sub', 'sup'):
        base, index = node.children
        if kind == 'sup' and base.kind == 'sub':
            obj = _element('sSubSup')
            obj.append(_container('e', base.children[0]))
            obj.append(_container('sub', base.children[1]))
            obj.append(_container('sup', index)); return [obj]
        obj = _element('sSub' if kind == 'sub' else 'sSup')
        obj.append(_container('e', base))
        obj.append(_container('sub' if kind == 'sub' else 'sup', index)); return [obj]
    raise ValueError('Estrutura matemática não reconhecida: '+kind)


def equation(text: str):
    """Return a native m:oMath element, with no image or Word dependency."""
    result = _element('oMath')
    result.extend(_emit(parse(text)))
    return result


def parts(text: str) -> list[str]:
    """Split independent top-level statements so built-up math can fit A4."""
    result, start, depth = [], 0, 0
    for index, char in enumerate(str(text)):
        if char in '([{': depth += 1
        elif char in ')]}': depth -= 1
        elif char == ';' and depth == 0:
            result.append(text[start:index].strip()); start = index+1
    result.append(text[start:].strip())
    return [part for part in result if part]
