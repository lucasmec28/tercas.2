"""NBR 14762:2010 resistance routes for equal-flange U and Ue purlins.

Unavailable checks are None with scoped limitations. Tabulated values are
interpolated only inside their domains; no elastic eigenvalues are invented.
"""
from __future__ import annotations
import math
import numpy as np
from .sections import _number
from .resistance_plates import (PlateDomainError, effective_u, prove_gross_lipped,
                                reduction, stress_coefficients, stress)
from .resistance_mrd import (minor_mrd, minor_service, global_resistance,
                             local_resistance, distortion_resistance)

_ETA13 = [.2,.3,.4,.5,.6,.7,.8,.9,1.]
_K13_U = [18.4,9.6,5.6,3.6,2.6,1.9,1.5,1.2,1.]
_K13_UE = [[32.,29.3,24.8,18.7,13.6,10.2,7.9,6.2,5.1],
           [25.8,23.8,20.7,17.6,13.3,10.1,7.9,6.3,5.1],
           [21.2,19.7,18.2,16.,13.,10.1,7.9,6.3,5.1]]
_ETA10 = [.1,.2,.3,.4,.5,.6,.7,.8,.9,1.]
_K10_U = [4.25,4.52,4.33,3.71,2.88,2.17,1.67,1.32,1.06,.88]
_K10_UE = [6.04,5.73,5.55,5.40,5.26,5.11,4.89,4.56,4.10]
_DIST_ETA = [.4,.6,.8,1.,1.2,1.4,1.6,1.8,2.]
_DIST_SLENDER = [50.,100.,125.,200.,250.]
_D14 = [[.25,.12,.10,.06,.05],[.25,.12,.10,.06,.05],
        [.22,.12,.09,.06,.05],[.22,.11,.09,.06,.05],
        [.20,.11,.09,.06,.05],[.20,.10,.09,.06,.05],
        [.20,.10,.09,.06,.05],[.19,.10,.09,.06,.05],
        [.19,.10,.09,.06,.05]]
_D11 = [[.08,.04,.04,.03,.02],[.15,.06,.06,.04,.03],
        [.22,.10,.08,.06,.05],[.27,.12,.10,.07,.06],
        [.27,.15,.12,.07,.06],[.27,.15,.12,.08,.06],
        [.27,.15,.12,.08,.07],[.27,.15,.12,.08,.07],
        [.27,.15,.12,.08,.07]]


def _mem(title, formula, substitution, result, unit, reference):
    return dict(title=title, formula=formula, substitution=substitution,
                result=float(result) if isinstance(result,(int,float,np.floating)) else str(result),
                unit=unit, reference=reference)


def _lim(code, message, reference, applies_to):
    return dict(code=code, message=message, reference=reference, applies_to=applies_to)


def _interp(value, axis, values):
    if value < axis[0]-1e-10 or value > axis[-1]+1e-10:
        raise PlateDomainError('Valor fora do intervalo tabulado; extrapolação não permitida.')
    return float(np.interp(min(max(value,axis[0]),axis[-1]), axis, values))


def _material(material):
    fy = _number(material.get('fy_mpa'), 'fy', positive=True)
    fu = _number(material.get('fu_mpa'), 'fu', positive=True)
    E = _number(material.get('E_mpa'), 'E', positive=True)
    G = _number(material.get('G_mpa'), 'G', positive=True)
    nu = _number(material.get('nu', .3), 'Poisson')
    if not 0 <= nu < .5:
        raise ValueError('O coeficiente de Poisson deve estar entre 0 e 0,5, excluindo 0,5.')
    if fu < fy:
        raise ValueError('fu não pode ser inferior a fy.')
    return fy, fu, E, G, nu


def major_local_coefficient(props):
    eta, mu = props['B']/props['H'], props['D']/props['H']
    if props['family'] == 'U':
        if .1-1e-10 <= eta < .2:
            return eta**(-1.843), 'Tabela 12a (domínio 0,1 ≤ bf/bw < 0,2)'
        return _interp(eta, _ETA13, _K13_U), 'Tabela 13a'
    if not .1-1e-10 <= mu <= .3+1e-10:
        raise PlateDomainError('Ue: D/bw deve estar entre 0,1 e 0,3 para esta rota MSE (Tabelas 12/13).')
    vals = [_interp(eta, _ETA13, column) for column in _K13_UE]
    return _interp(max(mu,.2), [.2,.25,.3], vals), 'Tabela 13b; interpolação linear nos dois parâmetros'


def axial_local_coefficient(props):
    eta, mu = props['B']/props['H'], props['D']/props['H']
    if props['family'] == 'U':
        return _interp(eta, _ETA10, _K10_U), 'Tabela 10 — U simples'
    if not .1-1e-10 <= mu <= .3+1e-10:
        raise PlateDomainError('Compressão Ue: D/bw fora de 0,1 a 0,3 (Tabela 9).')
    if .1-1e-10 <= eta < .2:
        return 6.8-5.8*eta+9.2*eta*eta-6*eta**3, 'Tabela 9b; Tabela 10 sem valor nesse intervalo'
    return _interp(eta, _ETA13, _K10_UE), 'Tabela 10 — Ue'


def distortion_waiver(props, compression=False):
    if props['family'] == 'U':
        return True, None, '9.3: U simples isolado'
    eta, slender = props['B']/props['H'], props['H']/props['t']
    table = _D11 if compression else _D14
    values = [_interp(slender, _DIST_SLENDER, row) for row in table]
    minimum = _interp(eta, _DIST_ETA, values)
    return props['D']/props['H'] >= minimum-1e-12, minimum, 'Tabela 11' if compression else 'Tabela 14'


def _plate_limit_messages(props, *, compression=False):
    issues = []
    if props['b']/props['t'] > 60+1e-9:
        issues.append('Mesa: b/t excede 60 (Tabela 4).')
    if props['family'] == 'Ue' and props['d']/props['t'] > 60+1e-9:
        issues.append('Enrijecedor AL: d/t excede 60 (Tabela 4).')
    web_limit = 90 if compression and props['family']=='U' else (500 if compression else 200)
    if props['h']/props['t'] > web_limit+1e-9:
        issues.append(f'Alma: h/t excede {web_limit} no estado analisado (Tabela 4).')
    return issues


def _chi_flt(lam):
    return 1. if lam <= .6 else (1.11*(1-.278*lam*lam) if lam < 1.336 else 1/(lam*lam))


def _minor_elastic_moment(props, elastic, direction):
    """Anexo E, Cm=1; a forma racionalizada evita cancelamento para Cs=-1."""
    nex,nez,j=elastic['Nex_N'],elastic['Nez_N'],props['j']
    root=math.sqrt(j*j+props['r0']**2*nez/nex)
    moment=(props['r0']**2*nez/(root+j) if direction>0 else nex*(j+root))
    wc=props['Wy_edge'] if direction>0 else props['Wy_web']
    return moment,wc,-1 if direction>0 else 1


def _minor_critical(member, sign):
    values=[]
    for prefix in ('ml','mdist'):
        key=f'{prefix}_minor_{sign}_kNm'
        raw=member.get(key)
        values.append(None if raw is None else _number(raw,key,positive=True)*1e6)
    return values


def _elastic(props, E, G, Lx, Ly, Lz):
    nex = math.pi**2*E*props['Ix']/Lx**2
    ney = math.pi**2*E*props['Iy']/Ly**2
    nez = (math.pi**2*E*props['Cw']/Lz**2+G*props['J'])/props['r0']**2
    beta = 1-(props['xsc']/props['r0'])**2
    discriminant = (nex+nez)**2-4*beta*nex*nez
    if beta <= 0 or discriminant < -1e-7*(nex+nez)**2:
        raise PlateDomainError('Parâmetros de flexotorção inconsistentes.')
    # Rationalised form avoids cancellation for slender members.
    nexz = 2*nex*nez/(nex+nez+math.sqrt(max(0.,discriminant)))
    return dict(Nex_N=nex, Ney_N=ney, Nez_N=nez, Nexz_N=nexz, Ne_N=min(ney,nexz), beta=beta)


def _buckling_lengths(member, *, lb_major_mm=None, ignore_restraints=False):
    """K=1 lengths of independent modes; they never change the beam span."""
    length=1000*_number(member.get('L_m'),'Vão L',positive=True)
    if ignore_restraints:
        return length,length,length
    restraint=member.get('restraint')
    if restraint not in ('none','continuous','discrete','panel','independent'):
        raise ValueError('Tipo de contenção não reconhecido.')
    if restraint=='independent':
        values=tuple(1000*_number(member.get(key),key,positive=True) for key in ('Lx_m','Ly_m','Lz_m'))
        if any(value>length+1e-8 for value in values):
            raise ValueError('Com K = 1, Lx, Ly e Lz não podem ultrapassar o vão L.')
        return values
    if restraint=='discrete':
        lb=(_number(lb_major_mm,'Lb',positive=True) if lb_major_mm is not None else
            1000*_number(member.get('Lb_m'),'Lb',positive=True))
        if lb>length+1e-8:
            raise ValueError('Lb não pode ultrapassar o vão L.')
        return length,lb,lb
    return length,length,length


def _distortion_capacity(props, fy, raw_value, compression, limitations, applies_to):
    reference = 'NBR 14762:2010, 9.7.3 e Tabela 11' if compression else 'NBR 14762:2010, 9.8.2.3 e Tabela 14'
    try:
        waived, minimum, origin = distortion_waiver(props, compression)
    except PlateDomainError:
        waived, minimum, origin = False, None, 'geometria fora do domínio da tabela de dispensa'
    if waived:
        return None, dict(waived=True, minimum_ratio=minimum, reference=origin)
    if raw_value is None:
        limitations.append(_lim(f'{applies_to}_distortion',
            'A dispensa distorcional não foi demonstrada; fornecer esforço crítico distorcional de análise elástica documentada.',reference,applies_to))
        return None, dict(waived=False, minimum_ratio=minimum, provided=False, reference=origin)
    critical = _number(raw_value, 'Ndist' if compression else 'Mdist', positive=True)*(1000 if compression else 1e6)
    base = props['A']*fy if compression else props['Wx']*fy
    lam = math.sqrt(base/critical)
    if compression:
        chi = 1. if lam <= .561 else (1-.25/lam**1.2)/lam**1.2
        capacity = chi*base/1.2
    else:
        chi = reduction(lam)
        capacity = chi*base/1.1
    return capacity, dict(waived=False, minimum_ratio=minimum, provided=True, critical=critical, lambda_dist=lam, chi_dist=chi, reference=origin)


def _panel_capacity(project, props, local, fy):
    member, panel = project['member'], project['panel']
    H,B,t = props['H'],props['B'],props['t']
    failures=[]
    if props['family'] != 'Ue': failures.append('Anexo F requer mesas com enrijecedores de borda.')
    checks=[(H<=292, 'bw deve ser ≤292 mm'),(60<=H/t<=170,'bw/t deve estar entre 60 e 170'),
            (2.8<=H/B<=4.5,'bw/bf deve estar entre 2,8 e 4,5'),
            (16<=props['b']/t<=43,'b/t da mesa plana deve estar entre 16 e 43'),
            (member['L_m']<10,'vão deve ser inferior a 10 m'),(fy<=410,'fy deve ser ≤410 MPa'),
            (member.get('end_fork') is True,'ambas as mesas precisam de impedimento lateral nos apoios'),
            (panel.get('thickness_mm',0)>=.45,'telha de aço deve ter espessura ≥0,45 mm'),
            (panel.get('rib_height_mm',0)>=25,'altura da nervura deve ser ≥25 mm'),
            (0<panel.get('rib_pitch_mm',0)<=300,'passo das nervuras deve ser ≤300 mm'),
            (panel.get('fastener_mm',0)>=5.5,'parafuso padronizado deve ter diâmetro ≥5,5 mm'),
            (panel.get('washer_mm',0)>=12.5,'arruela deve ter diâmetro ≥12,5 mm'),
            (0<panel.get('fastener_pitch_mm',0)<=300,'passo dos conectores deve ser ≤300 mm'),
            (panel.get('near_center') is True,'fixação deve estar próxima ao centro da mesa'),
            (panel.get('proven_stiffness') is True,'ligação painel–perfil deve ter eficácia comprovada')]
    failures += [message for ok,message in checks if not ok]
    if failures or local is None:
        return None,None,failures or ['Resistência local não disponível.']
    factor = .70 if H<=165 else (.65 if H<=216 else .40)
    return factor*local,factor,[]


def support_capacity(project, props, fy):
    """Table D.2, end reaction acting on one flange, no transverse stiffener."""
    support=project['support']
    limitations=[]
    if not support.get('check',False):
        return None,[],[_lim('support_not_checked','A verificação localizada da alma no apoio foi desativada.','NBR 14762:2010, Anexo D','support')]
    c=_number(support.get('c_mm'),'Comprimento de apoio',positive=True)
    theta=_number(support.get('theta_deg'),'Ângulo do apoio',positive=True)
    fastened=support.get('fastened') is True
    if props['family']=='U' and fastened:
        return None,[],[_lim('support_u_fastened','A Tabela D.2 não fornece linha de mesa conectada para U simples; não é permitido usar a linha de Ue.','Tabela D.2, p.79','support')]
    if props['family']=='Ue':
        alpha,ar,ac,ah,rmax=(4.6,.14,.35,.02,9.) if fastened else (4.3,.14,.35,.02,5.)
    else:
        alpha,ar,ac,ah,rmax=4.6,.40,.60,.03,2.
    h,t,ri=props['h'],props['t'],props['ri']
    requirements=[(abs(theta-90)<1e-9,'Tabela D.2 desta rota exige θ = 90°'),
                  (c>=20,'c deve ser ≥20 mm'),(h/t<=200,'h/t deve ser ≤200'),
                  (c/t<=210,'c/t deve ser ≤210'),(c/h<=2,'c/h deve ser ≤2'),
                  (ri/t<=rmax,f'ri/t deve ser ≤{rmax:g} nesta linha da tabela')]
    failures=[msg for ok,msg in requirements if not ok]
    if failures:
        return None,[],[_lim('support_domain','; '.join(failures),'NBR 14762:2010, Anexo D e Tabela D.2','support')]
    radius=1-ar*math.sqrt(ri/t);contact=1+ac*math.sqrt(c/t);web=1-ah*math.sqrt(h/t)
    if min(radius,contact,web)<=0:
        return None,[],[_lim('support_factor','Um fator do Anexo D não é positivo; não utilizar capacidade inválida.','Tabela D.2','support')]
    value=alpha*t*t*fy*radius*contact*web/1.35
    memory=[_mem('Resistência da alma no apoio de extremidade',r'F_{Rd}=\alpha t^2f_y(1-\alpha_r\sqrt{r_i/t})(1+\alpha_c\sqrt{c/t})(1-\alpha_h\sqrt{h/t})/1.35',
                 f'α={alpha}; αr={ar}; αc={ac}; αh={ah}; c={c} mm; uma mesa; '+('conectada' if fastened else 'não conectada'),value,'N','NBR 14762:2010, D.2, Tabela D.2')]
    return value,memory,limitations


def resistance_summary(project, props, *, cb_major=None, lb_major_mm=None):
    """Strengths of the ideal single member; connection design is independent.

    Optional Cb must come from the actual moment diagram. Lb is only the
    verified lateral AND torsional restraint spacing, never the vertical span.
    """
    fy, fu, E, G, nu = _material(project['material'])
    member = project['member']
    L = 1000*_number(member.get('L_m'), 'Vão L', positive=True)
    restraint = member.get('restraint')
    lx,ly,lz=_buckling_lengths(member,lb_major_mm=lb_major_mm)
    lb=ly  # Legacy display field; Lz must never be inferred from this alias.
    cb = 1. if cb_major is None else _number(cb_major, 'Cb', positive=True)
    out = {key: None for key in ('major_local_Nmm','major_pos_Rd_Nmm','major_neg_Rd_Nmm',
        'minor_pos_Rd_Nmm','minor_neg_Rd_Nmm','shear_Rd_N','compression_Rd_N',
        'tension_Rd_N','support_Rd_N','Ml_Nmm','kl','major_flt_Nmm',
        'minor_local_pos_Nmm','minor_local_neg_Nmm','compression_global_Rd_N',
        'Nl_N','Nex_N','Ney_N','Nez_N','Ne_N','tension_gross_Rd_N')}
    out.update(Lx_buckling_mm=lx,Ly_buckling_mm=ly,Lz_buckling_mm=lz,restraint_model=restraint)
    for sign in ('pos','neg'):
        for key in (f'Me_minor_{sign}_Nmm',f'Wc_minor_{sign}_mm3',f'Ml_minor_{sign}_Nmm',
                    f'Mdist_minor_{sign}_Nmm',f'minor_{sign}_distortion_Nmm',f'minor_{sign}_flt_Nmm'):
            out[key]=None
    memory, limitations = [], []
    beam_issues = _plate_limit_messages(props)
    boundaries = []
    if member.get('end_fork') is not True:
        boundaries.append('É necessário impedimento lateral e torcional tipo garfo nos dois apoios.')
    if member.get('load_at_shear_center') is not True:
        boundaries.append('A rota implementada não resolve a torção de cargas fora do centro de torção.')
    if member.get('warping_free') is not True:
        boundaries.append('As expressões adotadas exigem empenamento livre nas extremidades.')
    for scope in ('major_pos','major_neg','minor_pos','minor_neg','compression'):
        if boundaries:
            limitations.append(_lim(scope+'_boundary',' '.join(boundaries),
                'NBR 14762:2010, 9.7.2, 9.8.2.2 e Anexo E',scope))
    if beam_issues:
        for scope in ('major','minor'):
            limitations.append(_lim(scope+'_plate_limits',' '.join(beam_issues),'NBR 14762:2010, Tabela 4',scope))
    else:
        try:
            kl, origin = major_local_coefficient(props)
            Ml = kl*math.pi**2*E/(12*(1-nu*nu)*(props['H']/props['t'])**2)*props['Wx']
            lam = math.sqrt(props['Wx']*fy/Ml)
            Wef = props['Wx']*reduction(lam)
            local = Wef*fy/1.1
            out.update(kl=kl,Ml_Nmm=Ml,major_local_Nmm=local,Wef_major_mm3=Wef)
            memory += [
                _mem('Coeficiente local de flexão maior',r'k_\ell=k_\ell(b_f/b_w,D/b_w)',
                    f"bf/bw={props['B']/props['H']:.8g}; D/bw={props['D']/props['H']:.8g}",kl,'',origin),
                _mem('Momento crítico local da seção completa',r'M_\ell=\frac{k_\ell\pi^2E W}{12(1-\nu^2)(b_w/t)^2}',
                    f"kℓ={kl:.9g}; E={E:g}; W={props['Wx']:.9g}; bw/t={props['H']/props['t']:.9g}",Ml,'N mm','NBR 14762:2010, 9.8.2.1 b'),
                _mem('Módulo efetivo de flexão maior',r'\lambda_p=\sqrt{Wf_y/M_\ell};\quad W_{ef}=W\begin{cases}1&\lambda_p\leq0.673\\(1-0.22/\lambda_p)/\lambda_p&\lambda_p>0.673\end{cases}',
                    f'λp={lam:.9g}; Wef={Wef:.9g}',local,'N mm','9.8.2.1 b; MRd=Wef fy/1,1 (ramo integral até λp=0,673)')]
        except PlateDomainError as exc:
            limitations.append(_lim('major_mse_domain',str(exc),'NBR 14762:2010, Tabelas 12 e 13','major'))
    # One unstiffened web, with no post-buckling tension-field enhancement.
    h,t=props['h'],props['t']
    if h/t <= 200+1e-9:
        kv=5.
        slender=h/t; transition1=1.08*math.sqrt(E*kv/fy); transition2=1.4*math.sqrt(E*kv/fy)
        if slender <= transition1:
            V=.6*fy*h*t/1.1; branch='escoamento'
        elif slender <= transition2:
            V=.65*t*t*math.sqrt(E*kv*fy)/1.1; branch='transição'
        else:
            V=.905*E*kv*t**3/(h*1.1); branch='flambagem elástica'
        out['shear_Rd_N']=V
        memory.append(_mem('Cisalhamento da alma',r'V_{Rd}=\{0.6f_yht;\ 0.65t^2\sqrt{Ek_vf_y};\ 0.905Ek_vt^3/h\}/1.1',
            f'h/t={slender:.8g}; kv=5; limites={transition1:.8g}/{transition2:.8g}; ramo {branch}',V,'N','NBR 14762:2010, 9.8.3'))
    else:
        limitations.append(_lim('shear_domain','Alma sem enrijecedores transversais com h/t superior a 200.','Tabela 4 e 9.8.3','shear'))
    elastic = _elastic(props,E,G,lx,ly,lz)
    out.update({k:float(v) for k,v in elastic.items()})
    memory.append(_mem('Flambagem global elástica',r'N_e=\min(N_{ey},N_{exz})',
        f"Lx={lx:g}; Ly={ly:g}; Lz={lz:g}; Nex={elastic['Nex_N']:.9g}; Ney={elastic['Ney_N']:.9g}; Nez={elastic['Nez_N']:.9g}",
        elastic['Ne_N'],'N','NBR 14762:2010, 9.7.2.2; Kx=Ky=Kz=1'))
    local=out['major_local_Nmm']
    if local is not None and not boundaries:
        Me=cb*props['r0']*math.sqrt(elastic['Ney_N']*elastic['Nez_N'])
        lam0=math.sqrt(props['Wx']*fy/Me); chi=_chi_flt(lam0)
        lp_flt=math.sqrt(chi*props['Wx']*fy/out['Ml_Nmm'])
        Wcef=props['Wx']*reduction(lp_flt)
        flt=chi*Wcef*fy/1.1
        out.update(major_flt_Nmm=flt,Me_major_Nmm=Me,chi_flt_major=chi,Cb_major=cb,Lb_major_mm=lb)
        memory.append(_mem('FLT de flexão maior',r'M_e=C_b r_0\sqrt{N_{ey}N_{ez}};\quad M_{Rd,FLT}=\chi_{FLT}W_{c,ef}f_y/1.1',
            f'Cb={cb:.9g}; Ly={ly:g}; Lz={lz:g}; Me={Me:.9g}; λ0={lam0:.9g}; χFLT={chi:.9g}; Wcef={Wcef:.9g}',
            flt,'N mm','NBR 14762:2010, 9.8.2.2; Cb fornecido pelo diagrama ou 1 conservador'))
        for sign in ('pos','neg'):
            scope='major_'+sign
            if restraint=='panel' and sign=='neg':
                capacity, factor, failures=_panel_capacity(project,props,local,fy)
                out['major_neg_Rd_Nmm']=capacity
                if failures:
                    limitations.append(_lim('annex_f_domain','; '.join(failures),'NBR 14762:2010, Anexo F',scope))
                else:
                    out['panel_R']=factor
                    memory.append(_mem('Mesa tracionada ligada ao painel',r'M_{Rd}=R W_{ef}f_y/1.1',
                        f'R={factor:g}; MRd,local={local:.9g}; telha de aço, parafusos padronizados, todos os limites F.1 conferidos',capacity,'N mm','NBR 14762:2010, F.1 e Tabela F.1'))
                continue
            if restraint=='panel' and project['panel'].get('proven_stiffness') is not True:
                limitations.append(_lim('panel_positive_restraint','A eficácia da contenção da mesa comprimida pelo painel não foi comprovada.','9.8.2.2',scope))
                continue
            base=local if restraint in ('continuous','panel') else min(local,flt)
            dist,detail=_distortion_capacity(props,fy,member.get('mdist_major_kNm'),False,limitations,scope)
            out[scope+'_distortion']=detail
            if detail['waived'] or dist is not None:
                out[scope+'_Rd_Nmm']=base if dist is None else min(base,dist)
            if sign=='pos':
                memory.append(_mem('Flambagem distorcional da flexão maior',r'M_{Rd,dist}=\rho_{dist}Wf_y/1.1',
                    str(detail),dist if dist is not None else ('dispensada' if detail['waived'] else 'pendente'),'N mm','9.8.2.3 e Tabela 14'))
    # Minor-axis local yielding and Annex E: one joint effective section for
    # each signed state. Continuous MAJOR restraint does not waive this check.
    if props['family']=='Ue' and not beam_issues:
        wyield=min(props['Wy_web'],props['Wy_edge'])
        nominal=wyield*fy
        out['Wyield_minor_mm3']=wyield
        out['minor_yield_Nmm']=nominal
        source=member.get('minor_critical_source','').strip() or 'Origem externa não informada.'
        minor_dist_excluded=member.get('exclude_minor_distortion') is True
        memory.append(_mem('Flexão menor Ue: método da resistência direta',
            r'M_y=Wf_y;\quad W=\min(W_{y,alma},W_{y,borda});\quad '+
            (r'M_{Rd}=\min(M_{Re},M_{R\ell})/1.1' if minor_dist_excluded else r'M_{Rd}=\min(M_{Re},M_{R\ell},M_{Rdist})/1.1'),
            f'W={wyield:.9g}; fy={fy:g}; origem dos críticos: {source}',nominal,'N mm',
            'NBR 14762:2010, C.1, C.2 e C.4. Não se estende a dispensa da Tabela 14 à flexão menor.'+
            (' Resultado condicional: distorção excluída do escopo pelo usuário.' if minor_dist_excluded else '')))
        if member.get('mdist_minor_kNm') is not None:
            memory.append(_mem('Campo antigo de distorção menor', '',
                f"mdist_minor_kNm={member['mdist_minor_kNm']}",
                'Valor legado preservado para auditoria, sem aplicação automática a nenhum sentido. Usar os campos positivos/negativos próprios.',
                '', 'Rastreabilidade dos dados de entrada'))
        for sign,direction in (('pos',1.),('neg',-1.)):
            scope='minor_'+sign
            ml,mdist=_minor_critical(member,sign)
            dist_absent=member.get('minor_critical_mode')=='automatic' and member.get(f'_minor_{sign}_distortional_absent') is True
            dist_excluded=member.get('exclude_minor_distortion') is True
            dist_omitted=dist_absent or dist_excluded
            out['Ml_minor_'+sign+'_Nmm']=ml
            out['Mdist_minor_'+sign+'_Nmm']=mdist
            out[scope+'_method']='MRD_C4'
            out[scope+'_distortion_excluded']=dist_excluded
            out[scope+'_conditional']=dist_excluded
            out[scope+'_distortional_absence_verified']=dist_absent
            detail={key:None for key in ('MRe_Nmm','MRl_Nmm','MRdist_Nmm','MRk_Nmm','Rd_Nmm')}
            for value,label in ((ml,'local'),(mdist,'distortional')):
                if label=='distortional' and dist_omitted:
                    continue
                if value is None:
                    portuguese='local' if label=='local' else 'distorcional'
                    field=('ml' if label=='local' else 'mdist')+f'_minor_{sign}_kNm'
                    limitations.append(_lim(scope+'_'+label+'_critical',
                        f'Falta o momento crítico elástico {portuguese} do sentido My{"+" if direction>0 else "−"}: informar {field}, obtido por análise de estabilidade da seção nesse sentido. '
                        'O sentido oposto e o campo legado não substituem este dado.',
                        'NBR 14762:2010, C.1, C.2 e C.4; 9.3 e 9.8.2.3',scope))
            if dist_excluded:
                memory.append(_mem('Distorção da flexão menor excluída do escopo, '+sign,'','',
                    'Exclusão expressa pelo usuário. A resistência e a rigidez deste sentido são condicionais, sem o ramo distorcional. '
                    'Não constitui dispensa normativa nem prova de ausência do modo. O crítico disponível permanece registrado para auditoria.',
                    '', 'Hipótese de escopo do cálculo; não substitui a verificação de C.4.3'))
            elif dist_absent:
                memory.append(_mem('Modo distorcional não aplicável, '+sign,'','',
                    'Ramo omitido pela evidência da análise automática para este sentido. Não equivale a um momento crítico infinito. Consulte a identificação modal.',
                    '', 'NBR 14762:2010, C.2; evidência de estabilidade elástica anexa à memória'))
            if mdist is not None:
                dist_result=distortion_resistance(nominal,mdist)
                dist_characteristic=float(dist_result['MRdist_Nmm'])
                detail.update(dist_result)
                out[scope+'_distortion_Nmm']=dist_characteristic/1.1
                memory.append(_mem(('Distorção Ue no eixo menor, somente auditoria, ' if dist_excluded else 'Distorção Ue no eixo menor, ')+sign,
                    r'\lambda_{dist}=\sqrt{Wf_y/M_{dist}};\quad M_{Rdist}=\rho_{dist}Wf_y',
                    f"Mdist={mdist:.9g}; Wfy={nominal:.9g}; λdist={detail['lambda_dist']:.9g}; ρdist={detail['rho_dist']:.9g}",
                    dist_characteristic/1.1,'N mm','NBR 14762:2010, C.4.3; coeficiente de resistência 1,10'))
            if not boundaries:
                me,wc,cs=_minor_elastic_moment(props,elastic,direction)
                out['Me_minor_'+sign+'_Nmm']=me
                out['Wc_minor_'+sign+'_mm3']=wc
                global_result=global_resistance(nominal,me)
                global_characteristic=float(global_result['MRe_Nmm'])
                detail.update(global_result)
                out[scope+'_flt_Nmm']=global_characteristic/1.1
                memory.append(_mem('FLT Ue no eixo menor por MRD, '+sign,
                    r'M_e=C_sN_{ex}[j+C_s\sqrt{j^2+r_0^2N_{ez}/N_{ex}}]/C_m;\quad\lambda_0=\sqrt{Wf_y/M_e};\quad M_{Re}=\chi_{FLT}Wf_y',
                    f"Cs={cs}; Cm=1; j={props['j']:.9g}; Nex={elastic['Nex_N']:.9g}; Nez={elastic['Nez_N']:.9g}; Me={me:.9g}; "
                    f"Wc do lado comprimido={wc:.9g}; W de primeiro escoamento={wyield:.9g}; λ0={detail['lambda0']:.9g}; χFLT={detail['chi_global']:.9g}",
                    global_characteristic/1.1,'N mm','NBR 14762:2010, Anexo E e C.4.1. C.4 usa W da fibra que primeiro escoa, distinto de Wc de 9.8.2.2.'))
                if ml is not None:
                    local_result=local_resistance(global_characteristic,ml)
                    local_characteristic=float(local_result['MRl_Nmm'])
                    detail.update(local_result)
                    out['minor_local_'+sign+'_Nmm']=local_characteristic/1.1
                    memory.append(_mem('Flambagem local Ue no eixo menor por MRD, '+sign,
                        r'\lambda_\ell=\sqrt{M_{Re}/M_\ell};\quad M_{R\ell}=\rho_\ell M_{Re};\quad\rho_\ell=\begin{cases}1&\lambda_\ell\leq0.776\\(1-0.15/\lambda_\ell^{0.8})/\lambda_\ell^{0.8}&\lambda_\ell>0.776\end{cases}',
                        f"Mℓ={ml:.9g}; MRe={detail['MRe_Nmm']:.9g}; λℓ={detail['lambda_local']:.9g}; ρℓ={detail['rho_local']:.9g}",
                        local_characteristic/1.1,'N mm','NBR 14762:2010, C.4.2; ramo local inclui interação com flambagem global'))
                if ml is not None and (mdist is not None or dist_omitted):
                    detail=minor_mrd(nominal,me,ml,mdist,distortional_absent=dist_absent,
                                     distortional_excluded=dist_excluded)
                    out[scope+'_Rd_Nmm']=detail['Rd_Nmm']
                    memory.append(_mem('Resistência final Ue no eixo menor, '+sign,
                        r'M_{Rd}=\min(M_{Re},M_{R\ell})/1.10' if dist_omitted else r'M_{Rd}=\min(M_{Re},M_{R\ell},M_{Rdist})/1.10',
                        f"MRe={detail['MRe_Nmm']:.9g}; MRℓ={detail['MRl_Nmm']:.9g}; MRdist="+('excluído do escopo' if dist_excluded else 'não aplicável' if dist_absent else f"{detail['MRdist_Nmm']:.9g}"),
                        detail['Rd_Nmm'],'N mm','NBR 14762:2010, C.4'+('; resultado condicional: C.4.3 excluído por opção do usuário' if dist_excluded else '')))
            out[scope+'_mrd']=detail
    elif not beam_issues:
        for sign,direction in (('pos',1.),('neg',-1.)):
            scope='minor_'+sign
            try:
                eff=effective_u(props,project['material'],0.,direction,reference_stress=fy)
                local_minor=eff['moment_Nmm']/1.1
                out['minor_local_'+sign+'_Nmm']=local_minor
                memory.append(_mem('Flexão menor local, '+sign,r'M_{Rd,local}=M(\max|\sigma|=f_y)/1.1',
                    f"MLE iterativo; Aef={eff['A']:.9g}; xef={eff['xc']:.9g}; Iyef={eff['Iy']:.9g}; fibra original de referência conservadora",local_minor,'N mm','NBR 14762:2010, 9.2.2 e 9.8.2.1 a'))
                if boundaries:
                    continue
                j=props['j']
                Me_minor,Wc,cs=_minor_elastic_moment(props,elastic,direction)
                lambda_minor=math.sqrt(Wc*fy/Me_minor); chi_minor=_chi_flt(lambda_minor)
                eff_flt=effective_u(props,project['material'],0.,direction,
                    reference_stress=chi_minor*fy,compression_only=True)
                cap_flt=eff_flt['moment_Nmm']/1.1
                out[scope+'_Rd_Nmm']=min(local_minor,cap_flt)
                out[scope+'_flt_Nmm']=cap_flt
                memory.append(_mem('FLT da flexão menor, '+sign,r'M_e=C_sN_{ex}[j+C_s\sqrt{j^2+r_0^2N_{ez}/N_{ex}}]/C_m',
                    f'Cs={-1 if direction>0 else 1}; Cm=1; j={j:.9g}; Me={Me_minor:.9g}; λ0={lambda_minor:.9g}; χFLT={chi_minor:.9g}; MLE a χFLT fy',
                    cap_flt,'N mm','NBR 14762:2010, Anexo E e 9.8.2.2'))
            except PlateDomainError as exc:
                limitations.append(_lim(scope+'_domain',str(exc),'NBR 14762:2010, Tabelas 4, 5, 6 e Anexo E',scope))
    comp_issues=_plate_limit_messages(props,compression=True)
    if comp_issues:
        limitations.append(_lim('compression_plate_limits',' '.join(comp_issues),'NBR 14762:2010, Tabela 4','compression'))
    elif not boundaries:
        try:
            ka,origin=axial_local_coefficient(props)
            Nl=ka*math.pi**2*E/(12*(1-nu*nu)*(props['H']/props['t'])**2)*props['A']
            lambda0=math.sqrt(props['A']*fy/elastic['Ne_N'])
            chi=.658**(lambda0**2) if lambda0<=1.5 else .877/lambda0**2
            lp=math.sqrt(chi*props['A']*fy/Nl)
            rho=1. if lp<=.776 else (1-.15/lp**.8)/lp**.8
            Aef=props['A']*rho
            Nc=chi*Aef*fy/1.2
            out.update(Nl_N=Nl,kl_compression=ka,chi_compression=chi,Aef_compression_mm2=Aef,compression_global_Rd_N=Nc)
            dist,detail=_distortion_capacity(props,fy,member.get('ndist_kN'),True,limitations,'compression')
            out['compression_distortion']=detail
            if detail['waived'] or dist is not None:
                out['compression_Rd_N']=Nc if dist is None else min(Nc,dist)
            slender=max(L/props['rx'],lb/props['ry'])
            if slender>200+1e-9:
                limitations.append(_lim('compression_slenderness',f'Esbeltez geométrica máxima {slender:.3f} excede 200.','NBR 14762:2010, 9.7.4','compression'))
            memory.append(_mem('Compressão por MSE e instabilidade global',r'N_{c,Rd}=\chi A_{ef}f_y/1.2;\quad\lambda_p=\sqrt{\chi A f_y/N_\ell}',
                f'kℓ={ka:.9g}; Nℓ={Nl:.9g}; λ0={lambda0:.9g}; χ={chi:.9g}; λp={lp:.9g}; Aef={Aef:.9g}; {origin}',Nc,'N','NBR 14762:2010, 9.7.2; K=1; Lx=L e Ly=Lz=Lb somente para contenção discreta'))
            memory.append(_mem('Flambagem distorcional na compressão',r'N_{c,Rd,dist}=\chi_{dist}Af_y/1.2',str(detail),
                dist if dist is not None else ('dispensada' if detail['waived'] else 'pendente'),'N','9.7.3 e Tabela 11'))
        except PlateDomainError as exc:
            limitations.append(_lim('compression_mse_domain',str(exc),'NBR 14762:2010, Tabelas 9 e 10','compression'))
    out['tension_gross_Rd_N']=min(props['A']*fy/1.1,props['A']*fu/1.35)
    tension=project.get('tension',{})
    for key in ('an0_mm2','an_mm2','ct'):
        if tension.get(key) is not None:
            provided=_number(tension[key],key,positive=True)
            if (key=='ct' and provided>1) or (key!='ct' and provided>props['A']+1e-8):
                raise ValueError('As áreas líquidas An0 e An não podem exceder A, e Ct deve ser ≤1.')
    if all(tension.get(key) is not None for key in ('an0_mm2','an_mm2','ct')):
        an0=_number(tension['an0_mm2'],'Área líquida An0',positive=True)
        an=_number(tension['an_mm2'],'Área líquida An',positive=True)
        ct=_number(tension['ct'],'Coeficiente Ct',positive=True)
        if an0>props['A']+1e-8 or an>props['A']+1e-8 or ct>1:
            raise ValueError('As áreas líquidas An0 e An não podem exceder A, e Ct deve ser ≤1.')
        out['tension_Rd_N']=min(props['A']*fy/1.1,an0*fu/1.35,ct*an*fu/1.65)
        memory.append(_mem('Tração: três estados limites da barra',r'N_{t,Rd}=\min(Af_y/1.10,A_{n0}f_u/1.35,C_tA_nf_u/1.65)',
            f"A={props['A']:.9g}; An0={an0:.9g}; An={an:.9g}; Ct={ct:.9g}; áreas e Ct fornecidos de verificação externa",out['tension_Rd_N'],'N','NBR 14762:2010, 9.6.2; não dimensiona os conectores'))
    else:
        limitations.append(_lim('tension_connection','A capacidade final de tração depende de An0, An e Ct. Preencher os três dados calculados a partir da seção líquida e da ligação; a resistência bruta é apenas um limite superior.','NBR 14762:2010, 9.6.2','tension'))
    tension_slenderness=max(L/props['rx'],lb/props['ry'])
    out['tension_slenderness']=tension_slenderness
    memory.append(_mem('Esbeltez de barra tracionada',r'\max(L_x/r_x,L_y/r_y)\leq300\quad\text{(recomendação)}',
        f'Lx={L:g}; Ly={lb:g}; '+('recomendação atendida' if tension_slenderness<=300 else 'recomendação não atendida; avaliar o projeto'),tension_slenderness,'','NBR 14762:2010, 9.6.3'))
    if tension_slenderness>300:
        limitations.append(_lim('tension_slenderness',f'Esbeltez {tension_slenderness:.3f} excede a recomendação 300; exige avaliação explícita do projetista.','NBR 14762:2010, 9.6.3 (recomendação)','tension'))
    memory.append(_mem('Tração: limite superior da seção bruta',r'N_{t,Rd}\leq\min(Af_y/1.1,Af_u/1.35)',
        f"A={props['A']:.9g}; fy={fy:g}; fu={fu:g}; limite independente dos dados da ligação",out['tension_gross_Rd_N'],'N','NBR 14762:2010, 9.6.2; não substitui ruptura na ligação'))
    support,smem,slim=support_capacity(project,props,fy)
    out['support_Rd_N']=support;memory.extend(smem);limitations.extend(slim)
    out['memory']=memory;out['limitations']=limitations
    return out


def service_stiffness(profile, material, props, mx_nmm, my_nmm, n_n=0, *, project=None):
    """Effective elastic stiffness for a SINGLE concurrent signed load state.

    It never combines effective inertias from two independent bending states.
    The MSE uniaxial route supplies only the major stiffness relevant there.
    """
    fy,fu,E,G,nu=_material(material)
    mx=_number(mx_nmm,'Mx de serviço');my=_number(my_nmm,'My de serviço');normal=_number(n_n,'N de serviço')
    memory=[]
    result={key:None for key in ('A','Ix','Iy','Ixy','xc','yc')}
    result.update(converged=False,method='unavailable',memory=memory,limitations=[])
    ignore_restraints=project is not None and project['member'].get('deflection_ignore_restraints') is True
    result['deflection_ignore_restraints']=ignore_restraints
    if ignore_restraints:
        length=1000*_number(project['member'].get('L_m'),'Vão L',positive=True)
        result.update(service_global_length_mm=length,service_Lx_mm=length,service_Ly_mm=length,service_Lz_mm=length)
        memory.append(_mem('Contenções desconsideradas na flecha',r'L_{ELS}=L',
            'Adota-se o vão integral no modelo de flecha. Quando C.5 exigir Me, seus comprimentos de estabilidade também são iguais a L. '
            'As contenções continuam consideradas nas verificações de resistência ELU.',length,'mm',
            'Hipótese de serviço autorizada pelo usuário; não comprova a eficácia de contenções'))
    try:
        if mx==0 and my==0 and normal==0:
            result.update({key:float(props[key]) for key in ('A','Ix','Iy','Ixy','xc','yc')})
            result.update(converged=True,method='gross_MLE_verified')
            return result
        if my==0 and normal==0:
            issues=_plate_limit_messages(props)
            if issues:
                raise PlateDomainError(' '.join(issues))
            kl,origin=major_local_coefficient(props)
            Ml=kl*math.pi**2*E/(12*(1-nu*nu)*(props['H']/props['t'])**2)*props['Wx']
            lp=math.sqrt(abs(mx)/Ml)
            Ief=props['Ix']*reduction(lp)
            stress_bound=abs(mx)*props['H']/(2*Ief)
            if stress_bound>fy*(1+1e-8):
                raise PlateDomainError('A tensão de serviço excede fy; a rota de flecha elástica não é aplicável.')
            result.update(A=props['A'],Ix=Ief,Iy=props['Iy'],Ixy=0.,xc=props['xc'],yc=0.,
                converged=True,method='MSE_major')
            memory.append(_mem('Rigidez de serviço em flexão maior uniaxial',r'\lambda_{p,d}=\sqrt{|M_{ser}|/M_\ell};\quad I_{ef}=\rho(\lambda_{p,d})I',
                f'Mser={mx:.9g}; Mℓ={Ml:.9g}; λp,d={lp:.9g}; σref={stress_bound:.9g}; {origin}',Ief,'mm⁴','NBR 14762:2010, 9.8.5 b; somente Ix solicitado neste estado'))
            return result
        if props['family']=='Ue' and mx==0 and my!=0 and normal==0 and project is not None:
            member=project['member']
            sign='pos' if my>0 else 'neg'
            ml,mdist=_minor_critical(member,sign)
            dist_absent=member.get('minor_critical_mode')=='automatic' and member.get(f'_minor_{sign}_distortional_absent') is True
            dist_excluded=member.get('exclude_minor_distortion') is True
            dist_omitted=dist_absent or dist_excluded
            result.update(minor_distortion_excluded=dist_excluded,conditional=dist_excluded,
                          distortional_absence_verified=dist_absent)
            compatible=all(member.get(key) is True for key in ('end_fork','load_at_shear_center','warping_free'))
            if ml is not None and (mdist is not None or dist_omitted) and compatible:
                issues=_plate_limit_messages(props)
                if issues:
                    raise PlateDomainError(' '.join(issues))
                lx,ly,lz=_buckling_lengths(member,ignore_restraints=ignore_restraints)
                elastic=_elastic(props,E,G,lx,ly,lz)
                me,wc,cs=_minor_elastic_moment(props,elastic,1. if my>0 else -1.)
                data=minor_service(me,ml,mdist,my,props['Iy'],distortional_absent=dist_absent,
                                   distortional_excluded=dist_excluded)
                iyef=data['Ief_mm4']
                stress_bound=abs(my)*max(props['xc']+props['t']/2,props['B']-props['t']/2-props['xc'])/iyef
                if stress_bound>fy*(1+1e-8):
                    raise PlateDomainError('A tensão de serviço com Iy,ef do MRD excede fy; a rota de flecha elástica não é aplicável.')
                result.update(A=props['A'],Ix=props['Ix'],Iy=iyef,Ixy=0.,xc=props['xc'],yc=props['yc'],
                              converged=True,method='MRD_C5_minor',minor_mrd=data,
                              Me_service_Nmm=me,service_global_length_mm=ly,
                              service_Lx_mm=lx,service_Ly_mm=ly,service_Lz_mm=lz)
                if dist_excluded:
                    memory.append(_mem('Distorção excluída da rigidez de serviço, '+sign,'',
                        'Mdist informado='+('não informado' if mdist is None else f'{mdist:.9g} N mm'),
                        'Rigidez condicional sem o ramo distorcional por opção do usuário. Não representa ausência física nem dispensa normativa.',
                        '', 'Hipótese de escopo do cálculo; C.5 aplicado apenas aos ramos mantidos'))
                memory.append(_mem('Rigidez de serviço em flexão menor uniaxial por MRD',
                    r'I_{y,ef}=\min(1,M_{R,ser}/|M_n|)I_y;\quad M_{R,ser}=\min(M_{Re,ser},M_{R\ell,ser})' if dist_omitted else r'I_{y,ef}=\min(1,M_{R,ser}/|M_n|)I_y;\quad M_{R,ser}=\min(M_{Re,ser},M_{R\ell,ser},M_{Rdist,ser})',
                    f"Mn={my:.9g}; Lx={lx:g}; Ly={ly:g}; Lz={lz:g}; Me={me:.9g}; Mℓ={ml:.9g}; Mdist="+('excluído do escopo' if dist_excluded else 'não aplicável' if dist_absent else f'{mdist:.9g}')+f"; MRser={data['MRser_Nmm']:.9g}; "
                    f"Iy={props['Iy']:.9g}; razão={data['ratio']:.9g}; σref={stress_bound:.9g}",
                    iyef,'mm⁴','NBR 14762:2010, C.5 e C.4. Substitui-se Wfy por |Mn|, sem divisão por γ. '
                    'Rigidez equivalente somente para My uniaxial; não define seção efetiva conjunta para biaxial ou N.'))
                return result
        if props['family']=='U':
            effective=effective_u(props,material,mx,my,normal)
        else:
            effective=prove_gross_lipped(props,material,mx,my,normal)
        coeff=stress_coefficients(effective,props,mx,my,normal)
        # The bounding rectangle includes all original steel fibres. It may
        # conservatively reject a state whose extreme corner contains no steel.
        peak=max(abs(stress(coeff,(x,y))) for x in (-props['t']/2,props['B']-props['t']/2)
                 for y in (-props['H']/2,props['H']/2))
        if peak>fy*(1+1e-8):
            raise PlateDomainError('A envoltória conservadora de tensões de serviço excede fy; não se declara flecha elástica validada.')
        result.update({key:float(effective[key]) for key in ('A','Ix','Iy','Ixy','xc','yc')})
        result.update(converged=True,method=effective['method'],plates=effective.get('plates',[]))
        memory.append(_mem('Seção efetiva para os esforços conjuntos',r'\boldsymbol\kappa=E^{-1}\begin{bmatrix}I_x&I_{xy}\\I_{xy}&I_y\end{bmatrix}^{-1}\begin{bmatrix}M_x\\M_y\end{bmatrix}',
            f"Mx={mx:.9g}; My={my:.9g}; N={normal:.9g}; Aef={effective['A']:.9g}; Ix={effective['Ix']:.9g}; Iy={effective['Iy']:.9g}; Ixy={effective['Ixy']:.9g}; iterações={effective.get('iterations',0)}",effective['A'],'mm²','NBR 14762:2010, 9.2.2/9.2.3 e 9.8.5 a; momentos transportados ao CG efetivo quando N≠0'))
        for plate in effective.get('plates',[]):
            memory.append(_mem('Placa de serviço: '+plate['id'],r'\lambda_p=(b/t)/(0.95\sqrt{kE/\sigma});\quad b_{ef}=\rho b',
                f"σa={plate.get('sigma_a',0):.8g}; σb={plate.get('sigma_b',0):.8g}; k={plate.get('k')}; λp={plate.get('lambda_p')}; método={plate.get('method')}",plate.get('rho',1.),'','Tabelas 5/6 ou prova uniforme conservadora para 9.2.3'))
        return result
    except PlateDomainError as exc:
        result['limitations']=[_lim('service_domain',str(exc),'NBR 14762:2010, 9.2, 9.8.5 e Tabela 4','service')]
        return result
