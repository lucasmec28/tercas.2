"""Elastic minor-axis criticals for symmetric, unperforated lipped channels.

The rounded FSM / sharp cFSM procedure follows Li (2011), 6.2.2,
and AISI RP21-01. This is an elastic numerical provider, not an AISI resistance
calculation. Global instability remains a separate NBR 14762 Annex E check.

Element matrices and transverse equilibrium extension are from pyCUFSM 0.2.0
(Brooks Smith; original CUFSM by B. Schafer, S. Adany and Z. Li; AFL-3.0).
We construct the local kinematic basis independently: the release's adjacency
lookup in base_vectors uses np.any and otherwise selects element zero for all
subnodes. The G/D longitudinal basis and corner compatibility are rebuilt in
physical_basis to bypass separate warping/orientation indexing errors.
No installed package files are changed. See project documentation.
"""
from __future__ import annotations

from copy import deepcopy
from functools import lru_cache
from importlib.metadata import version
import math
from threading import RLock
from time import perf_counter
from typing import Any
import warnings

import numpy as np
from scipy.linalg import eigh
from scipy.optimize import minimize_scalar
from threadpoolctl import threadpool_limits
from pycufsm.pre.cutwp import prop2
from pycufsm.solve.analysis import analysis
from .physical_basis import BASIS_VERSION, physical_gd_bases


REFERENCE = "Li (2011), 6.2.2; AISI RP21-01 (2021), metodologia e Exemplo I; NBR 14762:2010, Anexo C.2."
METHOD = "FSM com cantos arredondados e separação cFSM local/distorcional em seção auxiliar de cantos retos."
MOMENT_TOLERANCE = .01
WAVE_TOLERANCE = .05
GLOBAL_SEPARATION = .05
SAMPLE_COUNT = 31
MAX_NODES = 180
_LOCK = RLock()


def _mesh(h, b, d, t, ri, width, angle, rounded):
    H, B, D = h-t, b-t, d-t/2
    vertices = np.array([[B,H/2-D],[B,H/2],[0,H/2],
                         [0,-H/2],[B,-H/2],[B,-H/2+D]], dtype=float)
    points = [vertices[0]]

    def line(end):
        start = np.asarray(points[-1])
        count = max(2, int(math.ceil(np.linalg.norm(end-start)/width)))
        if len(points)+count>MAX_NODES:
            raise ValueError("A geometria exige mais de 180 nós por malha; informe críticos externos após análise específica.")
        points.extend(start+(end-start)*i/count for i in range(1,count+1))

    if not rounded:
        for end in vertices[1:]:
            line(end)
    else:
        radius = ri+t/2
        for previous, corner, following in zip(vertices, vertices[1:], vertices[2:]):
            incoming = (corner-previous)/np.linalg.norm(corner-previous)
            outgoing = (following-corner)/np.linalg.norm(following-corner)
            start, end = corner-radius*incoming, corner+radius*outgoing
            center = start+radius*outgoing
            line(start)
            a0 = math.atan2(start[1]-center[1], start[0]-center[0])
            cross = incoming[0]*outgoing[1]-incoming[1]*outgoing[0]
            sweep = math.copysign(math.pi/2, cross)
            count = int(math.ceil(90/angle))
            if len(points)+count>MAX_NODES:
                raise ValueError("A geometria exige mais de 180 nós por malha; informe críticos externos após análise específica.")
            points.extend(center+radius*np.array([math.cos(a0+sweep*i/count),
                                                  math.sin(a0+sweep*i/count)])
                          for i in range(1,count+1))
            points[-1] = end
        line(vertices[-1])
    return np.asarray(points)


class _Solver:
    """Single-half-wave S-S finite strips, stress referenced to 1 kN m."""
    def __init__(self, geometry, E, nu, width, angle, rounded=False):
        h,b,d,t,ri = geometry
        self.h = h
        xy = _mesh(h,b,d,t,ri,width,angle,rounded)
        if len(xy)>MAX_NODES:
            raise ValueError("A geometria exige mais de 180 nós por malha; informe críticos externos após análise específica.")
        nn = len(xy)
        self.nodes = np.ones((nn,8))
        self.nodes[:,0] = np.arange(nn)
        self.nodes[:,1:3] = xy
        self.elements = np.array([[i,i,i+1,t,0] for i in range(nn-1)],dtype=float)
        self.section = prop2(xy,self.elements[:,1:4])
        self.props = np.array([[0,E,E,nu,nu,E/(2*(1+nu))]],dtype=float)
        self.el_props = analysis.elem_prop(self.nodes,self.elements)
        self._cache = {}
        if rounded:
            return
        physical = physical_gd_bases(self.nodes,self.elements,self.props,self.el_props,h)
        basis,n_local = physical['basis'],physical['n_local']
        self.basis_audit = physical['audit']
        self.longitudinal_global_basis = physical['global_y']
        self.longitudinal_distortional_basis = physical['distortional_y']
        self.longitudinal_metric = physical['metric']
        self.sectorial_omega = physical['omega']
        D = basis[:,4:6]
        axial = np.zeros(4*nn,dtype=bool)
        axial[1:2*nn:2] = True
        self.Da = D.copy()
        self.Da[~axial,:] = 0
        self.Dt = D.copy()
        self.Dt[axial,:] = 0
        self.Ga = basis[:,:4].copy()
        self.Ga[~axial,:] = 0
        self.Gt = basis[:,:4].copy()
        self.Gt[axial,:] = 0
        # Local kinematics: rotations at every node; transverse translations at
        # subnodes/free edges; no corner translation or longitudinal motion.
        columns = []
        for i in range(nn):
            col = np.zeros(4*nn)
            col[2*nn+2*i+1] = 1
            columns.append(col)
        for i in range(nn):
            if i not in (0,nn-1):
                a,z = xy[i]-xy[i-1],xy[i+1]-xy[i]
                cross = a[0]*z[1]-a[1]*z[0]
                if abs(cross)>1e-8*np.linalg.norm(a)*np.linalg.norm(z):
                    continue
            direction = xy[min(i+1,nn-1)]-xy[max(i-1,0)]
            direction /= np.linalg.norm(direction)
            col = np.zeros(4*nn)
            col[2*i],col[2*nn+2*i] = -direction[1],direction[0]
            columns.append(col)
        self.L = np.column_stack(columns)
        if self.L.shape[1]!=n_local:
            raise ValueError("Dimensão inconsistente do subespaço local.")

    def matrices(self,wave,sign):
        nodes = self.nodes.copy()
        nodes[:,7] = sign*1e6*(nodes[:,1]-self.section['cx'])/self.section['Iyy']
        return analysis.k_kg_global(nodes,self.elements,self.el_props,self.props,wave,'S-S',np.array([1]))

    def critical(self,wave,sign,family='all'):
        key = (float(wave),sign,family)
        if key in self._cache:
            return self._cache[key]
        K,Kg = self.matrices(wave,sign)
        if family=='local':
            R = self.L
            K,Kg = R.T@K@R,R.T@Kg@R
        elif family=='dist':
            R = self.Da+(wave/self.h)*self.Dt
            K,Kg = R.T@K@R,R.T@Kg@R
        elif family=='global':
            R = self.Ga+(wave/self.h)*self.Gt
            K,Kg = R.T@K@R,R.T@Kg@R
        K,Kg = (K+K.T)/2,(Kg+Kg.T)/2
        scale = np.sqrt(np.diag(K))
        if not np.all(np.isfinite(scale)) or np.any(scale<=0):
            raise ValueError("Matriz de rigidez sem diagonal positiva.")
        outer = np.outer(scale,scale)
        # K is positive definite; reciprocal symmetric eigenproblem exposes
        # nonpositive geometric energies without fake infinite/zero criticals.
        mu = float(eigh(Kg/outer,K/outer,subset_by_index=[len(K)-1,len(K)-1],
                        eigvals_only=True,check_finite=True)[0])
        value = 1/mu if mu>1e-13 else None
        self._cache[key] = value
        return value

    def absence(self,sign):
        """Certificate for all positive wavelengths within the sharp D space.

        At r=L/L0, R=Ra+r Rt and Kg(L)=Kg(L0)/r. Axial/transverse
        coupling is zero. Thus R.T Kg R=A/r+B r. Both A and B must be
        strictly negative definite with a relative numerical margin.
        """
        _,Kg = self.matrices(self.h,sign)
        A = self.Da.T@Kg@self.Da
        B = self.Dt.T@Kg@self.Dt
        cross = self.Da.T@Kg@self.Dt
        ea,eb = np.linalg.eigvalsh((A+A.T)/2),np.linalg.eigvalsh((B+B.T)/2)
        scale = max(np.linalg.norm(A),np.linalg.norm(B),1e-30)
        cross_relative = float(np.linalg.norm(cross)/scale)
        margin_a = float(-ea[-1]/max(abs(ea[0]),1e-30))
        margin_b = float(-eb[-1]/max(abs(eb[0]),1e-30))
        verified = margin_a>1e-7 and margin_b>1e-7 and cross_relative<1e-10
        return {'verified':bool(verified),'A_eigenvalues':ea.tolist(),'B_eigenvalues':eb.tolist(),
                'relative_margin_A':margin_a,'relative_margin_B':margin_b,
                'cross_block_relative_norm':cross_relative,
                'identity':'Kg_D(r)=A/r+B*r; r=L/L0>0',
                'scope':'Subespaço distorcional cFSM da seção auxiliar Ue simétrica, sob My puro constante; não é dispensa genérica de modos mistos.'}

    def minima(self,sign,family):
        lengths = np.geomspace(.05*self.h,100*self.h,SAMPLE_COUNT)
        values = [self.critical(float(w),sign,family) for w in lengths]
        minima = []
        for i in range(1,len(lengths)-1):
            left,center,right = values[i-1:i+2]
            if left is None or center is None or right is None:
                continue
            if center<left and center<=right:
                def value(log_wave):
                    result = self.critical(float(np.exp(log_wave)),sign,family)
                    if result is None:
                        raise ValueError("Ramo sem autovalor positivo durante o refinamento.")
                    return result
                opt = minimize_scalar(value,bounds=np.log([lengths[i-1],lengths[i+1]]),
                                      method='bounded',options={'xatol':1e-6,'maxiter':80})
                if not opt.success:
                    raise ValueError("O refinamento da semionda não convergiu.")
                wave = float(np.exp(opt.x))
                minima.append({'wave_mm':wave,'moment_Nmm':float(opt.fun)*1e6})
        return minima


def _select(rounded,sign,family,family_minimum,other_minimum,conventional):
    """Unique nearby stationary minimum, otherwise published FSM@cFSM-Lcr.

    Correspondence is by the independently constrained family wavelength,
    never by renaming the lowest eigenvalue of a complete signature curve.
    A factor-two window and nearest-family separation only select route1;
    ambiguity falls back to the explicitly defined published route2.
    """
    wave = family_minimum['wave_mm']
    candidates = []
    for item in conventional:
        distance = abs(math.log(item['wave_mm']/wave))
        if distance>math.log(2):
            continue
        if other_minimum is not None:
            other_distance = abs(math.log(item['wave_mm']/other_minimum['wave_mm']))
            if distance>=other_distance:
                continue
        candidates.append(item)
    if len(candidates)==1:
        selected = candidates[0]
        return {**selected,'route':'FSM arredondado: mínimo interior distinto correspondente à família cFSM',
                'cfsm_half_wave_mm':wave,'cfsm_pure_moment_Nmm':family_minimum['moment_Nmm']}
    value = rounded.critical(wave,sign)
    if value is None:
        raise ValueError(f"Não há autovalor positivo FSM na semionda {family} cFSM.")
    return {'wave_mm':wave,'moment_Nmm':value*1e6,
            'route':'FSM arredondado avaliado na semionda crítica cFSM (FSM@cFSM-Lcr)',
            'cfsm_half_wave_mm':wave,'cfsm_pure_moment_Nmm':family_minimum['moment_Nmm']}


def _level(geometry,E,nu,divisions,angle):
    h = geometry[0]
    sharp = _Solver(geometry,E,nu,h/divisions,angle)
    rounded = _Solver(geometry,E,nu,h/divisions,angle,rounded=True)
    data = {'strip_width_mm':h/divisions,'corner_angle_deg':angle,
            'sharp_nodes':len(sharp.nodes),'rounded_nodes':len(rounded.nodes),
            'half_wave_range_mm':[.05*h,100*h],'signature_samples':SAMPLE_COUNT,
            'rounded_area_mm2':float(rounded.section['A']),
            'rounded_Iy_mm4':float(rounded.section['Iyy']),'by_sign':{}}
    data['physical_basis'] = sharp.basis_audit
    for label,sign in (('pos',1),('neg',-1)):
        locals_ = sharp.minima(sign,'local')
        if len(locals_)!=1:
            raise ValueError("O ramo local cFSM não apresenta um único mínimo interior na faixa pesquisada.")
        proof = sharp.absence(sign)
        dist = None
        if not proof['verified']:
            dist_minima = sharp.minima(sign,'dist')
            if len(dist_minima)!=1:
                raise ValueError("O ramo distorcional não tem um único mínimo interior nem certificado de ausência.")
            dist = dist_minima[0]
        conventional = rounded.minima(sign,'all')
        local = _select(rounded,sign,'local',locals_[0],dist,conventional)
        distortion = None if dist is None else _select(rounded,sign,'dist',dist,locals_[0],conventional)
        guards = []
        for family,selected in (('local',local),('dist',distortion)):
            if selected is None:
                continue
            for origin,wave in (('cfsm',selected['cfsm_half_wave_mm']),('adopted',selected['wave_mm'])):
                global_value = sharp.critical(wave,sign,'global')
                family_value = sharp.critical(wave,sign,family)
                ratio = None if global_value is None or family_value is None else global_value/family_value
                guards.append({'family':family,'wave_source':origin,'wave_mm':wave,
                               'global_pure_Nmm':None if global_value is None else global_value*1e6,
                               'family_pure_Nmm':None if family_value is None else family_value*1e6,
                               'ratio_global_to_family':ratio,
                               'passed':bool(family_value is not None and (global_value is None or (ratio is not None and ratio>1+GLOBAL_SEPARATION)))})
        if not all(guard['passed'] for guard in guards):
            data['by_sign'][label] = {'error':"A família local/distorcional compete com o ramo global na seção auxiliar; separação inferior ou igual a 5%. É necessária identificação modal externa.",
                                     'global_separation_checks':guards,'local':local,'distortional':distortion,'absence':proof}
            continue
        data['by_sign'][label] = {'local':local,'distortional':distortion,'absence':proof,
                                 'rounded_stationary_minima':conventional,'global_separation_checks':guards}
    return data


def _difference(a,b,key):
    return abs(a[key]-b[key])/max(abs(a[key]),abs(b[key]))


@lru_cache(maxsize=16)
def _cached(geometry,E,nu):
    started = perf_counter()
    with _LOCK,threadpool_limits(limits=1,user_api='blas'),warnings.catch_warnings():
        warnings.simplefilter('ignore',DeprecationWarning)
        levels = [_level(geometry,E,nu,20,15),_level(geometry,E,nu,40,7.5)]
    by_sign: dict[str,dict[str,Any]] = {}
    for sign in ('pos','neg'):
        coarse,fine = [level['by_sign'][sign] for level in levels]
        error = coarse.get('error') or fine.get('error')
        if error:
            by_sign[sign] = {'status':'pending','local_Nmm':None,'distortional_Nmm':None,
                             'distortion_status':'pending','local_half_wave_mm':None,
                             'distortional_half_wave_mm':None,'convergence':{},'selected':{},'note':error}
            continue
        convergence = {}
        selected = {}
        passed = True
        for family in ('local','distortional'):
            a,b = coarse[family],fine[family]
            if a is None or b is None:
                same = a is None and b is None and coarse['absence']['verified'] and fine['absence']['verified']
                passed &= same
                convergence[family] = {'absence_verified_both_levels':bool(same)}
                selected[family] = None
                continue
            dm,dw = _difference(a,b,'moment_Nmm'),_difference(a,b,'wave_mm')
            good = dm<=MOMENT_TOLERANCE and dw<=WAVE_TOLERANCE
            passed &= good
            convergence[family] = {'moment_relative_change':dm,'wave_relative_change':dw,'passed':bool(good)}
            selected[family] = min((a,b),key=lambda item:item['moment_Nmm'])
        local,dist = selected['local'],selected['distortional']
        absence = dist is None and fine['absence']['verified'] and coarse['absence']['verified']
        by_sign[sign] = {'status':'computed' if passed else 'pending',
                         'local_Nmm':local['moment_Nmm'] if local and passed else None,
                         'distortional_Nmm':dist['moment_Nmm'] if dist and passed else None,
                         'distortion_status':'not_applicable' if absence and passed else ('computed' if passed else 'pending'),
                         'local_half_wave_mm':local['wave_mm'] if local else None,
                         'distortional_half_wave_mm':dist['wave_mm'] if dist else None,
                         'convergence':convergence,'selected':selected,
                         'note':('D ausente no modelo cFSM de My puro: ambas as formas geométricas são negativas em todas as semiondas; escopo físico conforme RP21-01.'
                                 if absence else 'Críticos local e distorcional determinados separadamente.')
                                if passed else 'Refinamento entre malhas excede a tolerância de 1% no momento ou 5% na semionda.'}
    status = 'computed' if all(item['status']=='computed' for item in by_sign.values()) else 'pending'
    memory = [{'title':'Origem dos momentos críticos automáticos','formula':r'\sigma_i=\pm\frac{10^6(x_i-x_c)}{I_y}',
               'substitution':'Momento de referência de 1 kN·m; compressão positiva. My+ comprime os lábios; My− comprime a alma.',
               'result':METHOD+' As cargas críticas puras cFSM não entram diretamente no MRD; apenas identificam família e semionda.',
               'unit':'N·mm, mm, MPa','reference':REFERENCE},
              {'title':'Convergência e alcance da análise elástica automática','formula':None,
               'substitution':'Duas malhas: h/20 e h/40; mínimo de 2 tiras por trecho reto; arcos de 15° e 7,5°; 31 semiondas logarítmicas de 0,05h a 100h, refinadas.',
               'result':'Adota-se o menor valor entre as duas malhas quando ΔM≤1% e ΔL≤5%. Esses limites medem convergência da discretização, não erro global nem margem normativa. G nas chapas=E/[2(1+ν)]. Vão, contenções, carregamento combinado e flambagem global são verificados separadamente.',
               'unit':'','reference':REFERENCE}]
    memory.append({'title':'Base física das famílias global e distorcional',
                   'formula':r'G_y=\operatorname{span}\{1,y,x,\omega\},\quad G_y^T R_{yd}D_y=0',
                   'substitution':'Coordenada setorial integrada ao longo da cadeia aberta; compatibilidade T u=−dv/ds nos dois tangentes adjacentes de cada canto.',
                   'result':'Quatro deformações globais e duas distorcionais independentes, com ortogonalidade pela métrica de área e identidades cinemáticas verificadas. O momento adotado provém da curva FSM completa.',
                   'unit':'','reference':REFERENCE})
    memory.append({'title':'Separação entre flambagem global e as famílias de seção',
                   'formula':r'M_{G,\mathrm{puro}}>1{,}05M_{\mathrm{família,puro}}',
                   'substitution':'Comparação na semionda cFSM e na semionda arredondada adotada, em ambas as malhas.',
                   'result':'Separação de 5% é um limite mínimo da implementação para evitar nomear um ramo global concorrente como local/distorcional; não é requisito da NBR, critério modal universal ou garantia de ausência de interação. Os modos da curva FSM completa permanecem acoplados. Se a comparação falhar, o sentido fica pendente. Esta guarda não substitui a verificação global pelo Anexo E.',
                   'unit':'','reference':REFERENCE})
    for sign,item in by_sign.items():
        symbol = 'My+' if sign=='pos' else 'My−'
        local_text = 'não determinado' if item['local_Nmm'] is None else f"{item['local_Nmm']/1e6:.6g} kN·m"
        dist_text = ('não aplicável' if item['distortion_status']=='not_applicable' else 'não determinado') if item['distortional_Nmm'] is None else f"{item['distortional_Nmm']/1e6:.6g} kN·m"
        memory.append({'title':f'Críticos automáticos — {symbol}','formula':None,
                       'substitution':str(item['convergence']),
                       'result':f"Mlocal={local_text}; Mdist={dist_text}. {item['note']}",
                       'unit':'kN·m','reference':REFERENCE})
        for index,level in enumerate(levels,1):
            checks = level['by_sign'][sign].get('global_separation_checks',[])
            descriptions = []
            for check in checks:
                global_text = 'sem autovalor positivo' if check['global_pure_Nmm'] is None else f"{check['global_pure_Nmm']/1e6:.6g} kN·m"
                family_text = 'não determinado' if check['family_pure_Nmm'] is None else f"{check['family_pure_Nmm']/1e6:.6g} kN·m"
                ratio_text = 'não se aplica' if check['ratio_global_to_family'] is None else f"{check['ratio_global_to_family']:.6g}"
                family_name = 'local' if check['family']=='local' else 'distorcional'
                wave_name = 'cFSM' if check['wave_source']=='cfsm' else 'adotada'
                descriptions.append(
                    f"Família {family_name}, semionda {wave_name}={check['wave_mm']:.6g} mm: "
                    f"G puro={global_text}, família pura={family_text}, "
                    f"G/família={ratio_text}; atende={'sim' if check['passed'] else 'não'}.")
            memory.append({'title':f'Separação global — {symbol}, malha {index}','formula':None,
                           'substitution':f"Largura máxima={level['strip_width_mm']:.6g} mm; arco={level['corner_angle_deg']}°.",
                           'result':' '.join(descriptions),'unit':'kN·m, mm','reference':REFERENCE})
        if item['distortion_status']=='not_applicable':
            proof = levels[1]['by_sign'][sign]['absence']
            memory.append({'title':f'Certificado de ausência distorcional — {symbol}',
                           'formula':r'K_{g,D}(r)=\frac{A}{r}+rB,\quad r=\frac{L}{L_0}>0',
                           'substitution':f"eig(A)={proof['A_eigenvalues']}; eig(B)={proof['B_eigenvalues']}",
                           'result':'A e B estritamente negativas: nenhuma semionda positiva produz autovalor crítico positivo no subespaço D auxiliar. Não é prova de ausência de todos os modos mistos ou de carregamentos combinados.',
                           'unit':'','reference':REFERENCE})
    return {'status':status,'by_sign':by_sign,'method':METHOD,'reference':REFERENCE,
            'note':None if status=='computed' else 'O cálculo automático exige análise externa para os ramos que não convergiram.',
            'diagnostics':{'levels':levels,'E_MPa':E,'nu':nu,'G_plate_MPa':E/(2*(1+nu)),
                           'physical_basis_version':BASIS_VERSION,
                           'versions':{name:version(name) for name in ('pycufsm','numpy','scipy')},
                           'elapsed_seconds':perf_counter()-started,
                           'moment_tolerance':MOMENT_TOLERANCE,'wave_tolerance':WAVE_TOLERANCE,
                           'global_separation_margin':GLOBAL_SEPARATION,
                           'load_case':'Momento uniforme puro no eixo menor; seção prismática, sem furos, lábios90°, duas mesas/lábios iguais.'},
            'memory':memory}


def critical_moments(profile,material):
    """Return independent positive/negative minor-axis elastic criticals.

    Cache key contains only geometry, E and nu. Yield stress, member length,
    other loads and actual restraints do not change this cross-section scan.
    Returned objects are copies so one project cannot mutate another's cache.
    """
    try:
        if profile.get('family')!='Ue':
            raise ValueError("O cálculo automático é exclusivo de perfis Ue simétricos com dois enrijecedores90°.")
        geometry = tuple(float(profile[key]) for key in ('h_mm','b_mm','d_mm','t_mm','r_mm'))
        E,nu = float(material['E_mpa']),float(material['nu'])
        if not all(math.isfinite(v) for v in (*geometry,E,nu)):
            raise ValueError("Geometria e constantes elásticas devem ser finitas.")
        h,b,d,t,ri = geometry
        if min(h,b,d,t,E)<=0 or ri<0 or not 0<=nu<.5:
            raise ValueError("Geometria ou constantes elásticas inválidas.")
        if min(h-2*(ri+t),b-2*(ri+t),d-ri-t)<=0 or 2*d>=h:
            raise ValueError("As dimensões não deixam trechos retos positivos ou os enrijecedores se sobrepõem.")
        return deepcopy(_cached(geometry,E,nu))
    except (ValueError,ArithmeticError,np.linalg.LinAlgError) as exc:
        return {'status':'pending','method':METHOD,'reference':REFERENCE,'note':str(exc),'by_sign':{},
                'diagnostics':{'error_type':type(exc).__name__},
                'memory':[{'title':'Momentos críticos automáticos pendentes','formula':None,
                           'substitution':None,'result':str(exc),'unit':'','reference':REFERENCE}]}


def clear_cache():
    """Clear in-process geometry cache, useful for numerical validation."""
    with _LOCK:
        _cached.cache_clear()
