"""Cálculo de terças de perfis U e Ue conforme a base NBR 14762:2010."""

__version__ = "0.5.0"
