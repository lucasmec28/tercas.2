"""Figures for the interface. No resistance or structural analysis lives here."""

from __future__ import annotations

import math
from typing import Any

import plotly.graph_objects as go
from .orientation import is_girt

BLUE = "#2876A5"
TEAL = "#147D73"
RED = "#C44747"
AMBER = "#B97818"
SLATE = "#374D60"
STATUS = {"pass": "Atende no modelo", "fail": "Não atende", "pending": "Verificação pendente",
          "not_applicable": "Não se aplica", "excluded": "Excluída por opção de projeto",
          "partial": "Cálculo parcial — escopo e hipóteses adotadas"}


def number(value: Any, digits: int = 3) -> str:
    """Display a finite number using Brazilian decimal punctuation."""
    if value is None:
        return "—"
    try:
        numeric = float(value)
    except (ValueError, TypeError):
        return str(value)
    if not math.isfinite(numeric):
        return "—"
    return f"{numeric:,.{digits}f}".replace(",", "_").replace(".", ",").replace("_", ".")


def _base(figure: go.Figure, height: int = 340) -> go.Figure:
    figure.update_layout(
        height=height,
        margin=dict(l=20, r=25, t=28, b=35),
        font=dict(family="Arial, sans-serif", size=13),
        paper_bgcolor="rgba(0,0,0,0)",
        plot_bgcolor="rgba(0,0,0,0)",
        legend=dict(orientation="h", y=1.15, x=0),
        hovermode="x unified",
    )
    return figure


def section_figure(profile: dict, props: dict | None = None, *, member: dict | None = None) -> go.Figure:
    """Rounded centreline drawing; displayed stroke thickness is schematic."""
    height = float(profile["h_mm"])
    width = float(profile["b_mm"])
    thickness = float(profile["t_mm"])
    radius = float(profile["r_mm"]) + thickness / 2
    lip = float(profile["d_mm"]) if profile["family"] == "Ue" else 0.0
    top = height / 2 - thickness / 2
    xs: list[float] = []
    ys: list[float] = []

    def point(x: float, y: float) -> None:
        xs.append(x)
        ys.append(y)

    def arc(cx: float, cy: float, start: float, end: float) -> None:
        for i in range(17):
            angle = math.radians(start + (end - start) * i / 16)
            point(cx + radius * math.cos(angle), cy + radius * math.sin(angle))

    if lip:
        point(width - thickness, -height / 2 + lip)
        arc(width - thickness - radius, -top + radius, 0, -90)
    else:
        point(width - thickness / 2, -top)
    point(radius, -top)
    arc(radius, -top + radius, -90, -180)
    point(0, top - radius)
    arc(radius, top - radius, 180, 90)
    if lip:
        point(width - thickness - radius, top)
        arc(width - thickness - radius, top - radius, 90, 0)
        point(width - thickness, height / 2 - lip)
    else:
        point(width - thickness / 2, top)

    figure = _base(go.Figure(), 390)
    figure.add_trace(go.Scatter(
        x=xs, y=ys, mode="lines", name=profile["family"],
        line=dict(color=BLUE, width=6),
        hovertemplate="x = %{x:.2f} mm<br>y = %{y:.2f} mm<extra>Linha média</extra>",
    ))
    pad = max(height, width) * 0.15

    def dimension(x1: float, y1: float, x2: float, y2: float, label: str) -> None:
        figure.add_shape(type="line", x0=x1, y0=y1, x1=x2, y1=y2,
                         line=dict(color=SLATE, width=1))
        tick = pad * 0.12
        for x, y in [(x1, y1), (x2, y2)]:
            figure.add_shape(type="line", x0=x - tick, y0=y - tick,
                             x1=x + tick, y1=y + tick,
                             line=dict(color=SLATE, width=1))
        figure.add_annotation(x=(x1 + x2) / 2, y=(y1 + y2) / 2,
                              text=label, showarrow=False, bgcolor="rgba(255,255,255,0.9)",
                              font=dict(color=SLATE, size=12),
                              xshift=-32 if x1 == x2 else 0,
                              yshift=0 if x1 == x2 else 12)

    dimension(-pad * 0.7, -height / 2, -pad * 0.7, height / 2,
              f"h = {number(height, 0)}")
    dimension(-thickness / 2, height / 2 + pad * 0.75,
              width - thickness / 2, height / 2 + pad * 0.75,
              f"b = {number(width, 0)} mm")
    if lip:
        dimension(width + pad * 0.6, height / 2 - lip,
                  width + pad * 0.6, height / 2,
                  f"D = {number(lip, 0)}")

    centroid = float(props["xc"]) if props else width * 0.28
    for name, end_x, end_y in [("x", centroid + pad * 1.4, 0),
                               ("y", centroid, pad * 1.4)]:
        figure.add_annotation(x=end_x, y=end_y, ax=centroid, ay=0,
                              xref="x", yref="y", axref="x", ayref="y",
                              text=name, showarrow=True, arrowhead=2,
                              arrowcolor=TEAL, font=dict(color=TEAL))
    lower_x = -pad * 2
    if props:
        shear_x = float(props["xc"]) + float(props["xsc"])
        lower_x = min(lower_x, shear_x - pad)
        figure.add_trace(go.Scatter(
            x=[centroid, shear_x], y=[0, 0], mode="markers+text",
            marker=dict(size=8, color=[TEAL, AMBER], symbol=["circle", "diamond"]),
            text=["CG", "CT"], textposition="bottom center", name="Centros",
            hovertemplate="%{text}<br>x = %{x:.2f} mm<extra></extra>",
        ))
    figure.update_layout(showlegend=False, hovermode="closest")
    figure.update_xaxes(visible=False, range=[lower_x, width + pad * 2],
                        fixedrange=True, constrain="domain")
    figure.update_yaxes(visible=False, range=[-height / 2 - pad, height / 2 + pad * 1.8],
                        scaleanchor="x", scaleratio=1, fixedrange=True)
    if member is not None and is_girt(member):
        # Display rotation only; section properties remain in the same local axes.
        for trace in figure.data:
            xx, yy = list(trace.x), list(trace.y)
            trace.x, trace.y = yy, [-value for value in xx]
        for shape in figure.layout.shapes:
            x0,y0,x1,y1=shape.x0,shape.y0,shape.x1,shape.y1
            shape.update(x0=y0,y0=-x0,x1=y1,y1=-x1)
        for annotation in figure.layout.annotations:
            xx,yy=annotation.x,annotation.y
            annotation.x,annotation.y=yy,-xx
            if annotation.axref=='x' and annotation.ayref=='y':
                ax,ay=annotation.ax,annotation.ay
                annotation.ax,annotation.ay=ay,-ax
            annotation.xshift=0
            annotation.yshift=12
        figure.update_xaxes(range=[-height/2-pad*1.5,height/2+pad*2])
        figure.update_yaxes(range=[-width-pad*2,-lower_x+pad])
    return figure


def member_figure(project: dict) -> go.Figure:
    member = project["member"]
    length = float(member["L_m"])
    figure = _base(go.Figure(), 190)
    figure.add_trace(go.Scatter(x=[0, length], y=[0, 0], mode="lines",
                                line=dict(color=SLATE, width=5), name="Barra",
                                hoverinfo="skip"))
    figure.add_trace(go.Scatter(x=[0, length], y=[-0.08, -0.08], mode="markers",
                                marker=dict(symbol="triangle-up", size=20, color=SLATE),
                                name="Apoios", hoverinfo="skip"))
    if member["restraint"] == "discrete" and float(member["Lb_m"]) > 0:
        spacing = float(member["Lb_m"])
        count = min(int(math.ceil(length / spacing)), 200)
        positions = [i * spacing for i in range(1, count) if i * spacing < length]
        figure.add_trace(go.Scatter(x=positions, y=[0.0] * len(positions), mode="markers",
                                    marker=dict(symbol="diamond", size=13, color=TEAL),
                                    name="Contenção lateral e torcional",
                                    hovertemplate="Contenção em z = %{x:.3f} m<extra></extra>"))
    elif member['restraint']=='independent':
        for axis, color, level in (('x', BLUE, 0.08), ('y', TEAL, 0.14), ('z', AMBER, 0.20)):
            spacing=float(member[f'L{axis}_m'])
            positions=[i*spacing for i in range(1,min(10001,math.ceil(length/spacing))) if i*spacing<length]
            figure.add_trace(go.Scatter(x=positions,y=[level]*len(positions),mode='markers',
                marker=dict(symbol='diamond',size=10,color=color),name=f'L{axis} = {number(spacing,2)} m',
                hovertemplate=f'Vínculo para L{axis} em z = %{{x:.3f}} m<extra></extra>'))
        figure.add_annotation(x=length/2,y=0.27,text='Lx / Ly / Lz distintos · K = 1',showarrow=False)
    elif member["restraint"] in {"continuous", "panel"}:
        figure.add_shape(type="line", x0=0, x1=length, y0=0.12, y1=0.12,
                         line=dict(color=TEAL, width=3, dash="dot"))
    figure.add_annotation(x=length / 2, y=-0.28, showarrow=False,
                          text=f"Vão principal L = {number(length, 2)} m")
    figure.update_layout(showlegend=False, hovermode="closest",
                         margin=dict(l=25, r=25, t=10, b=10))
    figure.update_xaxes(visible=False, range=[-length * 0.04, length * 1.04], fixedrange=True)
    figure.update_yaxes(visible=False, range=[-0.4, 0.3], fixedrange=True)
    return figure


def diagram_figure(diagram: dict, quantity: str) -> go.Figure:
    fields, unit, title = {
        "moment": (["Mx_kNm", "My_kNm"], "kN·m", "Momento fletor"),
        "shear": (["Vx_kN", "Vy_kN"], "kN", "Força cortante"),
        "deflection": (["dx_mm", "dy_mm"], "mm", "Deslocamento"),
    }[quantity]
    figure = _base(go.Figure(), 350)
    z = diagram.get("z_m", [])
    for field, color in zip(fields, [BLUE, TEAL]):
        values = diagram.get(field, [])
        if not values or len(values) != len(z):
            continue
        label = field.split("_")[0].replace("dx", "δx").replace("dy", "δy")
        figure.add_trace(go.Scatter(
            x=z, y=values, mode="lines", name=label,
            line=dict(color=color, width=2.5), connectgaps=False,
            hovertemplate=f"{label} = %{{y:.4f}} {unit}<extra></extra>",
        ))
    figure.add_hline(y=0, line=dict(color="#A9B4BC", width=1))
    figure.update_xaxes(title="Posição z no vão (m)", gridcolor="rgba(120,140,155,0.12)")
    figure.update_yaxes(title=f"{title} ({unit})", gridcolor="rgba(120,140,155,0.12)")
    return figure


def utilization_figure(checks: list[dict]) -> go.Figure | None:
    items = [check for check in checks if isinstance(check.get("utilization"), (int, float))
             and math.isfinite(check["utilization"]) and check.get("status") in {"pass", "fail"}]
    if not items:
        return None
    governing_by_label = {}
    for check in items:
        label = check["label"]
        if label not in governing_by_label or check["utilization"] > governing_by_label[label]["utilization"]:
            governing_by_label[label] = check
    items = sorted(governing_by_label.values(), key=lambda check: check["utilization"], reverse=True)[:12]
    labels = [check["label"] for check in items]
    figure = _base(go.Figure(go.Bar(
        x=[check["utilization"] for check in items], y=labels, orientation="h",
        customdata=[[check.get("case_id", ""), check.get("reference", ""),
                     "Atende ao escopo adotado" if check["status"] == "pass" and check.get("conditional") else STATUS[check["status"]],
                     check.get("note", "")] for check in items],
        marker_color=[RED if check["status"] == "fail" else AMBER if check.get("conditional") else TEAL for check in items],
        hovertemplate="%{y}<br>Utilização = %{x:.3f}<br>Caso: %{customdata[0]}<br>%{customdata[2]}<br>%{customdata[1]}<br>%{customdata[3]}<extra></extra>",
    )), max(260, 38 * len(items) + 70))
    figure.add_vline(x=1, line=dict(color=RED, width=1.5, dash="dash"))
    figure.update_layout(showlegend=False, margin=dict(l=10, r=20, t=20, b=35))
    figure.update_xaxes(title="Utilização (limite = 1)", rangemode="tozero")
    figure.update_yaxes(autorange="reversed", automargin=True)
    return figure
