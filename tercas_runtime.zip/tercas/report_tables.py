"""Compact, presentation-only tables for the editable calculation report.

Every public table returns headers/rows/widths. Cells are plain strings and
widths are relative fractions summing to one; the document builder owns styles,
pagination and the final scope notes. No structural result is recalculated here.
"""
from __future__ import annotations

from typing import TypedDict
from .report_formatting import number
from .orientation import is_girt, projection_angle


class TableSpec(TypedDict):
    headers: list[str]
    rows: list[list[str]]
    widths: list[float]


def _number(value, digits=6):
    return number(value)


def _paired(items):
    cells = [[symbol, _number(value), unit] for symbol, value, unit in items]
    rows = [cells[i] + (cells[i+1] if i+1 < len(cells) else ['', '', ''])
            for i in range(0, len(cells), 2)]
    return dict(headers=['Símbolo', 'Valor', 'Unidade', 'Símbolo', 'Valor', 'Unidade'],
                rows=rows, widths=[.14, .23, .13, .14, .23, .13])


def case_labels(result: dict) -> dict[str, str]:
    """Assign C01... in the original combination order, shared by every output."""
    labels = {}
    for index, case in enumerate(result.get('combinations', []), 1):
        identifier = case['id']
        if identifier in labels:
            raise ValueError('Identificador de combinação repetido: ' + identifier)
        labels[identifier] = f'C{index:02d}'
    return labels


def section_rows(result: dict) -> TableSpec:
    """External dimensions, actual member lengths and gross properties in mm."""
    project, section = result['project'], result['section']
    profile, member = project['profile'], project['member']
    items = [
        ('H', profile['h_mm'], 'mm'), ('B', profile['b_mm'], 'mm'),
        ('D', profile['d_mm'], 'mm'), ('t', profile['t_mm'], 'mm'),
        ('ri', profile['r_mm'], 'mm'), ('α', projection_angle(member), '°'),
        ('L', member['L_m']*1000, 'mm'),
        ('Lb', member['Lb_m']*1000 if member['restraint'] == 'discrete' else None, 'mm'),
        ('A', section['A'], 'mm²'), ('m', section['mass'], 'kg/m'),
        ('Ix', section['Ix'], 'mm⁴'), ('Iy', section['Iy'], 'mm⁴'),
        ('Ixy', section['Ixy'], 'mm⁴'), ('Wx', section['Wx'], 'mm³'),
        ('Wy,alma', section['Wy_web'], 'mm³'), ('Wy,borda', section['Wy_edge'], 'mm³'),
        ('J', section['J'], 'mm⁴'), ('Cw', section['Cw'], 'mm⁶'),
        ('xCT − xCG', section['xsc'], 'mm'), ('yCT − yCG', section['ysc'], 'mm'),
        ('rx', section['rx'], 'mm'), ('ry', section['ry'], 'mm'),
        ('r0', section['r0'], 'mm'), ('pp', section['pp'], 'kN/m'),
    ]
    if member['restraint'] == 'independent':
        items[8:8] = [(symbol, member[key]*1000, 'mm') for symbol, key in
                      [('Lx', 'Lx_m'), ('Ly', 'Ly_m'), ('Lz', 'Lz_m')]]
    return _paired(items)


def material_rows(result: dict) -> TableSpec:
    material = result['project']['material']
    return _paired([
        ('fy', material['fy_mpa'], 'MPa'), ('fu', material['fu_mpa'], 'MPa'),
        ('E', material['E_mpa'], 'MPa'), ('G', material['G_mpa'], 'MPa'),
        ('ν', material['nu'], '—'), ('ρaço', material['density_kgm3'], 'kg/m³'),
    ])


def load_rows(result: dict) -> TableSpec:
    """Active-mode actions only; pp is added once only in characteristic mode."""
    project = result['project']
    loads = project['loads']
    girt = is_girt(project['member'])
    surface = 'ao fechamento' if girt else 'à cobertura'
    rows = []
    def add(symbol, value, unit, meaning):
        rows.append([symbol, _number(value), unit, meaning])
    if loads['mode'] == 'characteristic':
        add('pp', result['section']['pp'], 'kN/m', 'Peso próprio vertical da '+('travessa' if girt else 'terça'))
        add('Gm,ad', loads['g_metal_kNm'], 'kN/m', 'Permanente metálica adicional ao pp')
        add('Gr', loads['g_roof_kNm'], 'kN/m', 'Permanente '+('do fechamento industrializado' if girt else 'da cobertura industrializada'))
        add('Q', loads['q_kNm'], 'kN/m', 'Sobrecarga vertical distribuída')
        add('W+', loads['wind_down_kNm'], 'kN/m', 'Vento de pressão, direção local +y')
        add('W−', -loads['wind_up_kNm'], 'kN/m', 'Vento de sucção, direção local −y')
        add('Pk', loads['point_kN'], 'kN', 'Força vertical; alternativa à sobrecarga Q')
        add('a', loads['point_x_m']*1000, 'mm', 'Posição de Pk desde o apoio inicial')
        add('ψ0,Q', loads['psi0_q'], '—', 'Acompanhante Q ou P no ELU')
        add('ψ0,W', loads['psi0_w'], '—', 'Vento acompanhante no ELU')
        add('ψ1,Q', loads['psi1_q'], '—', 'Acompanhante Q ou P no ELS raro')
        add('ψ1,W', loads['psi1_w'], '—', 'Vento acompanhante no ELS raro')
    else:
        for symbol, key, meaning in [
            ('qd,x', 'qd_parallel_kNm', 'Carga total ELU paralela '+surface),
            ('qd,y', 'qd_normal_kNm', 'Carga total ELU normal '+surface),
            ('qs,x', 'qs_parallel_kNm', 'Carga total ELS paralela '+surface),
            ('qs,y', 'qs_normal_kNm', 'Carga total ELS normal '+surface),
        ]:
            add(symbol, loads[key], 'kN/m', meaning+'; pp já integrado')
        add('Nsd', loads['nsd_kN'], 'kN', 'Normal concomitante ELU; compressão positiva')
        add('Nser', loads['nser_kN'], 'kN', 'Normal concomitante ELS; compressão positiva')
        add('Pk', loads['point_kN'], 'kN', 'Força vertical adicional: 1,5Pk ELU; Pk ELS')
        add('a', loads['point_x_m']*1000, 'mm', 'Posição de Pk desde o apoio inicial')
        if girt:
            add('W+', loads['wind_down_kNm'], 'kN/m', 'Vento característico isolado de pressão, direção local +y')
            add('W−', -loads['wind_up_kNm'], 'kN/m', 'Vento característico isolado de sucção, direção local −y')
    return dict(headers=['Ação', 'Valor', 'Unidade', 'Definição'], rows=rows,
                widths=[.14, .16, .12, .58])


def _term(coefficient, symbol):
    if coefficient == 0:
        return ''
    return symbol if coefficient == 1 else _number(coefficient)+' '+symbol


def _composition(case, project):
    """Render recorded ELU factors and the engine's identified ELS branches."""
    loads = project['loads']
    identifier = case['id']
    if identifier in ('SLS-SUCCAO-ISOLADA', 'SLS-PRESSAO-ISOLADA'):
        return 'W−' if 'SUCCAO' in identifier else 'W+'
    if loads['mode'] == 'design':
        elu = case['kind'] == 'ULS'
        return ('qd,x; qd,y; Nsd' if elu else 'qs,x; qs,y; Nser') + (
            ('; 1,5Pk' if elu else '; Pk') if loads['point_kN'] else '')
    wind = 'W−' if 'SUCCAO' in identifier else 'W+'
    if case.get('factors'):
        factors = case['factors']
        terms = [_term(factors.get(key, 0), symbol) for key, symbol in
                 [('G_metal', 'Gm'), ('G_roof', 'Gr'), ('Q', 'Q'), ('P', 'Pk'), ('W', wind)]]
    elif identifier == 'SLS-G':
        terms = ['Gm', 'Gr']
    elif identifier in ('SLS-SUCCAO-ISOLADA', 'SLS-PRESSAO-ISOLADA'):
        terms = [wind]
    elif identifier.startswith(('SLS-Q-PRINCIPAL-', 'SLS-P-PRINCIPAL-')):
        terms = ['Gm', 'Gr', 'Q' if identifier.startswith('SLS-Q-') else 'Pk']
        if not identifier.endswith('SEM-VENTO'):
            terms.append(_term(loads['psi1_w'], wind))
    elif identifier.startswith(('SLS-PRESSAO-PRINCIPAL-', 'SLS-SUCCAO-PRINCIPAL-')):
        terms = ['Gm', 'Gr', wind]
        if not identifier.endswith('SEM-Q'):
            terms.append(_term(loads['psi1_q'], 'Pk' if identifier.endswith('-P') else 'Q'))
    else:
        # A future branch must retain its recorded description rather than be
        # assigned a guessed coefficient expression.
        return case.get('description') or case.get('label') or identifier
    return ' + '.join(term for term in terms if term)


def combination_rows(result: dict) -> TableSpec:
    """All load cases, exact order, signed components and visible coefficients."""
    labels = case_labels(result)
    rows = []
    for case in result.get('combinations', []):
        kind = 'ELU' if case['kind'] == 'ULS' else 'ELS'
        if case.get('service_type') == 'coupled' and not is_girt(result['project']['member']):
            kind = 'ELS adic.'
        rows.append([labels[case['id']], kind, _composition(case, result['project']),
                     *[_number(case[key], digits=5) for key in ('qx_kNm', 'qy_kNm', 'px_kN', 'py_kN', 'nsd_kN')]])
    return dict(headers=['Caso', 'Tipo', 'Composição', 'qx\n[kN/m]', 'qy\n[kN/m]',
                         'Px\n[kN]', 'Py\n[kN]', 'N\n[kN]'], rows=rows,
                widths=[.07, .08, .35, .12, .12, .08, .08, .10])


def legend_rows(result: dict) -> TableSpec:
    """Symbols used by the compact report; optional branches add their symbols."""
    project = result['project']
    girt = is_girt(project['member'])
    rows = [
        ['H=b_w; B=b_f; D; t; ri', 'Altura, mesa e borda externas; espessura de aço; raio interno', 'mm'],
        ['h; b_i; d', 'Alma plana; largura plana da placa i; enrijecedor plano', 'mm'],
        ['L; Lb; a; b=L−a; z', 'Vão; contenção; distâncias da força aos apoios; posição longitudinal', 'mm'],
        ['α; x, y', ('Rotação de projeção −90°; x paralelo ao fechamento (positivo para cima), y normal'
                      if girt else 'Inclinação; eixos locais paralelo e normal à cobertura'), '°; —'],
        ['A; Ix, Iy, Ixy', 'Área; inércias centroidais e produto de inércia', 'mm²; mm⁴'],
        ['Wx; Wy,alma; Wy,borda', 'Módulos elásticos brutos referidos às fibras extremas', 'mm³'],
        ['Wef; Wc,ef; Ief; Ig', 'Módulos efetivos, inclusive na fibra comprimida; inércia efetiva e bruta', 'mm³; mm⁴'],
        ['J; Cw', 'Constantes de torção uniforme e empenamento', 'mm⁴; mm⁶'],
        ['CG; CT; rx, ry, r0; j', 'Centroide; centro de torção; raios; parâmetro de assimetria do Anexo E', 'mm'],
        ['fy, fu; E, G; ν; ρaço', 'Escoamento e ruptura; módulos elásticos; Poisson; massa específica', 'MPa; —; kg/m³'],
        ['m; pp', 'Massa e peso próprio por comprimento', 'kg/m; kN/m'],
        ['Gm = pp + Gm,ad; Gr', 'Permanente metálica total; '+('fechamento industrializado' if girt else 'cobertura industrializada'), 'kN/m'],
        ['Q; W+; W−; Pk', 'Sobrecarga; pressão; sucção com sinal negativo; força de manutenção', 'kN/m; kN'],
        ['γG, γQ; ψ0, ψ1', 'Fatores de ponderação e de combinação de ações', '—'],
        ['qx, qy; Px, Py', 'Componentes locais distribuídas e concentradas', 'kN/m; kN'],
        ['Mx, My; Vx, Vy; N', 'Momentos; cortantes; normal positiva em compressão', 'kN·m; kN'],
        ['Sd; Rd; ser', 'Índices de solicitação, resistência de cálculo e serviço', '—'],
        ['γ; η', 'Coeficiente de resistência; índice de utilização', '—'],
        ['k; kℓ, kv; Cb; Cs, Cm', 'Coeficientes de placa/local/cisalhamento; fator do diagrama; sinal e fator do Anexo E', '—'],
        ['σ, σmax, σref', 'Tensão normal, máxima e de referência da seção efetiva', 'MPa'],
        ['b_ret; b₁, b₂; c_ref', 'Largura retida; extremos das faixas efetivas; distância à fibra de referência', 'mm'],
        ['λp, λ0, λℓ, λdist; χ, χFLT, χdist; ρred', 'Esbeltezes reduzidas; fatores de redução global, FLT, distorcional e local', '—'],
        ['H(z−a)', 'Função degrau da força pontual: zero antes de a e um depois de a', '—'],
        ['Mℓ; Mdist; Me', 'Momentos críticos elásticos local, distorcional e global', 'N·mm'],
        ['MRd, MRd,loc; VRd', 'Resistências à flexão, flexão local e cortante', 'kN·m; kN'],
        ['Nex, Ney, Nez, Nexz, Ne', 'Forças críticas elásticas de flexão, torção, flexotorção e governante', 'N'],
        ['κ; δx, δy, δvertical; δlim', 'Curvatura; deslocamentos locais e vertical; limite de deslocamento', 'mm⁻¹; mm'],
        ['aδ; bδ; qδ; Pδ', 'Coeficientes de projeção e cargas divididas pela rigidez para a direção de flecha avaliada', '—; mm⁻³; mm⁻²'],
        ['Unidades', '1 MPa = 1 N/mm²; 1 kN/m = 1 N/mm; 1 kN·m = 10⁶ N·mm', '—'],
    ]
    rows.insert(3, ['Lx; Ly; Lz', 'Comprimentos de flambagem por flexão em x, flexão em y e torção', 'mm'])
    if project['profile']['family'] == 'Ue':
        rows.extend([
            ['Is; Ia; ηs; ns; λp0; b_ef', 'Inércias do enrijecedor real e requerido; eficiência; expoente; esbeltez inicial; largura efetiva', 'mm⁴; —; mm'],
            ['MRe, MRℓ, MRdist', 'Resistências características dos ramos global, local e distorcional', 'N·mm'],
            ['Mn; MR,ser', 'Momento de serviço; resistência recalculada com Mn em C.5', 'N·mm'],
        ])
    if any(abs(c.get('nsd_kN', 0)) > 0 for c in result.get('combinations', [])):
        rows.extend([
            ['Ne; Ndist; Aef', 'Forças críticas global e distorcional; área efetiva', 'N; mm²'],
            ['An0; An; Ct', 'Áreas líquidas fora e dentro da ligação; fator de transmissão', 'mm²; —'],
            ['β; x₀', 'Coeficiente de acoplamento flexotorcional; distância entre CT e CG', '—; mm'],
            ['Nc,Rd; Nt,Rd', 'Resistências de cálculo à compressão e à tração', 'kN'],
        ])
    if project['support']['check']:
        rows.append(['FRd', 'Resistência de cálculo à força localizada no apoio', 'kN'])
        rows.append(['c; θ; α, αr, αc, αh', 'Contato no apoio; ângulo da alma; coeficientes do Anexo D', 'mm; °; —'])
    if project['member']['restraint'] == 'panel':
        rows.append(['R', 'Fator de redução da resistência pelo Anexo F', '—'])
    return dict(headers=['Símbolo', 'Definição', 'Unidade'], rows=rows,
                widths=[.25, .59, .16])
