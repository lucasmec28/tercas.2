"""Estática e deslocamentos de uma barra biapoiada.

Unidades internas: N, mm, MPa. qy/Py produzem Mx; qx/Px produzem My.
Os valores de P representam força concentrada, não momento aplicado.
"""
from __future__ import annotations

import math
from typing import Callable

import numpy as np
from numpy.polynomial import Polynomial


def beam_case(combination: dict, length_mm: float) -> dict:
    return {"L": float(length_mm), "a": float(combination["a_m"]) * 1000,
            "qx": float(combination["qx_kNm"]), "qy": float(combination["qy_kNm"]),
            "px": float(combination["px_kN"]) * 1000,
            "py": float(combination["py_kN"]) * 1000,
            "N": float(combination.get("nsd_kN", 0)) * 1000}


def reactions(case: dict) -> dict:
    L, a = case["L"], case["a"]
    return {"RAx": case["qx"] * L / 2 + case["px"] * (L-a) / L,
            "RBx": case["qx"] * L / 2 + case["px"] * a / L,
            "RAy": case["qy"] * L / 2 + case["py"] * (L-a) / L,
            "RBy": case["qy"] * L / 2 + case["py"] * a / L}


def forces(case: dict, x: float, side: str = "right") -> dict:
    """Cortantes nos limites internos da barra; salto de P em x=a."""
    r = reactions(case)
    activated = x > case["a"] or (x == case["a"] and side == "right")
    dx = max(0.0, x-case["a"])
    return {"Mx": r["RAy"]*x-case["qy"]*x*x/2-case["py"]*dx,
            "My": r["RAx"]*x-case["qx"]*x*x/2-case["px"]*dx,
            "Vy": r["RAy"]-case["qy"]*x-(case["py"] if activated else 0),
            "Vx": r["RAx"]-case["qx"]*x-(case["px"] if activated else 0)}


def _real_roots(coefficients, lo: float, hi: float) -> list[float]:
    p = Polynomial(coefficients).trim(tol=1e-24)
    if p.degree() == 0:
        return []
    return [min(hi, max(lo, float(z.real))) for z in p.roots()
            if abs(z.imag) <= 1e-7 * max(1.0, abs(z.real))
            and lo-1e-8 <= z.real <= hi+1e-8]


def pieces(case: dict, extra=()) -> list[tuple[float, float]]:
    limits = sorted(set([0.0, case["L"], case["a"]] +
                        [float(x) for x in extra if 0 <= x <= case["L"]]))
    return [(a,b) for a,b in zip(limits, limits[1:]) if b-a > 1e-9]


def moment_polynomial(case: dict, midpoint: float, axis: str) -> Polynomial:
    suffix = "y" if axis == "major" else "x"
    q, P = case["q"+suffix], case["p"+suffix]
    R = reactions(case)["RA"+suffix]
    after = midpoint > case["a"]
    return Polynomial([P*case["a"] if after else 0.0,
                       R-P if after else R, -q/2])


def moment_candidates(case: dict, axis: str = "major", lo=0.0, hi=None) -> list[float]:
    hi = case["L"] if hi is None else hi
    candidates = [lo,hi]
    for a,b in pieces(case, [lo,hi]):
        if a < lo-1e-9 or b > hi+1e-9:
            continue
        candidates += [a,b]
        candidates += _real_roots(moment_polynomial(case, (a+b)/2, axis).deriv().coef, a,b)
    return sorted(set(candidates))


def moment_zeros(case: dict, axis: str = "major") -> list[float]:
    return sorted(set(x for a,b in pieces(case)
                      for x in _real_roots(moment_polynomial(case,(a+b)/2,axis).coef,a,b)))


def maximum_moment(case: dict, axis: str = "major", lo=0.0, hi=None) -> dict:
    key = "Mx" if axis == "major" else "My"
    x = max(moment_candidates(case,axis,lo,hi), key=lambda z: abs(forces(case,z)[key]))
    return {"x_mm": x, "value_Nmm": forces(case,x)[key]}


def cb_factor(case: dict, lo=0.0, hi=None) -> float:
    hi = case["L"] if hi is None else hi
    peak = abs(maximum_moment(case,"major",lo,hi)["value_Nmm"])
    if peak < 1e-10:
        return 1.0
    ma,mb,mc = [abs(forces(case,lo+(hi-lo)*u)["Mx"]) for u in (.25,.5,.75)]
    return 12.5*peak/(2.5*peak+3*ma+4*mb+3*mc)


def max_moment_shear(case: dict, moment_rd: float, shear_rd: float) -> dict:
    """Máximo exato de (Mx/MRd)^2+(Vy/VRd)^2 na mesma seção."""
    candidates=[]
    target=case["qy"]*moment_rd**2/shear_rd**2
    for a,b in pieces(case):
        poly=moment_polynomial(case,(a+b)/2,"major")
        candidates += [(a,"right"),(b,"left")]
        for x in _real_roots(poly.deriv().coef,a,b)+_real_roots((poly-target).coef,a,b):
            candidates.append((x,"right"))
    def value(item):
        f=forces(case,*item)
        return (f["Mx"]/moment_rd)**2+(f["Vy"]/shear_rd)**2
    x,side=max(candidates,key=value)
    f=forces(case,x,side)
    return {"x_mm":x,"side":side,"utilization":value((x,side)),**f}


def max_biaxial(case: dict, major_pos: float, major_neg: float,
                minor_pos: float, minor_neg: float) -> dict:
    cuts=moment_zeros(case,"major")+moment_zeros(case,"minor")
    candidates=[]
    for a,b in pieces(case,cuts):
        middle=(a+b)/2
        mx=moment_polynomial(case,middle,"major")
        my=moment_polynomial(case,middle,"minor")
        sx=1 if mx(middle)>=0 else -1
        sy=1 if my(middle)>=0 else -1
        rx=major_pos if sx>0 else major_neg
        ry=minor_pos if sy>0 else minor_neg
        poly=sx*mx/rx+sy*my/ry
        candidates += [a,b]+_real_roots(poly.deriv().coef,a,b)
    def value(x):
        f=forces(case,x)
        return abs(f["Mx"])/(major_pos if f["Mx"]>=0 else major_neg)+abs(f["My"])/(minor_pos if f["My"]>=0 else minor_neg)
    x=max(candidates,key=value)
    return {"x_mm":x,"utilization":value(x),**forces(case,x)}


def sample_forces(case: dict, count=81) -> dict:
    z=sorted(set(np.linspace(0,case["L"],count).tolist()+[case["a"]]+
                 moment_candidates(case,"major")+moment_candidates(case,"minor")))
    rows=[]
    for x in z:
        if x==case["a"] and (case["px"] or case["py"]):
            rows.append((x,forces(case,x,"left")))
        rows.append((x,forces(case,x)))
    return {"z_m":[x/1000 for x,_ in rows],
            **{k+"_"+("kNm" if k.startswith("M") else "kN"):
               [f[k]/(1e6 if k.startswith("M") else 1000) for _,f in rows]
               for k in ("Mx","My","Vx","Vy")}}


def _deflection_poly(L: float, a: float, q_ei: float, p_ei: float, after: bool) -> Polynomial:
    x=Polynomial([0,1])
    result=q_ei*x*(L**3-2*L*x*x+x*x*x)/24
    if after:
        result += p_ei*a*(L-x)*(L**2-a*a-(L-x)**2)/(6*L)
    else:
        b=L-a
        result += p_ei*b*x*(L**2-b*b-x*x)/(6*L)
    return result


def fixed_stiffness_deflections(case: dict, E: float, stiffness: dict, angle_deg=0.0) -> dict:
    """Solução exata por trechos para a MESMA matriz efetiva em todo o vão."""
    ix,iy,ixy=stiffness["Ix"],stiffness["Iy"],stiffness.get("Ixy",0.)
    determinant=ix*iy-ixy*ixy
    if determinant <= 0:
        raise ValueError("A matriz de rigidez efetiva não é positiva definida.")
    qx=(ix*case["qx"]-ixy*case["qy"])/(E*determinant)
    qy=(iy*case["qy"]-ixy*case["qx"])/(E*determinant)
    px=(ix*case["px"]-ixy*case["py"])/(E*determinant)
    py=(iy*case["py"]-ixy*case["px"])/(E*determinant)
    angle=math.radians(angle_deg)
    polynomials=[]
    for a,b in pieces(case):
        dx=_deflection_poly(case["L"],case["a"],qx,px,(a+b)/2>case["a"])
        dy=_deflection_poly(case["L"],case["a"],qy,py,(a+b)/2>case["a"])
        polynomials.append((a,b,dx,dy))
    peaks={}
    for label in ("dx","dy","vertical"):
        candidates=[]
        for a,b,dx,dy in polynomials:
            poly=dx if label=="dx" else dy if label=="dy" else dx*math.sin(angle)+dy*math.cos(angle)
            for x in [a,b]+_real_roots(poly.deriv().coef,a,b):
                candidates.append((x,float(poly(x))))
        x,value=max(candidates,key=lambda item:abs(item[1]))
        peaks[label+"_mm"]=value
        peaks[label+"_at_mm"]=x
    z=sample_forces(case)["z_m"]
    def value(x,index):
        item=next((p for p in polynomials if p[0]-1e-8<=x<=p[1]+1e-8),polynomials[-1])
        return float(item[index](x))
    peaks.update(z_m=z,dx_series_mm=[value(x*1000,2) for x in z],
                 dy_series_mm=[value(x*1000,3) for x in z],
                 method="rigidez efetiva constante; solução analítica por trechos",
                 converged=True,stations=len(z))
    return peaks


class StiffnessUnavailable(Exception):
    def __init__(self,result):
        self.result=result
        super().__init__("Seção efetiva fora do domínio implementado.")


def variable_stiffness_deflections(case: dict, E: float, stiffness_at: Callable,
                                   angle_deg=0.0, max_panels=2048) -> dict:
    """Integra κ por trechos e refina a malha até convergência de deslocamentos.

    A interpolação linear de κ é integrada exatamente em cada painel. A matriz
    vem de uma seção efetiva conjunta; não se combinam duas soluções uniaxiais.
    """
    angle=math.radians(angle_deg)
    cache={}
    def curvature(x):
        key=round(x,10)
        if key not in cache:
            f=forces(case,x)
            st=stiffness_at(f["Mx"],f["My"],case["N"])
            if not st.get("converged") or st.get("Ix") is None:
                raise StiffnessUnavailable(st)
            ix,iy,ixy=st["Ix"],st["Iy"],st.get("Ixy",0.)
            D=ix*iy-ixy*ixy
            if D<=0:
                raise StiffnessUnavailable(st)
            cache[key]=np.array([(ix*f["My"]-ixy*f["Mx"])/(E*D),
                                  (iy*f["Mx"]-ixy*f["My"])/(E*D)],float)
        return cache[key]
    points=sorted(set([0.,case["L"],case["a"]]+moment_zeros(case,"major")+moment_zeros(case,"minor")+
                      moment_candidates(case,"major")+moment_candidates(case,"minor")))
    previous=None
    panels=32
    while panels<=max_panels:
        z=np.array(sorted(set(np.linspace(0,case["L"],panels+1).tolist()+points)))
        k=np.array([curvature(float(x)) for x in z])
        h=np.diff(z)
        integral=(h[:,None]*(k[:-1]+k[1:])/2)
        weighted=(case["L"]-z[:-1])[:,None]*integral-h[:,None]**2*(k[:-1]/6+k[1:]/3)
        slope0=weighted.sum(axis=0)/case["L"]
        slopes=np.vstack([slope0,slope0-np.cumsum(integral,axis=0)])
        increments=slopes[:-1]*h[:,None]-h[:,None]**2*(2*k[:-1]+k[1:])/6
        displacement=np.vstack([np.zeros(2),np.cumsum(increments,axis=0)])
        peaks={}
        for label,projection in (("dx",np.array([1.,0.])),("dy",np.array([0.,1.])),
                                  ("vertical",np.array([math.sin(angle),math.cos(angle)]))):
            candidates=[]
            for i,step in enumerate(h):
                poly=Polynomial([displacement[i]@projection,slopes[i]@projection,
                                 -(k[i]@projection)/2,-((k[i+1]-k[i])@projection)/(6*step)])
                for xx in [0.,float(step)]+_real_roots(poly.deriv().coef,0,float(step)):
                    candidates.append((float(z[i]+xx),float(poly(xx))))
            location,value=max(candidates,key=lambda item:abs(item[1]))
            peaks[label+"_mm"]=value
            peaks[label+"_at_mm"]=location
        values=np.array([peaks[name+"_mm"] for name in ("dx","dy","vertical")])
        error=None if previous is None else float(np.max(np.abs(values-previous)))
        tolerance=max(.0005,float(np.max(np.abs(values)))*.0002)
        if error is not None and error<=tolerance:
            break
        previous=values
        panels*=2
    converged=error is not None and error<=tolerance
    display=sample_forces(case)["z_m"]
    def interpolate(x):
        i=min(len(h)-1,max(0,int(np.searchsorted(z,x,side="right"))-1))
        u=x-z[i]
        return displacement[i]+slopes[i]*u-k[i]*u*u/2-(k[i+1]-k[i])*u**3/(6*h[i])
    curve=[interpolate(x*1000) for x in display]
    peaks.update(z_m=display,dx_series_mm=[float(v[0]) for v in curve],
                 dy_series_mm=[float(v[1]) for v in curve],converged=converged,
                 error_mm=error,stations=len(z),
                 method="integração da curvatura com seção efetiva conjunta e refinamento da malha")
    return peaks


class EulerInstability(ValueError):
    """O modelo plano ideal atingiu a singularidade elástica de Euler."""


def beam_column_forces(case: dict, x: float, E: float, Ix: float) -> dict:
    """Solução de viga-coluna reta, EI constante, N constante e qy uniforme.

    Não representa imperfeições iniciais, deslocabilidade global ou flexotorção.
    O cortante retornado é seccional dM/dx, distinto da reação global qL/2.
    """
    if case["qx"] or case["px"] or case["py"]:
        raise ValueError("A solução exata de viga-coluna aceita somente qy uniforme e N constante.")
    L,N,q=case["L"],case["N"],case["qy"]
    Ne=math.pi**2*E*Ix/L**2
    if N>=Ne*(1-1e-12):
        raise EulerInstability("A compressão atingiu a carga de Euler no plano da flexão: o modelo elástico está singular.")
    first=forces(case,x)
    if abs(N)<1e-8*Ne:
        result=dict(first)
        result["dy"]=q*x*(L**3-2*L*x*x+x**3)/(24*E*Ix)
        return result
    k=math.sqrt(abs(N)/(E*Ix));u=k*L/2
    if N>0:
        M=q/k**2*2*math.sin(k*x/2)*math.sin(k*(L-x)/2)/math.cos(u)
        V=-q/k*math.sin(k*(x-L/2))/math.cos(u)
    else:
        arg=k*(x-L/2)
        if u<20:
            M=q/k**2*2*math.sinh(k*x/2)*math.sinh(k*(L-x)/2)/math.cosh(u)
            V=-q/k*math.sinh(arg)/math.cosh(u)
        else:
            ratio=math.exp(abs(arg)-u)*(1+math.exp(-2*abs(arg)))/(1+math.exp(-2*u))
            sinh_ratio=math.copysign(math.exp(abs(arg)-u)*(1-math.exp(-2*abs(arg)))/(1+math.exp(-2*u)),arg)
            M=q/k**2*(1-ratio)
            V=-q/k*sinh_ratio
    return dict(Mx=M,My=0.,Vx=0.,Vy=V,dy=(M-first["Mx"])/N)


def beam_column_deflections(case: dict, E: float, Ix: float, angle_deg=0.) -> dict:
    z=sample_forces(case)["z_m"]
    peak=beam_column_forces(case,case["L"]/2,E,Ix)["dy"]
    return dict(dx_mm=0.,dy_mm=peak,vertical_mm=peak*math.cos(math.radians(angle_deg)),
                dx_at_mm=0.,dy_at_mm=case["L"]/2,vertical_at_mm=case["L"]/2,
                z_m=z,dx_series_mm=[0. for _ in z],
                dy_series_mm=[beam_column_forces(case,x*1000,E,Ix)["dy"] for x in z],
                method="solução exata de viga-coluna plana, reta, N e EI constantes; seção bruta comprovada",
                converged=True,stations=len(z))


def max_beam_column_moment_shear(case: dict, E: float, Ix: float,
                                moment_rd: float, shear_rd: float) -> dict:
    candidates=[0.,case["L"]/2,case["L"]]
    denominator=shear_rd**2-case["N"]/(E*Ix)*moment_rd**2
    peak=beam_column_forces(case,case["L"]/2,E,Ix)["Mx"]
    if abs(denominator)>1e-20:
        target=case["qy"]*moment_rd**2/denominator
        if min(0.,peak)<target<max(0.,peak):
            lo,hi=0.,case["L"]/2
            for _ in range(60):
                mid=(lo+hi)/2
                value=beam_column_forces(case,mid,E,Ix)["Mx"]
                if (value<target)==(peak>0): lo=mid
                else: hi=mid
            candidates.extend([(lo+hi)/2,case["L"]-(lo+hi)/2])
    def utilization(x):
        f=beam_column_forces(case,x,E,Ix)
        return (f["Mx"]/moment_rd)**2+(f["Vy"]/shear_rd)**2
    location=max(candidates,key=utilization)
    return dict(x_mm=location,side="seção do modelo de segunda ordem",
                utilization=utilization(location),**beam_column_forces(case,location,E,Ix))
