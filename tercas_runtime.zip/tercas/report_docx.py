"""Compact, editable Word calculation memory without heading paragraph styles.

The report consumes a completed engine result. It does not change capacities,
load combinations or the user's calculation scope.
"""
from __future__ import annotations

from io import BytesIO

from docx import Document
from docx.enum.table import WD_CELL_VERTICAL_ALIGNMENT, WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Cm, Pt, RGBColor

from . import __version__
from .report_checks import build_verifications, collect_assumptions, conclusion_data
from .report_figures import beam_evidence, beam_figure, moment_figures
from .report_formatting import number
from .report_omml import equation as native_equation, parts as equation_parts
from .report_tables import (case_labels, combination_rows, legend_rows, load_rows,
                            material_rows, section_rows)
from .orientation import is_girt, element_label

FONT = 'Times New Roman'
GREEN = '008000'
RED = 'C00000'
MIME = 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'


def _font(run, size=12, bold=False, color='000000'):
    run.font.name = FONT
    run.font.size = Pt(size)
    run.bold = bold
    run.font.color.rgb = RGBColor.from_string(color)
    fonts = run._element.get_or_add_rPr().get_or_add_rFonts()
    for kind in ('ascii', 'hAnsi', 'eastAsia', 'cs'):
        fonts.set(qn('w:'+kind), FONT)
    for kind in ('asciiTheme', 'hAnsiTheme', 'eastAsiaTheme', 'cstheme'):
        fonts.attrib.pop(qn('w:'+kind), None)
    return run


def _paragraph(document, text='', *, bold=False, before=0, after=4, keep=False):
    p = document.add_paragraph(style='Normal')
    p.paragraph_format.space_before = Pt(before)
    p.paragraph_format.space_after = Pt(after)
    p.paragraph_format.line_spacing = 1.0
    p.paragraph_format.keep_with_next = keep
    p.paragraph_format.widow_control = True
    _font(p.add_run(str(text)), bold=bold)
    return p


def _label(document, text):
    return _paragraph(document, text, bold=True, before=8, after=5, keep=True)


def _equation_paragraph(document, text, *, keep=False, after=4):
    """Editable built-up Word equations, never pictures or linear run math."""
    parts = equation_parts(str(text))
    last = None
    for index, part in enumerate(parts):
        last = _paragraph(document, keep=keep and index == len(parts)-1,
                          after=after if index == len(parts)-1 else 2)
        last.paragraph_format.keep_together = True
        display = OxmlElement('m:oMathPara')
        display.append(native_equation(part))
        last._p.append(display)
    return last


def _numeric_line(equation):
    numeric, result = equation['numeric'], str(equation.get('result') or '')
    if not result:
        return numeric
    if ';' not in numeric and ';' not in result and '=' in numeric and '=' in result:
        left, right = result.split('=', 1)
        if numeric.split('=', 1)[0].strip() == left.strip():
            return numeric+' = '+right.strip()
    return numeric+' ⇒ '+result


def _table(document, data):
    headers, rows = data['headers'], data['rows']
    if not rows:
        _paragraph(document, 'Sem dados aplicáveis.')
        return
    widths = data.get('widths') or [1/len(headers)]*len(headers)
    total = sum(widths)
    table = document.add_table(rows=1, cols=len(headers))
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    table.autofit = False
    pr = table._tbl.tblPr
    borders = OxmlElement('w:tblBorders')
    for edge in ('top','left','bottom','right','insideH','insideV'):
        item = OxmlElement('w:'+edge)
        for key, value in {'val':'single','sz':'4','color':'D9D9D9'}.items():
            item.set(qn('w:'+key), value)
        borders.append(item)
    pr.append(borders)
    margins = OxmlElement('w:tblCellMar')
    for edge, value in (('top','50'),('bottom','50'),('left','75'),('right','75')):
        item = OxmlElement('w:'+edge)
        item.set(qn('w:w'), value)
        item.set(qn('w:type'), 'dxa')
        margins.append(item)
    pr.append(margins)
    for i, width in enumerate(widths):
        table.columns[i].width = Cm(17*width/total)
    for index, values in enumerate([headers, *rows]):
        row = table.rows[0] if index == 0 else table.add_row()
        row_pr = row._tr.get_or_add_trPr()
        row_pr.append(OxmlElement('w:cantSplit'))
        if index == 0:
            row_pr.append(OxmlElement('w:tblHeader'))
        for i, (cell, value) in enumerate(zip(row.cells, values)):
            cell.width = Cm(17*widths[i]/total)
            cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER
            p = cell.paragraphs[0]
            p.style = document.styles['Normal']
            p.paragraph_format.space_before = Pt(0)
            p.paragraph_format.space_after = Pt(0)
            p.paragraph_format.line_spacing = 1.0
            p.paragraph_format.keep_with_next = index == 0
            header = headers[i]
            if index > 0 and (header=='Valor' or header.startswith(('qx','qy','Px','Py','N\n'))):
                p.alignment = WD_ALIGN_PARAGRAPH.RIGHT
            elif header in ('Caso','Tipo','Unidade'):
                p.alignment = WD_ALIGN_PARAGRAPH.CENTER
            else:
                p.alignment = WD_ALIGN_PARAGRAPH.LEFT
            _font(p.add_run(str(value)), size=10, bold=index == 0)
            if index == 0:
                shading = OxmlElement('w:shd')
                shading.set(qn('w:fill'), 'E8EEF2')
                cell._tc.get_or_add_tcPr().append(shading)


def _figure(document, png, caption, alt):
    p = _paragraph(document, after=2, keep=True)
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    shape = p.add_run().add_picture(BytesIO(png), width=Cm(17))
    shape._inline.docPr.set('descr', alt)
    _paragraph(document, caption, after=5)


def _case_text(value, labels: dict[str, str]):
    text = str(value or '')
    for identifier in sorted(labels, key=len, reverse=True):
        text = text.replace(identifier, labels[identifier])
    return text


def report_docx(result: dict) -> bytes:
    """Return a .docx with plain Normal paragraphs and 12/10 pt text."""
    document = Document()
    section = document.sections[0]
    section.page_width, section.page_height = Cm(21), Cm(29.7)
    section.top_margin = section.bottom_margin = Cm(1.8)
    section.left_margin = section.right_margin = Cm(2)
    normal = document.styles['Normal']
    normal.font.name, normal.font.size = FONT, Pt(12)
    normal.font.color.rgb = RGBColor(0,0,0)
    normal.paragraph_format.line_spacing = 1.0
    normal.paragraph_format.space_after = Pt(4)
    outline = OxmlElement('w:outlineLvl')
    outline.set(qn('w:val'), '9')
    normal.element.get_or_add_pPr().append(outline)
    properties = document.core_properties
    properties.title = 'Memória de cálculo — '+element_label(result['project']['member'])
    properties.subject = 'Verificações no escopo adotado da ABNT NBR 14762:2010'
    properties.author = ''
    properties.last_modified_by = ''
    properties.comments = ''
    properties.keywords = 'terças; NBR 14762:2010; versão '+__version__
    project = result['project']
    labels = case_labels(result)
    verifications = build_verifications(result)

    noun = 'travessa' if is_girt(project['member']) else 'terça'
    _label(document, 'Esquema da '+noun+' — '+str(project.get('name','Minha '+noun)))
    _figure(document, beam_figure(project), 'Dimensões em mm.',
            'Barra biapoiada com apoios, contenções indicadas e cotas em milímetros')
    _label(document, 'Seção utilizada')
    profile = project['profile']
    dimensions = [profile['h_mm'], profile['b_mm']]
    if profile['family']=='Ue':
        dimensions.append(profile['d_mm'])
    designation = profile['family']+' '+' × '.join(number(v) for v in dimensions)
    designation += ' # '+number(profile['t_mm'])+' mm'
    _paragraph(document, designation, keep=True)
    _table(document, section_rows(result))
    _label(document, 'Propriedades do material')
    _table(document, material_rows(result))
    _label(document, 'Legenda de variáveis')
    _table(document, legend_rows(result))
    _label(document, 'Carregamentos')
    _table(document, load_rows(result))
    _label(document, 'Diagramas de momentos das combinações críticas')
    figures = moment_figures(result, verifications)
    if figures:
        for figure in figures:
            _figure(document, figure['png'], _case_text(figure['caption'],labels),
                    'Momentos Mx e My da combinação '+labels.get(figure['case_id'],figure['case_id']))
    else:
        _paragraph(document, 'Não há momento fletor de ELU a representar nas combinações avaliadas.')
    _label(document, 'Tabela de combinações')
    _table(document, combination_rows(result))
    _label(document, 'Verificações normativas')
    demonstrated = {}
    for index, verification in enumerate(verifications, 1):
        title = str(index)+'. '+str(verification['title'])+' — '+str(verification['reference'])
        if 'NBR 14762:2010' not in title:
            title += ' — NBR 14762:2010'
        _label(document, title)
        _paragraph(document, 'Combinação governante: '+labels.get(verification['case_id'],verification['case_id']), keep=True)
        equations = verification['equations']
        retained, previous = [], []
        for position, equation in enumerate(equations):
            signature = tuple(str(equation.get(key,'')) for key in ('symbolic','numeric','result'))
            if position < len(equations)-2 and signature in demonstrated:
                previous.append(demonstrated[signature])
            else:
                retained.append(equation)
                demonstrated.setdefault(signature, index)
        if previous:
            _paragraph(document, 'Etapas comuns já demonstradas nas verificações '+
                       ', '.join(str(number) for number in dict.fromkeys(previous))+'.', keep=True)
        for equation in retained:
            _equation_paragraph(document, equation['symbolic'], after=1, keep=True)
            _equation_paragraph(document, _numeric_line(equation), after=4)
        passed = verification['status']=='pass'
        p = _paragraph(document, after=6)
        _font(p.add_run('✓ Atende' if passed else '× Não atende'), bold=True,
              color=GREEN if passed else RED)
        utilization = verification.get('utilization')
        if utilization is not None:
            _font(p.add_run(' — aproveitamento '+number(100*utilization)+'%.'))
    if not verifications:
        _paragraph(document, 'Não há verificação numérica concluída para os dados informados.')
    _label(document, 'Conclusão')
    conclusion = conclusion_data(result)
    _paragraph(document, conclusion['text'])
    _label(document, 'Premissas e pontos não verificados')
    assumptions = collect_assumptions(result)
    for figure in figures:
        assumptions = [*assumptions, *figure.get('evidence',{}).get('assumptions',[])]
    evidence = beam_evidence(project)
    premise = evidence.get('assumption') or evidence.get('premise')
    if premise:
        assumptions = [*assumptions, str(premise)]
    assumptions = list(dict.fromkeys(assumptions))
    for i, item in enumerate(assumptions, 1):
        _paragraph(document, f'{i}. '+_case_text(item, labels))
    _paragraph(document, 'Aplicativo Terças '+__version__+'. Base normativa: ABNT NBR 14762:2010.', before=4)
    output = BytesIO()
    document.save(output)
    return output.getvalue()
