"""Combinações, verificações concomitantes e cobertura do cálculo da terça."""
from __future__ import annotations

from copy import deepcopy
from itertools import product
import math

from . import analysis, resistance, sections
from .project import validate_project
from .critical_inputs import resolve_minor_criticals
from .catalog import critical_data
from .orientation import gravity_components, is_girt, projection_angle, minor_restraints_present


def _validate(project):
    def finite(value,path="projeto"):
        if isinstance(value,dict):
            for key,item in value.items(): finite(item,path+"."+key)
        elif isinstance(value,list):
            for i,item in enumerate(value): finite(item,f"{path}[{i}]")
        elif isinstance(value,(int,float)) and not isinstance(value,bool):
            if not math.isfinite(value):
                raise ValueError(f"{path}: informe um número finito.")
    finite(project)
    for key in ("profile","material","member","loads","support","panel","limits"):
        if not isinstance(project.get(key),dict):
            raise ValueError(f"O projeto não contém o grupo obrigatório '{key}'.")
    member,loads=project["member"],project["loads"]
    if float(member["L_m"])<=0:
        raise ValueError("O vão deve ser maior que zero.")
    if abs(float(member["angle_deg"]))>=90:
        raise ValueError("A inclinação da cobertura deve estar entre −90° e 90°.")
    if member["restraint"] not in {"continuous","none","discrete","panel","independent"}:
        raise ValueError("Tipo de contenção desconhecido.")
    if float(member["Lb_m"])<=0:
        raise ValueError("O comprimento entre contenções deve ser maior que zero.")
    if loads["mode"] not in {"characteristic","design"}:
        raise ValueError("Modo de carregamento desconhecido.")
    for key in ("g_metal_kNm","g_roof_kNm","q_kNm","wind_down_kNm","wind_up_kNm","point_kN"):
        if float(loads[key])<0:
            raise ValueError(f"{key}: informe a intensidade não negativa da ação.")
    if loads["point_kN"]>0 and not 0<float(loads["point_x_m"])<member["L_m"]:
        raise ValueError("A carga pontual deve estar no interior do vão: 0 < a < L.")
    for key in ("psi0_q","psi1_q","psi2_q","psi0_w","psi1_w","psi2_w"):
        if not 0<=float(loads[key])<=1:
            raise ValueError(f"{key}: o fator de combinação deve estar entre 0 e 1.")
    for key in ("gravity_L","uplift_L","parallel_L","wall_wind_L"):
        if float(project["limits"][key])<=0:
            raise ValueError("Os denominadores dos limites de flecha devem ser positivos.")


def _memory(title,formula="",substitution="",result="",unit="",reference=""):
    return dict(title=title,formula=formula,substitution=substitution,result=result,
                unit=unit,reference=reference)


def _combinations(project,props):
    loads,member=project["loads"],project["member"]
    sn,cs=gravity_components(member)
    wall=is_girt(member)
    position=loads["point_x_m"] if loads["point_kN"]>0 else member["L_m"]/2
    cases=[]
    signatures=set()
    def add(identifier,label,kind,g=0.,q=0.,P=0.,wind=0.,description="",service_type=None,
            direct=None,factors=None,normal_override=None):
        if wall and kind == 'SLS' and wind and service_type in ('gravity', 'coupled'):
            service_type = 'coupled'
            label = label.replace('ELS adicional', 'ELS rara')
            description = ('Combinação rara adotada para a flecha paralela ao fechamento, conforme A.2.4 e 6.7.3.4. '
                           'A rigidez efetiva considera gravidade e vento concomitantes; Q e P são alternativas. '
                           'O limite perpendicular não é aplicado a essa combinação: usa vento característico isolado, A.1 c/d.')
        qx=(g+q)*sn if direct is None else direct[0]
        qy=(g+q)*cs+wind if direct is None else direct[1]
        n=(loads["nsd_kN"] if kind=="ULS" else loads["nser_kN"]) if loads["mode"]=="design" else 0.
        if normal_override is not None:
            n=normal_override
        row=dict(id=identifier,label=label,kind=kind,qx_kNm=qx,qy_kNm=qy,
                 px_kN=P*sn,py_kN=P*cs,a_m=position,nsd_kN=n,description=description)
        if service_type: row["service_type"]=service_type
        if factors: row["factors"]=factors
        signature=(kind,service_type,*(round(float(row[k]),12) for k in
                    ("qx_kNm","qy_kNm","px_kN","py_kN","nsd_kN")))
        if signature not in signatures:
            cases.append(row)
            signatures.add(signature)
    if loads["mode"]=="design":
        note=("Cargas distribuídas já totais: não se acrescenta peso próprio nem se majoram qd/qs. "
              "A carga pontual de manutenção, quando informada, é característica e adicional: "
              "1,50Pk no ELU e Pk no ELS. N é concomitante ao caso, sem análise global implícita.")
        add("ULS-DIRETO","ELU — esforços e cargas diretos","ULS",P=1.5*loads["point_kN"],
            direct=(loads["qd_parallel_kNm"],loads["qd_normal_kNm"]),description=note)
        if wall:
            add('SLS-DIRETO','ELS — combinação rara concomitante informada','SLS',P=loads['point_kN'],
                direct=(loads['qs_parallel_kNm'],loads['qs_normal_kNm']),service_type='gravity',
                description=note+' qs,x e qs,y são componentes concomitantes da combinação rara informada, adotada para a flecha paralela ao fechamento (A.2.4 e 6.7.3.4).')
            for identifier,label,wind in (('PRESSAO','pressão',loads['wind_down_kNm']),('SUCCAO','sucção',-loads['wind_up_kNm'])):
                if wind:
                    add('SLS-'+identifier+'-ISOLADA','ELS — '+label+' característica isolada','SLS',
                        direct=(0.,wind),normal_override=0.,service_type='wall_wind',
                        description='Wk perpendicular isolado informado separadamente, sem G, Q, P ou N concomitantes: Tabela A.1, notas c e d.')
            return cases
        uplift=loads["qs_normal_kNm"]<0
        add("SLS-DIRETO","ELS — cargas diretas","SLS",P=loads["point_kN"],
            direct=(loads["qs_parallel_kNm"],loads["qs_normal_kNm"]),description=note+
            (" Para qs normal negativo, a comparação L/uplift pressupõe ação oposta isolada, sem abater G."
             if uplift else " A combinação informada é interpretada como rara de serviço."),
            service_type="uplift" if uplift else "gravity")
        return cases
    gm=props["pp"]+loads["g_metal_kNm"]
    gr=loads["g_roof_kNm"]
    maintenance=[]
    if loads["q_kNm"]>0: maintenance.append(("Q",loads["q_kNm"],0.))
    if loads["point_kN"]>0: maintenance.append(("P",0.,loads["point_kN"]))
    winds=[]
    if loads["wind_down_kNm"]>0: winds.append(("PRESSAO",loads["wind_down_kNm"]))
    if loads["wind_up_kNm"]>0: winds.append(("SUCCAO",-loads["wind_up_kNm"]))
    # Os fatores permanecem constantes ao longo de toda a origem da ação.
    g_options=list(product((1.,1.25) if gm else (1.,),(1.,1.35) if gr else (1.,)))
    for fg,fr in g_options:
        g=fg*gm+fr*gr
        gid=f"G{int(round(fg*100))}-{int(round(fr*100))}"
        gf={"G_metal":fg,"G_roof":fr}
        text=(f"γG,metal={fg:g}; γG,componentes={fr:g}. Peso próprio incluído uma única vez. "
              "A envoltória inclui efeitos permanentes favoráveis e desfavoráveis.")
        add(f"ULS-{gid}",f"ELU — permanentes ({fg:g}; {fr:g})","ULS",g=g,description=text,factors=gf)
        for maintenance_id,q,P in maintenance:
            for wind_id,wind in [("SEM-VENTO",0.)]+winds:
                factors={**gf,maintenance_id:1.5,"W":1.4*loads["psi0_w"] if wind else 0.}
                add(f"ULS-{gid}-{maintenance_id}-PRINCIPAL-{wind_id}",
                    f"ELU — {maintenance_id} principal, {wind_id.lower()} ({fg:g}; {fr:g})",
                    "ULS",g=g,q=1.5*q,P=1.5*P,wind=1.4*loads["psi0_w"]*wind,
                    factors=factors,description=text+" Q distribuída e P de manutenção são alternativas, nunca simultâneas. "
                    "Variável principal integral; vento acompanhante com ψ0. Pressão e sucção são alternativas.")
        for wind_id,wind in winds:
            for maintenance_id,q,P in [("SEM-Q",0.,0.)]+maintenance:
                factors={**gf,"W":1.4,maintenance_id:1.5*loads["psi0_q"] if (q or P) else 0.}
                add(f"ULS-{gid}-{wind_id}-PRINCIPAL-{maintenance_id}",
                    f"ELU — {wind_id.lower()} principal, {maintenance_id} ({fg:g}; {fr:g})",
                    "ULS",g=g,q=1.5*loads["psi0_q"]*q,P=1.5*loads["psi0_q"]*P,
                    wind=1.4*wind,factors=factors,description=text+
                    " Vento principal integral; Q ou P acompanhante com ψ0, ou ausente quando favorável.")
    g=gm+gr
    add("SLS-G","ELS — permanentes","SLS",g=g,description="Permanentes características com peso próprio incluído.",service_type="gravity")
    for maintenance_id,q,P in maintenance:
        for wind_id,wind in [("SEM-VENTO",0.)]+winds:
            add(f"SLS-{maintenance_id}-PRINCIPAL-{wind_id}",
                f"ELS {'adicional' if wind<0 else 'rara'} — {maintenance_id} principal"+(" + "+wind_id.lower()+" acompanhante" if wind else ""),
                "SLS",g=g,q=q,P=P,wind=loads["psi1_w"]*wind,
                description="G + ação variável principal + ψ1 da acompanhante, conforme a edição de 2010. Q e P são alternativas. "
                "O estado com sucção acompanhada verifica somente o critério adicional no plano: não aplica a nota e a ações opostas nem substitui o vento isolado da nota f.",
                service_type="coupled" if wind<0 else "gravity")
    for wind_id,wind in winds:
        for maintenance_id,q,P in [("SEM-Q",0.,0.)]+maintenance:
            add(f"SLS-{wind_id}-PRINCIPAL-{maintenance_id}",f"ELS {'adicional' if wind<0 else 'rara'} — {wind_id.lower()} principal, {maintenance_id}",
                "SLS",g=g,q=loads["psi1_q"]*q,P=loads["psi1_q"]*P,wind=wind,
                description="G + W + ψ1Q (ou ψ1P); não se usa ψ0 nas acompanhantes da rara da edição de 2010. "
                "O estado com sucção acompanhada verifica somente o critério adicional no plano: não aplica a nota e a ações opostas nem substitui o vento isolado da nota f.",
                service_type="coupled" if wind<0 else "gravity")
    if loads["wind_up_kNm"]:
        add("SLS-SUCCAO-ISOLADA","ELS — sucção característica isolada","SLS",wind=-loads["wind_up_kNm"],
            description=("Somente Wk de sucção perpendicular ao fechamento: Tabela A.1, notas c e d." if wall else
                         "Somente Wk de sucção, sem descontar permanentes nem acrescentar Q/P: Tabela A.1, nota f."),
            service_type="wall_wind" if wall else "uplift")
    if wall and loads['wind_down_kNm']:
        add('SLS-PRESSAO-ISOLADA','ELS — pressão característica isolada','SLS',wind=loads['wind_down_kNm'],
            description='Somente Wk de pressão perpendicular ao fechamento: Tabela A.1, notas c e d.',service_type='wall_wind')
    return cases


def _plain(value):
    if isinstance(value,dict): return {str(k):_plain(v) for k,v in value.items()}
    if isinstance(value,(list,tuple)): return [_plain(v) for v in value]
    if hasattr(value,"item"): return _plain(value.item())
    if isinstance(value,float) and not math.isfinite(value):
        raise ValueError("O cálculo produziu um valor não finito; confira os dados e o domínio do modelo.")
    return value


def _aggregate_status(rows, *, empty='not_applicable', overall=False):
    """Keep failures and unresolved checks ahead of explicit scope exclusions."""
    for state in ('fail','pending'):
        if any(row['status']==state for row in rows):
            return state
    if any(row['status']=='excluded' for row in rows):
        return 'partial' if overall else 'excluded'
    if any(row.get('conditional',False) or row['status']=='partial' for row in rows):
        return 'partial'
    return 'pass' if rows else empty


def _minor_distortion_excluded(project):
    return project['profile']['family']=='Ue' and project['member'].get('exclude_minor_distortion',False)


_MINOR_DISTORTION_NOTE = (
    'Resultado condicionado ao escopo adotado: flambagem distorcional em My não verificada por solicitação. '
    'A exclusão não constitui dispensa normativa nem demonstração de ausência do modo.'
)


def calculate(project: dict) -> dict:
    """Calcula uma cópia do projeto e retorna somente estruturas JSON estritas."""
    p=validate_project(deepcopy(project))
    _validate(p)
    props=sections.section_properties(p["profile"],p["material"])
    combinations=_combinations(p,props)
    input_project=deepcopy(p)
    section_catalog = critical_data(p['profile'], p['material']) if p['member']['minor_critical_mode']=='automatic' else None
    if section_catalog is not None and p['profile']['family']=='Ue':
        md = section_catalog['major'].get('distortional_Nmm')
        p['member']['mdist_major_kNm'] = md/1e6 if md is not None else None
    p,automatic_minor=resolve_minor_criticals(p,combinations,
        precomputed=section_catalog['minor'] if section_catalog is not None else None)
    L=p["member"]["L_m"]*1000
    E=p["material"]["E_mpa"]
    minor_reference=("NBR 14762:2010, Anexo C.4 (MRD) e Anexo E" if p["profile"]["family"]=="Ue"
                     else "NBR 14762:2010, 9.8.2 e Anexo E")
    biax_reference="NBR 14762:2010, 9.9; resistências de flexão menor: "+minor_reference
    base_resistance=resistance.resistance_summary(p,props)
    checks=[]; limitations=[]; memory=[]; diagrams=[]; service_cases=[]
    limitation_keys=set()
    def limit(code,message,reference="",status="pending"):
        if (code,message,status) not in limitation_keys:
            limitations.append(dict(code=code,message=message,reference=reference,status=status))
            limitation_keys.add((code,message,status))
    def check(identifier,label,case_id,demand=None,capacity=None,unit="",reference="",note="",status=None,utilization=None,conditional=False):
        if utilization is None and demand is not None and capacity is not None and capacity>0:
            utilization=abs(demand)/capacity
        if status is None:
            status="pending" if utilization is None else "pass" if utilization<=1+1e-9 else "fail"
        checks.append(dict(id=identifier,label=label,case_id=case_id,status=status,
                           demand=demand,capacity=capacity,utilization=utilization,unit=unit,
                           reference=reference,note=note,conditional=bool(conditional)))
    memory += [dict(item,title="Estado de referência — Cb=1 — "+item["title"])
               for item in base_resistance.get("memory",[])]
    memory += automatic_minor.get('memory',[])
    if section_catalog is not None:
        memory += section_catalog.get('memory',[])
        memory += section_catalog['major'].get('memory',[])
    resistance_memory_states={1.}
    if is_girt(p['member']) and p['loads']['mode']=='design' and not (p['loads']['wind_down_kNm'] or p['loads']['wind_up_kNm']) and (p['loads']['qd_normal_kNm'] or p['loads']['qs_normal_kNm']):
        check('wall-deflection-wind-data','Flecha perpendicular ao fechamento — vento característico ausente',None,
              reference='NBR 14762:2010, Tabela A.1, notas c e d',status='pending',
              note='A carga normal combinada qd/qs não substitui Wk isolado. Informe pressão e/ou sucção características para concluir o limite perpendicular ao fechamento.')
    memory.append(_memory("Convenções dos eixos e unidades",result=
        "N, mm, MPa no cálculo; qy/Py → Mx/Vy, qx/Px → My/Vx. My positivo comprime as bordas livres. "
        "Os sinais são preservados; o índice de utilização usa intensidades e capacidades do sentido correspondente.",
        reference="NBR 14762:2010, 9.8 e 9.9"))
    memory.append(_memory("Critério de interação de força normal e flexão",
        formula=r"\frac{|N_{Sd}|}{N_{Rd}}+\frac{|M_{x,Sd}|}{M_{x,Rd}}+\frac{|M_{y,Sd}|}{M_{y,Rd}}\leq1",
        result="Solicitações da mesma seção e combinação; resistência axial conforme compressão/tração e resistências de flexão conforme o sinal. "
        "Sem N, a primeira parcela é nula. A análise dos momentos deve corresponder às hipóteses explicitadas para o caso.",
        reference="NBR 14762:2010, 9.9"))
    memory.append(_memory("Peso próprio e combinações",formula=r"q_{pp}=A\,10^{-6}\rho g/1000",
        result=props["pp"],unit="kN/m",reference="Mecânica; NBR 14762:2010, 6.6 e 6.7"))
    if p["loads"]["mode"]=="characteristic":
        memory.append(_memory("Combinações ELU e ELS",formula=r"F_d=\sum\gamma_G G+\gamma_Q Q_1+\sum\gamma_Q\psi_0 Q_j;\quad F_{ser,rara}=\sum G+Q_1+\sum\psi_1Q_j",
            result="γG metálico=1,25; componentes industrializados=1,35; favoráveis=1,00; γQ=1,50; γW=1,40. "
            "P substitui Q, sem simultaneidade. As ações variáveis favoráveis também são omitidas na envoltória. "
            "As combinações quase permanentes/frequentes não substituem as raras da nota e nem o vento isolado da nota f.",
            reference="NBR 14762:2010, Tabelas 2 e 3; 6.7.2.1; 6.7.3.4; A.1 notas e/f"))
        if p["loads"]["nsd_kN"] or p["loads"]["nser_kN"]:
            limit("AXIAL_IGNORED_CHARACTERISTIC","Nsd/Nser são campos exclusivos do modo de cargas diretas e não foram aplicados no modo característico.","Contrato do modelo")
    else:
        memory.append(_memory("Cargas diretas",result="qd e qs já incluem todas as parcelas distribuídas, inclusive peso próprio. "
            "P, se informado, continua sendo uma força característica adicional; sua presença e os fatores aparecem nas combinações.",reference="Hipótese de entrada"))
    if p["member"]["restraint"]=="continuous":
        memory.append(_memory("Contenção contínua",result="Hipótese de contenção lateral e torcional eficaz da mesa comprimida em ambos os sentidos; "
            "a existência da telha, isoladamente, não comprova essa hipótese.",reference="NBR 14762:2010, 9.8.2.2"))
    if p["member"]["restraint"]=="discrete":
        memory.append(_memory("Vão e contenções",result=f"Vão de flexão principal e de flecha = {L/1000:g} m; "
            f"comprimento de contenção lateral/torcional = {p['member']['Lb_m']:g} m. A contenção não cria apoio vertical.",reference="Hipótese estrutural"))
    if p['member']['restraint']=='independent':
        memory.append(_memory('Comprimentos de estabilidade distintos',
            result=f"Lx={p['member']['Lx_m']:g} m; Ly={p['member']['Ly_m']:g} m; Lz={p['member']['Lz_m']:g} m; Kx=Ky=Kz=1. "
                   'Vínculo de deslocamento lateral não equivale a impedimento à torção. Cb=1 conservador. Os esforços mantêm o vão biapoiado L.',
            reference='NBR 14762:2010, 9.7.2, 9.8.2.2 e Anexo E'))
    if is_girt(p['member']):
        memory.append(_memory('Travessa aberta para baixo',
            formula=r'q_x=-G;\quad q_y=\pm W;\quad\delta_{vertical}=-\delta_x',
            result='Gravidade produz My negativo (alma comprimida); vento produz Mx. Flecha paralela: A.1 b; perpendicular: vento característico isolado, A.1 c/d. A inclinação de cobertura armazenada não é aplicada à travessa.',
            reference='Convenção geométrica; NBR 14762:2010, Tabela A.1'))
    if _minor_distortion_excluded(p) and any(abs(c['qx_kNm'])+abs(c['px_kN'])>1e-12 for c in combinations):
        memory.append(_memory('Exclusão solicitada da flambagem distorcional em My',
            result=_MINOR_DISTORTION_NOTE+' Permanecem calculadas as parcelas global e local; '+
            'as interações e o serviço que dependem dessa exclusão são identificados como condicionais.',
            reference='Escopo solicitado; NBR 14762:2010, C.2, C.4 e C.5'))
    resistance_by_case={}
    force_by_case={}
    for combination in combinations:
        case=analysis.beam_case(combination,L)
        force_by_case[combination["id"]]=case
        diag={"case_id":combination["id"],"label":combination["label"],**analysis.sample_forces(case),"dx_mm":[],"dy_mm":[]}
        diagrams.append(diag)
        if _minor_distortion_excluded(p):
            minor_moments=[analysis.forces(case,x)['My'] for x in analysis.moment_candidates(case,'minor')]
            for sign,demand in (('pos',max(0.,max(minor_moments))),('neg',max(0.,-min(minor_moments)))):
                if demand<=1e-6:
                    continue
                check(combination['id']+'-minor-distortion-'+sign,
                      'Flambagem distorcional em My'+('+' if sign=='pos' else '−'),combination['id'],
                      demand/1e6,None,'kN·m','Escopo solicitado; NBR 14762:2010, C.2, C.4 e C.5',
                      note=_MINOR_DISTORTION_NOTE,status='excluded')
                limit('MINOR_DISTORTION_EXCLUDED',_MINOR_DISTORTION_NOTE,
                      'Escopo solicitado; NBR 14762:2010, C.2, C.4 e C.5',status='excluded')
        if combination["kind"]!="ULS":
            continue
        identifier=combination["id"]
        second_order=False
        ideal_planar=case["N"]>0 and abs(case["qx"])+abs(case["px"])+abs(case["py"])<1e-12 and abs(case["qy"])>1e-12
        if ideal_planar:
            try:
                analysis.beam_column_forces(case,L/2,E,props["Ix"])
                second_order=True
            except analysis.EulerInstability as exc:
                nex=math.pi**2*E*props["Ix"]/L**2
                check(identifier+"-euler-model","Instabilidade do modelo plano ideal",identifier,
                      case["N"]/1000,nex/1000,"kN",reference="Mecânica: carga de Euler",note=str(exc),status="fail")
        def case_forces(x,side="right"):
            return analysis.beam_column_forces(case,x,E,props["Ix"]) if second_order else analysis.forces(case,x,side)
        diag["analysis_type"]="segunda ordem: barra plana inicialmente reta com EIx bruto constante" if second_order else "primeira ordem"
        if second_order:
            responses=[case_forces(x*1000) for x in diag["z_m"]]
            diag["Mx_kNm"]=[f["Mx"]/1e6 for f in responses]
            diag["Vy_kN"]=[f["Vy"]/1000 for f in responses]
        cb=1.
        if p["member"]["restraint"]=="none" and case["N"]==0 and p["member"]["load_at_shear_center"]:
            cb=analysis.cb_factor(case)
        rd=resistance.resistance_summary(p,props,cb_major=cb)
        resistance_by_case[identifier]=rd
        state=round(cb,12)
        if state not in resistance_memory_states:
            memory += [dict(item,title=f"{identifier} — Cb={cb:.8g} — "+item["title"])
                       for item in rd.get("memory",[])]
            resistance_memory_states.add(state)
        capacities=[]
        for name,key in (("Mx,Rd+","major_pos_Rd_Nmm"),("Mx,Rd−","major_neg_Rd_Nmm"),
                         ("My,Rd+","minor_pos_Rd_Nmm"),("My,Rd−","minor_neg_Rd_Nmm")):
            value=rd.get(key)
            capacities.append(name+"="+(f"{value/1e6:.9g} kN·m" if value is not None else "pendente"))
        memory.append(_memory(identifier+" — resistências utilizadas",formula=r"C_b=\frac{12,5M_{\max}}{2,5M_{\max}+3M_A+4M_B+3M_C}",
            substitution=f"Cb={cb:.9g}; estado de contenção={p['member']['restraint']}",
            result="; ".join(capacities)+". A memória do estado Cb correspondente define as resistências desta combinação. "
            "Cb=1 é adotado quando a majoração não é aplicável ou quando é conservadoramente dispensada.",
            reference="NBR 14762:2010, 9.8.2.2 (flexão maior); "+minor_reference+" (flexão menor); capacidades por sentido e combinação"))
        candidates=sorted(set(analysis.moment_candidates(case,"major")+analysis.moment_candidates(case,"minor")))
        force_rows=[(x,case_forces(x)) for x in candidates]
        major_positive=max(0.,max(f["Mx"] for _,f in force_rows))
        major_negative=max(0.,-min(f["Mx"] for _,f in force_rows))
        minor_positive=max(0.,max(f["My"] for _,f in force_rows))
        minor_negative=max(0.,-min(f["My"] for _,f in force_rows))
        has_major=max(major_positive,major_negative)>1e-6
        has_minor=max(minor_positive,minor_negative)>1e-6
        conditional_minor=has_minor and _minor_distortion_excluded(p)
        has_axial=abs(case["N"])>1e-6
        active={"all"}
        reaction_values=analysis.reactions(case)
        if max(reaction_values["RAy"],reaction_values["RBy"])>1e-6:
            active.add("support")
        if has_major: active.add("major")
        if has_minor: active.add("minor")
        if major_positive>1e-6: active.add("major_pos")
        if major_negative>1e-6: active.add("major_neg")
        if minor_positive>1e-6: active.add("minor_pos")
        if minor_negative>1e-6: active.add("minor_neg")
        if case["N"]>0: active.add("compression")
        if case["N"]<0: active.add("tension")
        for item in rd.get("limitations",[]):
            applies=item.get("applies_to","all")
            applicable=bool(active.intersection(applies if isinstance(applies,list) else [applies]))
            if applicable:
                item_status=item.get('status','pending')
                limit(item["code"],item["message"],item.get("reference",""),status=item_status)
                check(identifier+"-domain-"+item["code"],"Domínio: "+item["message"],identifier,
                      reference=item.get("reference",""),status=item_status)
        for suffix,label,demand,key in (
            ("Mx+","Flexão maior positiva",major_positive,"major_pos_Rd_Nmm"),
            ("Mx-","Flexão maior negativa",major_negative,"major_neg_Rd_Nmm"),
            ("My+","Flexão menor — bordas livres comprimidas",minor_positive,"minor_pos_Rd_Nmm"),
            ("My-","Flexão menor — lado da alma comprimido",minor_negative,"minor_neg_Rd_Nmm")):
            if demand<=1e-6: continue
            cap=rd.get(key)
            check(identifier+"-"+suffix,label,identifier,demand/1e6,cap/1e6 if cap else None,"kN·m",
                  minor_reference if suffix.startswith("My") else "NBR 14762:2010, 9.8.2",
                  note=f"Extremo real no vão; Cb maior={cb:.6g}. A resistência respeita o sinal do momento. "+
                  ("Momento de segunda ordem do modelo plano ideal, EIx bruto constante." if second_order else "")+
                  (' '+_MINOR_DISTORTION_NOTE if suffix.startswith('My') and conditional_minor else ''),
                  conditional=suffix.startswith('My') and conditional_minor)
        # A expressão 9.8.4 usa a resistência LOCAL da seção, nunca R·MRd nem MRd de FLT.
        shear_points=[case_forces(x,side) for x in (0.,case["a"],L) for side in ("left","right")]
        vy=max(abs(f["Vy"]) for f in shear_points)
        vx=max(abs(f["Vx"]) for f in shear_points)
        if vy>1e-6:
            cap=rd.get("shear_Rd_N")
            check(identifier+"-Vy","Cisalhamento da alma",identifier,vy/1000,cap/1000 if cap else None,"kN","NBR 14762:2010, 9.8.3")
        if vx>1e-6:
            excluded=p['member'].get('exclude_minor_shear',False)
            note=('Cisalhamento no eixo menor e suas interações excluídos por solicitação; nenhuma capacidade foi atribuída. '
                  'A exclusão não representa atendimento nem dispensa normativa.' if excluded else
                  'As expressões de 9.8.3 para almas não são aplicadas automaticamente ao conjunto de mesas e enrijecedores sob Vx; esse mecanismo não está implementado.')
            check(identifier+"-Vx","Cisalhamento no eixo menor",identifier,vx/1000,None,"kN","NBR 14762:2010, 9.8.3",
                  note=note,status='excluded' if excluded else 'pending')
            limit('MINOR_SHEAR_EXCLUDED' if excluded else 'MINOR_SHEAR',note,
                  'NBR 14762:2010, 9.8.3–9.8.4',status='excluded' if excluded else 'pending')
        if has_major or vy>1e-6:
            mr,vr=rd.get("major_local_Nmm"),rd.get("shear_Rd_N")
            if mr and vr:
                mv=analysis.max_beam_column_moment_shear(case,E,props["Ix"],mr,vr) if second_order else analysis.max_moment_shear(case,mr,vr)
                check(identifier+"-MV","Interação Mx–Vy na mesma seção",identifier,mv["utilization"],1.,"índice","NBR 14762:2010, 9.8.4",
                      note=f"Máximo analítico em z={mv['x_mm']/1000:.6g} m, lado {mv['side']}; "
                      f"Mx={mv['Mx']/1e6:.6g} kN·m e Vy={mv['Vy']/1000:.6g} kN concomitantes.")
            else:
                check(identifier+"-MV","Interação Mx–Vy",identifier,reference="NBR 14762:2010, 9.8.4",status="pending")
        if has_minor:
            names=("major_pos_Rd_Nmm","major_neg_Rd_Nmm","minor_pos_Rd_Nmm","minor_neg_Rd_Nmm")
            demands=(major_positive,major_negative,minor_positive,minor_negative)
            caps=[rd.get(key) if demand>1e-6 else 1. for key,demand in zip(names,demands)]
            if all(cap is not None and cap>0 for cap in caps):
                biax=analysis.max_biaxial(case,*caps)
                ratio=biax["utilization"]
                check(identifier+"-biax","Interação de flexão biaxial",identifier,ratio,1.,"índice",biax_reference,
                      note=f"Máximo em z={biax['x_mm']/1000:.6g} m; dois momentos da mesma seção e combinação. Esta parcela não inclui N. "+
                      (_MINOR_DISTORTION_NOTE if conditional_minor else ''),conditional=conditional_minor)
            else:
                check(identifier+"-biax","Interação de flexão biaxial",identifier,reference=biax_reference,
                      note="Há resistência de um dos sentidos não determinada. "+
                      (_MINOR_DISTORTION_NOTE if conditional_minor else ''),conditional=conditional_minor)
        if has_axial:
            key="compression_Rd_N" if case["N"]>0 else "tension_Rd_N"
            cap=rd.get(key)
            check(identifier+"-N","Compressão axial isolada" if case["N"]>0 else "Tração axial isolada",
                  identifier,abs(case["N"])/1000,cap/1000 if cap else None,"kN","NBR 14762:2010, 9.7" if case["N"]>0 else "NBR 14762:2010, 9.6")
            if has_major or has_minor:
                moment_capacity=rd.get("major_pos_Rd_Nmm" if major_positive>=major_negative else "major_neg_Rd_Nmm")
                tension_caps={"major_pos":rd.get("major_pos_Rd_Nmm") if major_positive>1e-6 else 1.,
                              "major_neg":rd.get("major_neg_Rd_Nmm") if major_negative>1e-6 else 1.,
                              "minor_pos":rd.get("minor_pos_Rd_Nmm") if minor_positive>1e-6 else 1.,
                              "minor_neg":rd.get("minor_neg_Rd_Nmm") if minor_negative>1e-6 else 1.}
                tension_available=case["N"]<0 and all(tension_caps.values())
                if (second_order and not has_minor and moment_capacity) or tension_available:
                    capacity_for_screen=cap if cap else rd.get("tension_gross_Rd_N") if case["N"]<0 else None
                    if capacity_for_screen:
                        if tension_available:
                            bending=analysis.max_biaxial(case,**tension_caps)
                            moment_ratio=bending["utilization"]
                            critical_x=bending["x_mm"]
                        else:
                            moment_ratio=max(major_positive,major_negative)/moment_capacity
                            critical_x=L/2
                        ratio=abs(case["N"])/capacity_for_screen+moment_ratio
                        note=("N e M da seção central, com momento de segunda ordem do modelo plano ideal. " if second_order else
                              "Sem tomar crédito da estabilização por tração: momentos de primeira ordem, capacidades por sentido e máximo concomitante no vão. ")
                        if cap is None:
                            note+="A parcela axial usa SOMENTE escoamento bruto como triagem; faltam An/Ct e ruptura líquida para obter Nt,Rd."
                        if conditional_minor:
                            note+=' '+_MINOR_DISTORTION_NOTE
                        check(identifier+"-NM","Força normal e flexão — interação da barra",identifier,ratio,1.,"índice",
                              "NBR 14762:2010, 9.9",note=note,
                              status=("fail" if ratio>1+1e-9 else "pending") if cap is None else None,
                              conditional=conditional_minor)
                        memory.append(_memory(identifier+" — interação força normal e flexão",
                            formula=r"\eta_{NM}=\frac{|N_{Sd}|}{N_{Rd}}+\frac{|M_{x,Sd}|}{M_{x,Rd}}+\frac{|M_{y,Sd}|}{M_{y,Rd}}\leq1",
                            substitution=f"|N|/NRd={abs(case['N'])/capacity_for_screen:.9g}; soma das parcelas de flexão={moment_ratio:.9g}; z={critical_x/1000:.9g} m",
                            result=ratio,unit="índice",reference="NBR 14762:2010, 9.9. "+note))
                    else:
                        check(identifier+"-NM","Força normal e flexão",identifier,status="pending",reference="NBR 14762:2010, 9.9",
                              note="A capacidade axial total não foi determinada.")
                else:
                    check(identifier+"-NM","Força normal e flexão — análise de segunda ordem",identifier,
                          note="Este caso não é a viga-coluna plana com N constante e q uniforme. Capacidades isoladas e diagramas de primeira ordem não validam a interação.",
                          reference="NBR 14762:2010, 8.1 e 9.9",status="pending")
                check(identifier+"-NM-global","Imperfeições e estabilidade global do sistema",identifier,status="pending",
                      note="A solução de barra inicialmente reta não substitui imperfeições geométricas, deslocabilidade, flexotorção nem o modelo global do galpão.",
                      reference="NBR 14762:2010, 8.1")
                limit("AXIAL_GLOBAL","O modelo analítico de viga-coluna cobre apenas N constante, q uniforme, flexão maior plana, EI bruto e barra inicialmente reta; imperfeições e estabilidade do sistema permanecem pendentes.","NBR 14762:2010, 8.1 e 9.9")
        if (has_minor or has_axial) and major_negative>1e-6 and p["member"]["restraint"]=="panel":
            check(identifier+"-F-biax","Anexo F — domínio do plano de carregamento",identifier,status="pending",
                  note="A combinação tem flexão menor ou força axial. A aplicação de R em flexão simples não aprova esse estado combinado.",reference="NBR 14762:2010, F.1")
            limit("PANEL_BIAXIAL","Anexo F exige flexão em plano paralelo à alma; o estado com flexão menor ou força axial requer tratamento adicional.","NBR 14762:2010, F.1")
        if has_minor and minor_restraints_present(p['member']):
            check(identifier+"-minor-restraints","Modelo do eixo menor com contenções intermediárias",identifier,status="pending",
                  note="Os diagramas mostrados conservam a barra biapoiada de vão L. A contenção lateral altera o caminho das forças no eixo menor; os vínculos e suas reações precisam de modelo próprio.",reference="Hipótese estrutural")
        r=analysis.reactions(case)
        for end in ("A","B"):
            demand=r["R"+end+"y"]
            if abs(demand)<=1e-6: continue
            if not p["support"]["check"]:
                check(identifier+"-support-"+end,"Alma no apoio "+end,identifier,abs(demand)/1000,None,"kN",
                      note="Verificação de apoio desativada; não representa dispensa normativa.",reference="NBR 14762:2010, 9.5.1 e Anexo D")
            elif demand<0:
                check(identifier+"-support-"+end,"Reação de levantamento no apoio "+end,identifier,abs(demand)/1000,None,"kN",
                      note="O contato de apoio informado não comprova a transferência sob levantamento; dimensionar fixação e introdução da força na chapa.",reference="NBR 14762:2010, 10 e Anexo D")
            else:
                cap=rd.get("support_Rd_N")
                check(identifier+"-support-"+end,"Força localizada na alma — apoio "+end,identifier,demand/1000,cap/1000 if cap else None,"kN",
                      reference="NBR 14762:2010, Anexo D, Tabela D.2",
                      note="Extremidade, uma mesa carregada; conexão e comprimento real de contato são hipóteses do detalhe.")
        if case["px"] or case["py"]:
            check(identifier+"-point-introduction","Introdução da força concentrada no vão",identifier,
                  math.hypot(case["px"],case["py"])/1000,None,"kN",reference="NBR 14762:2010, 9.5.1 e Anexo D",
                  note="O comprimento c do apoio não representa contato da força pontual no vão; esse detalhe não foi informado.")
        memory.append(_memory(combination["label"],formula=r"R_A=qL/2+Pb/L;\quad M(z)=R_Az-qz^2/2-P\max(z-a,0)",
            substitution=f"qy={case['qy']:.8g} N/mm; qx={case['qx']:.8g} N/mm; Py={case['py']:.8g} N; Px={case['px']:.8g} N; L={L:g} mm",
            result=f"RAy={r['RAy']/1000:.8g} kN; RBy={r['RBy']/1000:.8g} kN; Cb={cb:.8g}. "+combination["description"],reference="Mecânica estrutural; NBR 14762:2010, 6.7"))
        if second_order:
            mid=case_forces(L/2)
            memory.append(_memory(combination["label"]+" — viga-coluna plana",
                formula=r"k=\sqrt{N/(EI_x)};\quad M_2(z)=\frac{q}{k^2}\left[\frac{\cos(k(z-L/2))}{\cos(kL/2)}-1\right];\quad V_2=dM_2/dz",
                result=f"M2 máximo={mid['Mx']/1e6:.8g} kN·m; V2 seccional no apoio={case_forces(0)['Vy']/1000:.8g} kN; "
                f"reação global={r['RAy']/1000:.8g} kN; flecha com ações ELU={mid['dy']:.8g} mm (não comparar com ELS). "
                "Barra inicialmente reta, sem deslocamento dos apoios, rigidez bruta, sem imperfeições adicionais.",reference="Solução auxiliar de mecânica; NBR 14762:2010, 8.1 e 9.9"))
    _service(p,props,combinations,force_by_case,diagrams,service_cases,memory,check,limit)
    # Cobertura real: passar nas resistências da barra não dimensiona seus conectores.
    loaded=any(abs(c[k])>1e-12 for c in combinations for k in ("qx_kNm","qy_kNm","px_kN","py_kN","nsd_kN"))
    if loaded:
        check("connections","Ligações, fixações e ancoragens",None,status="pending",reference="NBR 14762:2010, seção 10",
              note="O motor verifica a alma do apoio quando habilitada; não dimensiona parafusos, soldas, chapas de ligação nem ancoragens das contenções.")
        limit("CONNECTIONS","Ligações, fixações e resistência/rigidez das contenções exigem detalhamento próprio. Resultados do perfil não aprovam o conjunto.","NBR 14762:2010, 8 e 10")
    else:
        check("no-actions","Ações para verificação",None,status="pending",reference="Hipótese de entrada",
              note="Nenhuma ação foi aplicada. O estado de solicitação nula não representa dimensionamento nem aprovação da terça.")
    if not p["member"]["load_at_shear_center"] and loaded:
        check("torsion","Torção por excentricidade do carregamento",None,status="pending",reference="NBR 14762:2010, 8 e 9.8.2.2",
              note="Os diagramas não incluem torção de Saint-Venant, empenamento ou efeitos da altura de aplicação da carga.")
        limit("TORSION","Carga fora do centro de torção: o modelo de flexão não verifica os esforços torsionais nem a estabilidade correspondente.","NBR 14762:2010, 9.8.2.2")
    numeric=[c for c in checks if c["utilization"] is not None]
    highest=max(numeric,key=lambda c:c["utilization"]) if numeric else None
    overall=_aggregate_status(checks,empty='pass',overall=True)
    coverage=_coverage(checks,p)
    result=dict(project=input_project,automatic_minor=automatic_minor,section_catalog=section_catalog,section=props,resistances={**base_resistance,"by_case":resistance_by_case},
                combinations=combinations,checks=checks,service_cases=service_cases,diagrams=diagrams,
                memory=memory,limitations=limitations,overall_status=overall,
                governing=None if highest is None else dict(label=highest["label"],case_id=highest["case_id"],utilization=highest["utilization"]),coverage=coverage)
    return _plain(result)


def _service(p,props,combinations,force_by_case,diagrams,service_cases,memory,check,limit):
    L=p["member"]["L_m"]*1000
    E=p["material"]["E_mpa"]
    angle=projection_angle(p['member'])
    wall=is_girt(p['member'])
    for combination in combinations:
        if combination["kind"]!="SLS": continue
        identifier=combination["id"]
        case=force_by_case[identifier]
        uplift=combination.get("service_type") in ('uplift', 'wall_wind')
        coupled=combination.get("service_type")=="coupled"
        additional=p['limits']['additional_checks']
        if coupled and not additional and not wall:
            continue
        denominator=p['limits']['wall_wind_L'] if wall and uplift else p["limits"]["uplift_L"] if uplift else p["limits"]["gravity_L"]
        limv=None if uplift or (coupled and not wall) else L/denominator
        limy=None if coupled or (not uplift and not additional) else L/denominator
        limx=L/p["limits"]["parallel_L"] if additional else None
        stiff_cache={}
        def stiffness(mx,my,n=0.):
            key=(round(mx,6),round(my,6),round(n,6))
            if key not in stiff_cache:
                stiff_cache[key]=resistance.service_stiffness(p["profile"],p["material"],props,mx,my,n,project=p)
            return stiff_cache[key]
        major_only=abs(case["qx"])+abs(case["px"])<1e-12
        same_sign=case["qy"]*case["py"]>=0
        minor_only=abs(case["qy"])+abs(case["py"])<1e-12
        minor_same_sign=case["qx"]*case["px"]>=0
        ignore_restraints=p['member'].get('deflection_ignore_restraints',False)
        intermediate_restraints=minor_restraints_present(p['member'])
        conditional_distortion=not major_only and _minor_distortion_excluded(p)
        conditional_model=ignore_restraints and intermediate_restraints and any(
            abs(case[key])>1e-12 for key in ('qx','qy','px','py'))
        conditional=conditional_distortion or conditional_model
        scope_notes=[]
        if conditional_distortion:
            scope_notes.append(_MINOR_DISTORTION_NOTE)
        if conditional_model:
            scope_notes.append('Hipótese solicitada para flechas: barra biapoiada no vão integral L, sem o efeito das contenções intermediárias. '
                               'Lb, estabilidade e modelo dos vínculos no ELU permanecem inalterados.')
        scope_note=' '.join(scope_notes)
        if conditional_model:
            memory.append(_memory(combination['label']+' — hipótese de vínculos para a flecha',
                substitution=f"L={L/1000:g} m; Lb cadastrado={p['member']['Lb_m']:g} m, não utilizado como vão nem como comprimento de estabilidade da rigidez de serviço.",
                result=scope_notes[-1],reference='Hipótese de modelo solicitada; NBR 14762:2010, 8.1 e 9.8.5'))
        reference_points=set(analysis.moment_candidates(case,"major")+analysis.moment_candidates(case,"minor"))
        reference_force=max((analysis.forces(case,x) for x in reference_points),
                            key=lambda f:abs(f["Mx"])/props["Wx"]+abs(f["My"])/min(props["Wy_web"],props["Wy_edge"]))
        reference_stiffness=stiffness(reference_force["Mx"],reference_force["My"],case["N"])
        computed=None
        exact_column=False
        unstable=False
        try:
            if case["N"] and major_only and not case["px"] and not case["py"]:
                column_peak=analysis.beam_column_forces(case,L/2,E,props["Ix"])
                reference_stiffness=stiffness(column_peak["Mx"],0.,case["N"])
                # Sob N+M, a prova é conjunta. Verificam-se a faixa completa de
                # momentos e todos os elementos, não apenas λ de flexão pura.
                for j in range(101):
                    current=stiffness(column_peak["Mx"]*j/100,0.,case["N"])
                    if not current.get("converged") or current.get("Ix") is None or \
                       abs(current["Ix"]/props["Ix"]-1)>1e-8 or \
                       abs(current["Iy"]/props["Iy"]-1)>1e-8 or \
                       abs(current.get("Ixy",0.))>1e-7:
                        raise analysis.StiffnessUnavailable(dict(current,limitations=current.get("limitations",[])+[
                            dict(code="AXIAL_SERVICE_REDUCED",message="A solução exata com N requer comprovar seção bruta integral na faixa de momentos. Se houver redução, é necessário resolver a viga-coluna com rigidez efetiva variável.",reference="NBR 14762:2010, 8.1 e 9.8.5")]))
                computed=analysis.beam_column_deflections(case,E,props["Ix"],angle)
                exact_column=True
            if case["N"] and not exact_column:
                raise analysis.StiffnessUnavailable(dict(converged=False,limitations=[
                    dict(code="AXIAL_SERVICE_MODEL",message="Nser com carga pontual ou flexão biaxial exige análise de viga-coluna com rigidez efetiva conjunta, transporte ao centroide efetivo e rigidez geométrica. Os deslocamentos não são calculados neste domínio.",
                         reference="NBR 14762:2010, 8.1 e 9.8.5")]))
            gross=reference_stiffness.get("converged") and reference_stiffness.get("Ix") is not None and \
                abs(reference_stiffness["Ix"]/props["Ix"]-1)<1e-8 and \
                abs(reference_stiffness["Iy"]/props["Iy"]-1)<1e-8 and abs(reference_stiffness.get("Ixy",0.))<1e-7
            uniform_vector=abs(case["px"])+abs(case["py"])<1e-12
            use_constant=case["N"]==0 and reference_stiffness.get("converged") and \
                ((major_only and (same_sign or gross)) or (gross and uniform_vector) or
                 (minor_only and minor_same_sign and reference_stiffness.get("method")=="MRD_C5_minor"))
            if exact_column:
                pass
            elif use_constant:
                computed=analysis.fixed_stiffness_deflections(case,E,reference_stiffness,angle)
                if gross and reference_stiffness.get("method")=="MRD_C5_minor":
                    computed["method"]="Iy,ef = Iy,g pelo MRD C.5; rigidez constante e solução analítica por trechos"
                elif not gross:
                    computed["method"]=("Iy,ef mínimo por MRD C.5" if reference_stiffness.get("method")=="MRD_C5_minor" else "Ief mínimo por MSE")+", constante no vão, conservador para cargas uniaxiais de mesmo sinal"
            else:
                computed=analysis.variable_stiffness_deflections(case,E,stiffness,angle)
        except analysis.StiffnessUnavailable as exc:
            reference_stiffness=exc.result
        except analysis.EulerInstability as exc:
            unstable=True
            nex=math.pi**2*E*props["Ix"]/L**2
            check(identifier+"-euler-service","Instabilidade do modelo plano em serviço",identifier,
                  case["N"]/1000,nex/1000,"kN",status="fail",reference="Mecânica: carga de Euler",note=str(exc))
        stiffness_reference=("NBR 14762:2010, Anexo C.5 (rigidez de flexão menor)" if
            any(item.get("method")=="MRD_C5_minor" for item in stiff_cache.values()) else
            "NBR 14762:2010, 9.2 e 9.8.5 (rigidez efetiva)")
        if computed is None or not computed.get("converged"):
            messages=reference_stiffness.get("limitations",[])
            reason="A seção efetiva conjunta ou a integração não convergiu dentro do domínio implementado."
            details=[item.get("message","") if isinstance(item,dict) else str(item) for item in messages]
            if any(details): reason=" ".join(dict.fromkeys(item for item in details if item))
            if scope_note:
                reason+=' '+scope_note
            for item in messages:
                if isinstance(item,dict):
                    limit(item.get("code","SERVICE_DOMAIN"),item.get("message",reason),item.get("reference","NBR 14762:2010, 9.8.5"))
                else: limit("SERVICE_DOMAIN",str(item),"NBR 14762:2010, 9.8.5")
            check(identifier+"-deflection","Deslocamentos em serviço",identifier,reference=stiffness_reference,note=reason,status="pending",conditional=conditional)
            service_cases.append(dict(id=identifier,label=combination["label"],status="fail" if unstable else "pending",dx_mm=None,dy_mm=None,
                limit_x_mm=limx,limit_y_mm=limy,utilization_x=None,utilization_y=None,note=reason,conditional=conditional))
            continue
        dx,dy,dv=computed["dx_mm"],computed["dy_mm"],computed["vertical_mm"]
        pending_axial=abs(case["N"])>1e-6 and not exact_column
        pending_minor=not ignore_restraints and intermediate_restraints and \
            abs(case["qx"])+abs(case["px"])>1e-12
        mixed_uplift=uplift and (case["px"] or case["py"])
        wall_wind_preload=wall and uplift and p['loads']['mode']=='design' and abs(p['loads']['nser_kN'])>1e-12
        note=computed["method"]+"; vão integral L usado no deslocamento. "+combination["description"]
        if scope_note:
            note+=' '+scope_note
        if pending_axial:
            note+=" Deslocamento de primeira ordem: os efeitos de N na rigidez geométrica/Pδ não são resolvidos nesta versão."
        elif exact_column:
            note+=" A efetividade integral foi conferida em 101 estados da faixa de momentos N+M. Hipótese de barra inicialmente reta; imperfeições e sistema global não são modelados."
        if pending_minor:
            note+=" A contenção intermediária exige modelo das reações e da continuidade do eixo menor."
        if mixed_uplift:
            note+=" Carga direta de sucção e P simultâneos não constituem vento isolado; a comparação automática requer confirmação do caso."
        if wall_wind_preload:
            note+=' O vento isolado foi separado das ações, mas o efeito da força axial preexistente na rigidez e no deslocamento incremental de vento não está resolvido. Essa verificação permanece pendente.'
        pending=pending_axial or pending_minor or bool(mixed_uplift) or wall_wind_preload
        ratio_x=abs(dx)/limx if limx is not None else None
        ratio_y=abs(dy)/limy if limy is not None else None
        ratio_v=abs(dv)/limv if limv is not None else None
        ratios=[value for value in (ratio_x,ratio_y,ratio_v) if value is not None]
        service_status="pending" if pending else "fail" if max(ratios,default=0.)>1+1e-9 else "pass"
        service_cases.append(dict(id=identifier,label=combination["label"],status=service_status,dx_mm=dx,dy_mm=dy,
            limit_x_mm=limx,limit_y_mm=limy,utilization_x=ratio_x,utilization_y=ratio_y,
            dvertical_mm=dv,limit_vertical_mm=limv,
            utilization_vertical=ratio_v,
            dx_at_m=computed["dx_at_mm"]/1000,dy_at_m=computed["dy_at_mm"]/1000,note=note,conditional=conditional))
        if not pending:
            if limy is not None:
                check(identifier+"-deflection-normal",("Flecha perpendicular ao fechamento — vento isolado" if wall else "Flecha normal — sucção isolada") if uplift else "Flecha normal — critério adicional",
                      identifier,abs(dy),limy,"mm",stiffness_reference+"; "+(("Tabela A.1, notas c e d" if wall else "Tabela A.1, nota f") if uplift else "limite informado; projeção vertical verificada separadamente"),note=note,conditional=conditional)
            if limx is not None and abs(dx)>1e-9:
                check(identifier+"-deflection-parallel","Flecha paralela ao fechamento — limite adicional" if wall else "Flecha no plano da cobertura — limite adicional",identifier,abs(dx),limx,"mm",
                      stiffness_reference+"; critério adicional informado, não é limite universal da Tabela A.1 para terças",note=note,conditional=conditional)
            if not uplift and (not coupled or wall):
                check(identifier+"-deflection-vertical","Flecha paralela ao fechamento — gravidade" if wall else "Flecha vertical — combinação rara",identifier,abs(dv),limv,"mm",
                      stiffness_reference+("; Tabela A.1, nota b; A.2.4 e 6.7.3.4" if wall else "; Tabela A.1, nota e"),note="Projeção na direção da gravidade; seu máximo é localizado ao longo do vão. "+note,conditional=conditional)
        else:
            check(identifier+"-deflection-model","Modelo dos deslocamentos em serviço",identifier,status="pending",
                  reference="NBR 14762:2010, 8.1; "+stiffness_reference,note=note,conditional=conditional)
        diag=next(d for d in diagrams if d["case_id"]==identifier)
        diag["analysis_type"]="segunda ordem: viga-coluna plana ideal" if exact_column else "primeira ordem"
        if exact_column:
            values=[analysis.beam_column_forces(case,x*1000,E,props["Ix"]) for x in diag["z_m"]]
            diag["Mx_kNm"]=[f["Mx"]/1e6 for f in values]
            diag["Vy_kN"]=[f["Vy"]/1000 for f in values]
        diag["dx_mm"]=computed["dx_series_mm"]
        diag["dy_mm"]=computed["dy_series_mm"]
        memory.append(_memory(combination["label"]+" — rigidez e flecha",
            formula=r"\begin{bmatrix}\kappa_x\\\kappa_y\end{bmatrix}=\frac{1}{E(I_xI_y-I_{xy}^2)}\begin{bmatrix}I_x&-I_{xy}\\-I_{xy}&I_y\end{bmatrix}\begin{bmatrix}M_y\\M_x\end{bmatrix}",
            result=f"dx={dx:.8g} mm; dy={dy:.8g} mm; vertical={dv:.8g} mm; {computed['stations']} estações. "+note,
            reference="Mecânica estrutural; "+stiffness_reference+"; Anexo A (limites)"))
        memory+=reference_stiffness.get("memory",[])
        if exact_column:
            memory.append(_memory(combination["label"]+" — efeito axial em serviço",
                formula=r"u=\frac{L}{2}\sqrt{|N|/(EI_x)};\quad M_{max}=\frac{qEI_x}{N}(\sec u-1)\ (N>0);\quad\delta=\frac{M_{max}-qL^2/8}{N}",
                result=f"Nser={case['N']/1000:g} kN; Mser,max={column_peak['Mx']/1e6:.8g} kN·m; flecha={dy:.8g} mm. "
                "Para tração usa-se a forma hiperbólica Mmax=qEI/|N|·(1−sech u).",
                reference="Solução auxiliar de mecânica; NBR 14762:2010, 9.8.5"))


def _coverage(checks,p):
    groups=[("Flexão maior",lambda c:c["id"].endswith(("Mx+","Mx-"))),
            ("Flexão menor",lambda c:c["id"].endswith(("My+","My-"))),
            ("Flambagem distorcional da flexão menor",lambda c:'-minor-distortion-' in c['id']),
            ("Interação biaxial",lambda c:c["id"].endswith("biax")),
            ("Cisalhamento da alma e M–V",lambda c:c["id"].endswith(("Vy","MV"))),
            ("Cisalhamento do eixo menor",lambda c:c["id"].endswith("Vx")),
            ("Compressão axial",lambda c:c["label"]=="Compressão axial isolada"),
            ("Tração axial",lambda c:c["label"]=="Tração axial isolada"),
            ("Força axial e análise de segunda ordem",lambda c:c["id"].endswith(("-N","-NM","-NM-global","-euler-model"))),
            ("Forças localizadas e apoios",lambda c:"support-" in c["id"] or c["id"].endswith("point-introduction")),
            ("Deslocamentos",lambda c:"deflection" in c["id"] or c["id"].endswith("euler-service")),
            ("Ligações e ancoragens",lambda c:c["id"]=="connections"),
            ("Torção",lambda c:c["id"]=="torsion"),
            ("Domínio normativo e vínculos",lambda c:"-domain-" in c["id"] or c["id"].endswith(("F-biax","minor-restraints")) or c["id"]=="no-actions")]
    result=[]
    for label,selector in groups:
        subset=[c for c in checks if selector(c)]
        if label=='Flambagem distorcional da flexão menor' and not subset:
            # The ordinary My resistance already includes applicable modes.
            # This additional row records the explicit omitted branch only.
            continue
        status=_aggregate_status(subset)
        note="; ".join(dict.fromkeys(c["note"] for c in subset if
            (c['status'] in ('pending','excluded') or c.get('conditional',False)) and c['note']))
        if not subset:
            note="Sem solicitação correspondente nos casos analisados."
            if label=="Torção": note="Ausência de torque assumida pela aplicação da carga no centro de torção; não há análise torsional."
        result.append(dict(verification=label,status=status,note=note,reference="; ".join(dict.fromkeys(c["reference"] for c in subset if c["reference"]))))
    result.append(dict(verification="Estabilidade global e sistema do galpão",status="pending",
        note="Este modelo é de uma barra biapoiada. Não verifica pórticos, contraventamentos globais, empoçamento ou sequência de montagem.",reference="NBR 14762:2010, 8 e Anexo A"))
    return result
